"""Small presentation-only values; never used for CAD decisions or ML features."""
import copy
import uuid
from .models import normalize


def camera_vectors(direction, up):
    direction = normalize(direction)
    up = normalize(up)
    dot = sum(a*b for a,b in zip(direction,up))
    up = normalize(tuple(u-dot*d for u,d in zip(up,direction)))
    return direction, up


def validate_custom_cameras(plan):
    if type(plan.next_custom_camera_index) is not int or plan.next_custom_camera_index < 1:
        raise ValueError('사용자 지정 카메라 번호가 잘못되었습니다.')
    if not isinstance(plan.custom_cameras, dict) or len(plan.custom_cameras)>1000:
        raise ValueError('사용자 지정 카메라 목록이 잘못되었습니다.')
    names=set()
    for key,value in plan.custom_cameras.items():
        if not isinstance(key,str) or not key.startswith('CUSTOM:') or str(uuid.UUID(key[7:]))!=key[7:]:
            raise ValueError('사용자 지정 카메라 ID가 잘못되었습니다.')
        name=value.get('name')
        if not isinstance(name,str) or not name.strip() or len(name)>100 or name in names:
            raise ValueError('사용자 지정 카메라 이름이 잘못되었습니다.')
        names.add(name)
        camera_vectors(value['view_direction'],value['view_up'])
    for step in plan.steps:
        if step.camera_mode.startswith('CUSTOM:') and step.camera_mode not in plan.custom_cameras:
            raise ValueError('단계에서 사용하는 사용자 지정 카메라가 없습니다.')
    if not isinstance(plan.display_names,dict) or any(not isinstance(k,str) or not isinstance(n,str) or not n.strip() or len(n)>200
            or any(ord(c)<32 for c in n) for k,n in plan.display_names.items()):
        raise ValueError('부품 표시명이 잘못되었습니다.')


def add_custom_camera(plan, direction, up):
    direction,up=camera_vectors(direction,up)
    key='CUSTOM:'+str(uuid.uuid4())
    used={v['name'] for v in plan.custom_cameras.values()}
    while f'사용자 지정{plan.next_custom_camera_index}' in used:plan.next_custom_camera_index+=1
    plan.custom_cameras=copy.deepcopy(plan.custom_cameras)
    plan.custom_cameras[key]={'name':f'사용자 지정{plan.next_custom_camera_index}',
                              'view_direction':list(direction),'view_up':list(up)}
    plan.next_custom_camera_index+=1
    return key


def prune_custom_cameras(plan):
    used={s.camera_mode for s in plan.steps}
    plan.custom_cameras={k:v for k,v in plan.custom_cameras.items() if k in used}
