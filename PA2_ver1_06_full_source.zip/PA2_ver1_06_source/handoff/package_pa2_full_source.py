"""Create and verify an isolated, complete PA2 developer source archive."""
from __future__ import annotations

import argparse
import ast
import hashlib
import io
import json
import stat
import tokenize
import zipfile
from datetime import datetime, timezone
from pathlib import Path


DIRECTORIES = ('src', 'assets', 'schemas', 'migrations', 'packaging',
               'tests', 'tools', 'scripts', 'docs', 'handoff')
ROOT_FILES = ('.gitignore', 'pyproject.toml', 'requirements-lock.txt', 'run.py',
              'uninst.py', 'alembic.ini', 'README.md', 'V28_OPERATIONS.md')
SKIP_PARTS = {'__pycache__', '.pytest_cache', '.git', '.venv', 'node_modules'}
SKIP_SUFFIXES = {'.pyc', '.pyo', '.log', '.lck', '.tmp', '.bak'}
FORBIDDEN_SUFFIXES = {'.db', '.sqlite', '.sqlite3', '.mp4', '.avi', '.exe',
                      '.dll', '.zip', '.7z', '.step', '.stp', '.pyd'}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_digest(path: Path) -> str:
    sha = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            sha.update(block)
    return sha.hexdigest()


def no_link(path: Path) -> None:
    for part in (path, *path.parents):
        if part.is_symlink() or (part.exists() and
                getattr(part.lstat(), 'st_file_attributes', 0) &
                getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 1024)):
            raise ValueError(f'Link/reparse point is not a source input: {path}')


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--version', default='1_04')
    parser.add_argument('--guide', type=Path)
    parser.add_argument('--spec', type=Path)
    args = parser.parse_args()
    root = args.project.resolve()
    if not (root / 'src/pa2/__main__.py').is_file():
        raise ValueError('Not a PA2 source root')
    if any(c not in '0123456789_' for c in args.version):
        raise ValueError('Version must contain digits and underscores only')
    output = args.output.resolve()
    checksum = output.with_suffix(output.suffix + '.sha256')
    report_path = output.with_suffix(output.suffix + '.report.json')
    for path in (output, checksum, report_path):
        if path.exists():
            raise FileExistsError(path)
    prefix = f'PA2_ver{args.version}_source/'
    inputs: dict[str, Path] = {}
    for folder in DIRECTORIES:
        base = root / folder
        if not base.exists():
            if folder == 'handoff':
                continue
            raise FileNotFoundError(base)
        for path in sorted(base.rglob('*')):
            relative = path.relative_to(root)
            if any(part in SKIP_PARTS for part in relative.parts):
                continue
            no_link(path)
            if not path.is_file() or path.suffix.lower() in SKIP_SUFFIXES:
                continue
            if path.suffix.lower() in FORBIDDEN_SUFFIXES or path.name.startswith('.env'):
                raise ValueError(f'Unexpected runtime/private file in source tree: {relative}')
            inputs[relative.as_posix()] = path
    for name in ROOT_FILES:
        path = root / name
        if not path.is_file():
            raise FileNotFoundError(path)
        inputs[name] = path
    # All source-root launchers, including historical validation launchers.
    for path in sorted(root.glob('*.bat')):
        inputs[path.name] = path
    guide = args.guide or root / 'SOURCE_README_KO.txt'
    spec = args.spec or root / f'docs/PA2_ver{args.version}_상세_기술명세.md'
    inputs['SOURCE_README_KO.txt'] = guide.resolve()
    inputs['docs/' + spec.name] = spec.resolve()
    inputs['handoff/package_pa2_full_source.py'] = Path(__file__).resolve()

    contents: dict[str, bytes] = {}
    hashes = {}
    python_count = 0
    for name, path in sorted(inputs.items()):
        no_link(path)
        data = path.read_bytes()
        if path.suffix == '.py':
            encoding, _ = tokenize.detect_encoding(io.BytesIO(data).readline)
            ast.parse(data.decode(encoding), filename=name)
            python_count += 1
        contents[name] = data
        hashes[name] = {'bytes': len(data), 'sha256': digest(data)}
    all_application_modules = {
        p.relative_to(root).as_posix() for p in (root / 'src/pa2').rglob('*.py')
        if '__pycache__' not in p.parts
    }
    if not all_application_modules <= contents.keys():
        raise ValueError('Application source modules omitted')
    # Check that the large, required trained-model/evaluation assets are included.
    asset_names = {p.relative_to(root).as_posix() for p in (root / 'assets').rglob('*')
                   if p.is_file() and '__pycache__' not in p.parts}
    if not asset_names <= contents.keys():
        raise ValueError('Assets omitted')
    for name in ('assets/pilot/pilot.json', 'packaging/pa2.spec',
                 'packaging/uninst.spec', 'uninst.py'):
        if name not in contents:
            raise ValueError(f'Required input missing: {name}')
    protected = {}
    for path in (root / 'PA2.exe', root / 'uninst.exe', root / '.pa2-install.json',
                 root / f'releases/PA2_ver{args.version}_windows_x64.zip'):
        if path.exists():
            protected[path] = file_digest(path)
    manifest = {
        'schema': 'pa2-full-source-v1', 'release': f'ver{args.version}',
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'python': 'CPython 3.13 x64',
        'application_modules': len(all_application_modules),
        'python_files': python_count, 'assets': len(asset_names),
        'technical_spec': 'docs/' + spec.name,
        'paired_runtime': {
            'executable_sha256': file_digest(root / 'PA2.exe') if (root / 'PA2.exe').is_file() else None,
            'distribution_sha256': file_digest(root / f'releases/PA2_ver{args.version}_windows_x64.zip')
                if (root / f'releases/PA2_ver{args.version}_windows_x64.zip').is_file() else None,
        },
        'files': hashes,
        'excludes': ['virtualenv', 'compiled runtimes', 'build outputs',
                     'user project databases', 'logs', 'videos',
                     'external original STEP files', 'installation ownership manifest'],
        'note': 'assets/pilot includes bundled learned models and fixed reference resources. '
                'SOURCE_MANIFEST.json does not hash itself.',
    }
    contents['SOURCE_MANIFEST.json'] = json.dumps(
        manifest, ensure_ascii=False, indent=2).encode('utf-8')
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'x', zipfile.ZIP_DEFLATED, compresslevel=7) as archive:
        for name, data in sorted(contents.items()):
            archive.writestr(prefix + name, data)
    with zipfile.ZipFile(output) as archive:
        bad = archive.testzip()
        if bad:
            raise ValueError(f'ZIP CRC failed: {bad}')
        if set(archive.namelist()) != {prefix + name for name in contents}:
            raise ValueError('ZIP entries mismatch')
        for name, data in contents.items():
            if digest(archive.read(prefix + name)) != digest(data):
                raise ValueError(f'ZIP content mismatch: {name}')
    for name, path in inputs.items():
        if file_digest(path) != hashes[name]['sha256']:
            raise ValueError(f'Original changed during packaging: {name}')
    for path, before in protected.items():
        if file_digest(path) != before:
            raise ValueError(f'Protected runtime changed: {path.name}')
    zip_sha = file_digest(output)
    checksum.write_text(f'{zip_sha}  {output.name}\n', encoding='utf-8')
    report = {'ok': True, 'archive': output.name, 'bytes': output.stat().st_size,
              'sha256': zip_sha, 'files': len(contents), 'python_files': python_count,
              'application_modules': len(all_application_modules),
              'asset_files': len(asset_names), 'crc_ok': True,
              'all_entry_hashes_match': True, 'all_original_inputs_unchanged': True,
              'protected_runtime_files_unchanged': len(protected),
              'manifest': 'SOURCE_MANIFEST.json'}
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
