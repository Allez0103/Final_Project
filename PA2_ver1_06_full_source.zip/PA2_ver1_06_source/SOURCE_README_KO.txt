PA² ver1_06 전체 소스 전달 안내
작성일: 2026-10-26

1. 용도와 포함 범위
PA2_ver1_06_windows_x64.zip의 V32 실행 파일에 대응하는 사내 개발용 전체 소스입니다.
실행용 ZIP은 Python 설치가 필요 없지만, 이 소스의 실행/빌드에는 Windows x64,
Python 3.13 x64와 requirements-lock.txt의 라이브러리가 필요합니다. wheel은 미포함입니다.

포함: 전체 Python 소스(UI/알고리즘/저장/영상/학습/로그/제거), 테스트,
잠금 의존성, 스키마·마이그레이션, 빌드 도구, 아이콘·영상 템플릿, 기술 문서,
승인된 순서·방향 모델과 고정 학습/평가 참조 자산(assets/pilot의 JSON·BREP).
Git 소스 저장소와 달리 이 ZIP에는 위 모델/참조 번들이 들어갑니다.
제외: .venv, EXE/DLL, 빌드 결과, 배포 ZIP, 실제 사용자 CAD/STEP·DB·로그·영상,
runtime-data, 실험 결과, 설치 소유권 파일, Git 이력/자격 증명.
모델/참조 자산을 포함하므로 사내 개발 전달용이며 외부 공개 권한을 뜻하지 않습니다.

2. 최신 변경과 문서 우선순위
최신 배포 기준: docs/RELEASE_VER1_06.md
최신 세부 구현: docs/V32_EDITOR_CUSTOM_CAMERA.md
이전 변경: docs/RELEASE_VER1_05.md 및 V29~V31 관련 문서
전체 기반 명세: docs/PA2_ver1_04_상세_기술명세.md (원문 보존)
로그: docs/ACCURACY_LOG.md / 모델·로그·제거 운용: V28_OPERATIONS.md

이번 추가: 작업 속성 2탭, 미리보기 & 적용 통합, 좌/우 드래그 전환,
프로젝트별 사용자 지정 시점과 재사용/자동 정리, 생성 전·후 부품 표시명 편집.
기존 자동/수동 생성·그룹화·순서 편집/확정·영상·학습·로그·제거를 유지합니다.
간섭 기준 변경 및 보류한 자동 예외 실험은 포함하지 않습니다.
1_04 상세 명세는 당시 이력입니다. 새로운 1_06 통합 상세 명세를 작성한 것은 아닙니다.
예전 자재정보/과정 문구는 수동 입력 보호를 위해 이름 변경 시 덮어쓰지 않습니다.
기존 색상 없는 캐시 및 한글 설치 경로 LightGBM 문제는 미해결입니다.
가능하면 영문 개발 경로를 사용하고 과거 문서의 개발 PC 절대 경로에 주의하세요.

3. 개발 환경 구성 (압축 해제한 PA2_ver1_06_source 폴더에서 PowerShell 실행)
  powershell -ExecutionPolicy Bypass -File .\scripts\setup.ps1
Python 검색 실패 시:
  powershell -ExecutionPolicy Bypass -File .\scripts\setup.ps1 -Python "C:\경로\python.exe"
setup.ps1은 .venv 생성, 잠금 의존성 및 편집 가능한 패키지 설치를 수행합니다.
내부 Python 패키지 버전 0.1.0은 유지하며 전달본 버전은 ver1_06입니다.

4. 실제 업무 데이터와 분리하여 실행
아래 설정은 테스트/빌드에도 유지하세요.
  $env:PYTHONPATH = Join-Path $PWD.Path 'src'
  $env:PA2_DATA_ROOT = Join-Path $PWD.Path 'runtime-data\developer'
  $env:PA2_INSTALL_ROOT = $PWD.Path
  $env:PA2_DISABLE_BACKGROUND_LEARNING = '1'
  Remove-Item Env:PA2_DATABASE_URL -ErrorAction SilentlyContinue
  .\.venv\Scripts\python.exe -X utf8 -B .\run.py
기본 업무 EXE의 DB를 개발용으로 지정하지 마세요. 자동 학습 비활성화는 개발 중
백그라운드 학습을 막기 위한 것이며 배포본의 사용자 설정을 바꾸지 않습니다.

5. 테스트
위 격리 환경에서:
  powershell -ExecutionPolicy Bypass -File .\scripts\test.ps1
외부 CAD 입력이 없는 통합 테스트는 건너뛸 수 있습니다. 이전 검증 스크립트는
개발 PC 절대 경로/외부 자료를 전제로 할 수 있으므로 확인 후 실행하세요.
포장 전 V32 회귀검사는 500개 중 498개 통과, 2개 건너뜀, 실패 0개입니다.
실제 EXE의 자동/수동 생성·시점·표시명·확정·영상 등 33개 확인 항목을 통과했습니다.

6. EXE 빌드 (업무 배포 폴더가 아닌 개발 복사본에서)
  powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1
제거 프로그램은 별도 빌드합니다:
  .\.venv\Scripts\python.exe -m PyInstaller --noconfirm --distpath build\uninst-distribution packaging\uninst.spec
  Copy-Item -LiteralPath .\build\uninst-distribution\uninst.exe -Destination .\uninst.exe
PA2.exe, uninst.exe, _internal이 준비된 새 빌드에서만 설치 목록을 만드세요:
  .\.venv\Scripts\python.exe -c "from pathlib import Path; from pa2.uninstaller import inventory; inventory(Path.cwd())"
제거는 별도 복사본에서 시험하세요. --report는 삭제 결과 출력 옵션이지 읽기 전용
점검 옵션이 아닙니다. 실제 프로젝트 삭제에 주의하세요.
실행 배포 포장: tools/package_portable.py --help (버전은 --version ver1_06 명시).

7. 무결성과 재포장
SOURCE_MANIFEST.json에는 파일별 크기/SHA256과 대응 EXE·실행 ZIP 해시가 있습니다.
ZIP 옆 .sha256은 ZIP 자체 해시입니다. .report.json에는 파일 수와 검증 결과가 있습니다.
재포장 도구 handoff/package_pa2_full_source.py의 기본값 대신 --version 1_06을 지정하고
--guide SOURCE_README_KO.txt --spec docs/PA2_ver1_04_상세_기술명세.md도 명시하세요.
기존 ZIP은 덮어쓰지 않습니다. 사내 전달본은 서명되지 않았으며 외부 배포 라이선스
검토 완료를 의미하지 않습니다. 이번 요청으로 Git 저장소는 갱신하지 않습니다.
