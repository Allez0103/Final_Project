import copy

import pytest
import vtk

from test_mentor_visuals import editor


@pytest.mark.parametrize('name',['등각','상면','하면','정면','후면','좌측','우측'])
@pytest.mark.parametrize('swapped',[False,True])
def test_manual_rotation_clears_preset_and_allows_reselection(editor,name,swapped):
    page=editor
    scene=page.vtk_scene
    interactor=vtk.vtkGenericRenderWindowInteractor()
    interactor.SetRenderWindow(scene.render_window)
    scene.configure_interaction(interactor,lambda *_:None,on_rotate=page._manual_view_rotation)
    scene.set_mouse_swap(swapped)
    camera=scene.renderer.GetActiveCamera()
    action=next(a for a in page.view_action_group.actions() if a.text()==name)
    action.trigger()
    direction=camera.GetDirectionOfProjection()
    before=copy.deepcopy(page.plan.to_dict())
    style=scene._interaction_style

    # A click and tiny mouse jitter preserve the selected preset.
    button='Right' if swapped else 'Left'
    interactor.SetEventInformation(100,100,0,0)
    style.InvokeEvent(button+'ButtonPressEvent')
    interactor.SetEventInformation(101,101,0,0)
    style.InvokeEvent('MouseMoveEvent')
    style.InvokeEvent(button+'ButtonReleaseEvent')
    assert action.isChecked()

    # Pan and zoom preserve the angle and its checked state.
    pan_button='Left' if swapped else 'Right'
    interactor.SetEventInformation(100,100,0,0)
    style.InvokeEvent(pan_button+'ButtonPressEvent')
    interactor.SetEventInformation(115,108,0,0)
    style.InvokeEvent('MouseMoveEvent')
    style.InvokeEvent(pan_button+'ButtonReleaseEvent')
    style.InvokeEvent('MouseWheelForwardEvent')
    assert action.isChecked()
    assert camera.GetDirectionOfProjection()==pytest.approx(direction)

    # Rotate through the real VTK interaction events.
    interactor.SetEventInformation(100,100,0,0)
    style.InvokeEvent(button+'ButtonPressEvent')
    interactor.SetEventInformation(145,125,0,0)
    style.InvokeEvent('MouseMoveEvent')
    style.InvokeEvent(button+'ButtonReleaseEvent')
    assert camera.GetDirectionOfProjection()!=pytest.approx(direction)
    assert page.views.currentIndex()==-1
    assert not any(a.isChecked() for a in page.view_action_group.actions())
    action.trigger()
    assert action.isChecked() and page.views.currentText()==name
    assert camera.GetDirectionOfProjection()==pytest.approx(direction)
    assert page.plan.to_dict()==before
    # Repeatedly choosing the same preset must also restore its direction.
    camera.Azimuth(15)
    action.trigger()
    assert camera.GetDirectionOfProjection()==pytest.approx(direction)
    scene._stop_navigation()
