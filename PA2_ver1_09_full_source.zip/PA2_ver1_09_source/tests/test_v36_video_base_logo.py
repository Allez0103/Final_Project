from pathlib import Path
import numpy as np
from PIL import Image
from test_mentor_visuals import editor
from pa2.rendering.scene import scene_at,SceneFrame,CameraPose
from pa2.video.renderer import VideoRenderer
from pa2.settings.config import AppSettings


def test_v36_base_intro_keeps_original_color_and_normal_steps_still_highlight(editor):
    p=editor;timeline=p._timeline();original=p.vtk_scene.base_colors[p.plan.base_group_id]
    for t in (0,.25,.5,timeline.base_end-.001):
        frame=scene_at(p.plan,t,p.settings,timeline)
        assert frame.active_group_id==p.plan.base_group_id and frame.highlight_alpha==0
        p.vtk_scene.apply(frame)
        assert np.allclose(p.vtk_scene.actors[p.plan.base_group_id].GetProperty().GetColor(),original)
    first=timeline.segments[0]
    assert scene_at(p.plan,first.camera_end+.001,p.settings,timeline).highlight_alpha==1
    assert scene_at(p.plan,(first.highlight_end+first.move_end)/2,p.settings,timeline).highlight_alpha==1


def test_v36_logo_fits_region_is_centered_and_keeps_source_image(tmp_path):
    root=Path(__file__).resolve().parents[1];path=root/'assets/thn_logo.png';original=path.read_bytes()
    renderer=VideoRenderer(AppSettings(),root/'assets/video_template_v1.json',path)
    frame=SceneFrame(0,set(),{},None,0,CameraPose((0,0,-1),'TOP'),process_text='기준 부품 배치')
    preview=renderer._compose(np.full((200,300,3),245,dtype=np.uint8),frame,'차종','품종','완제품.step',1920,1080)
    x,y,w,h=renderer.template['regions']['logo'];box=(int(x*1920),int(y*1080),int((x+w)*1920),int((y+h)*1080))
    pixels=np.asarray(preview.crop(box));rows,cols=np.where((pixels[:,:,:3]<240).any(axis=2))
    assert abs((cols.min()+cols.max())/2-(pixels.shape[1]-1)/2)<=2
    assert abs((rows.min()+rows.max())/2-(pixels.shape[0]-1)/2)<=2
    assert (rows.max()-rows.min()+1>=pixels.shape[0]-2 or
            cols.max()-cols.min()+1>=pixels.shape[1]-2)
    assert renderer.logo.width > renderer.logo.height * 7  # Both horizontal lockups.
    assert renderer.TEMPLATE_VERSION == renderer.template['template_version']
    assert path.read_bytes()==original
    preview.save(tmp_path/'v36-template.png')
