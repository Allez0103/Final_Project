"""Removal tests use disposable copies; never touch the real installation/data."""
import json
from pathlib import Path

import pytest

from pa2 import uninstaller as u


def fixture(tmp_path):
    install=tmp_path/'install';data=tmp_path/'data'
    (install/'_internal/empty/nested').mkdir(parents=True)
    (install/'log/accuracy_log').mkdir(parents=True)
    (install/'PA2.exe').write_bytes(b'program')
    (install/'uninst.exe').write_bytes(b'remover')
    (data/'projects/p1').mkdir(parents=True)
    (data/'projects/p1/model.step').write_bytes(b'COPY')
    for name in ('database','cache','assets','jobs','learning','logs'):
        (data/name).mkdir()
    (data/'settings.json').write_text('{}')
    u.inventory(install);u.register_data(install,data)
    return install,data


def test_clean_install_and_data_roots_have_no_residual_folders(tmp_path):
    install,data=fixture(tmp_path)
    result=u.execute(install,u.build_plan(install)['approval'])
    assert result['ok'] and not result['remaining_directories']
    assert not install.exists() and not data.exists()
    assert tmp_path.exists()  # Never remove parents outside the exact roots.


def test_shared_data_removed_but_other_installation_and_original_stay(tmp_path):
    install,data=fixture(tmp_path)
    other=tmp_path/'other-version';other.mkdir()
    (other/'PA2.exe').write_bytes(b'other version')
    (other/'uninst.exe').write_bytes(b'other remover')
    u.inventory(other);u.register_data(other,data)
    before={p.name:p.read_bytes() for p in other.iterdir()}
    original=tmp_path/'original.step';original.write_bytes(b'original')
    plan=u.build_plan(install)
    assert plan['shared_data_roots']==[str(data)]
    assert u.execute(install,plan['approval'])['ok']
    assert not data.exists() and not install.exists()
    assert before=={p.name:p.read_bytes() for p in other.iterdir()}
    assert original.read_bytes()==b'original'
    # Another version can start over after shared data removal.
    data.mkdir();u.register_data(other,data)
    assert u.read(data/u.OWNED)['owners']=={u.read(other/u.MANIFEST)['id']:str(other)}


def test_same_zip_id_at_two_paths_does_not_block_shared_removal(tmp_path):
    install,data=fixture(tmp_path)
    other=tmp_path/'other-version';other.mkdir()
    (other/'PA2.exe').write_bytes(b'other')
    (other/u.MANIFEST).write_bytes((install/u.MANIFEST).read_bytes())
    u.register_data(other,data)  # v1 replaces the same ID's owner path.
    plan=u.build_plan(install)
    assert plan['shared_data_roots']==[str(data)]
    assert u.execute(install,plan['approval'])['ok']
    assert not install.exists() and not data.exists() and (other/'PA2.exe').exists()


def test_unknown_files_preserve_their_containers(tmp_path):
    install,data=fixture(tmp_path)
    for path in (install/'backup.zip',install/'log/notes.txt',data/'original.step'):
        path.write_bytes(b'USER')
    result=u.execute(install,u.build_plan(install)['approval'])
    assert result['ok'] and result['remaining_directories']
    for path in (install/'backup.zip',install/'log/notes.txt',data/'original.step'):
        assert path.read_bytes()==b'USER'
    assert not (install/'_internal').exists() and not (data/'projects').exists()


def test_owner_change_after_confirmation_invalidates_approval(tmp_path):
    install,data=fixture(tmp_path);plan=u.build_plan(install)
    marker=u.read(data/u.OWNED);marker['owners']['old']='Z:/old-version';u.atomic(data/u.OWNED,marker)
    with pytest.raises(ValueError,match='범위가 바뀌'):
        u.execute(install,plan['approval'])
    assert (install/'PA2.exe').exists() and (data/'projects/p1/model.step').exists()


def test_unrelated_owner_id_cannot_authorize_a_data_wipe(tmp_path):
    install,data=fixture(tmp_path)
    u.atomic(data/u.OWNED,{'schema':'pa2-owned-data-v1','owners':{'other':str(tmp_path/'other')}})
    with pytest.raises(ValueError,match='소유 경로'):
        u.build_plan(install)
    assert (data/'projects/p1/model.step').exists()


def test_collision_needs_matching_other_manifest(tmp_path):
    install,data=fixture(tmp_path);other=tmp_path/'other';other.mkdir()
    marker=u.read(data/u.OWNED);marker['owners'][u.read(install/u.MANIFEST)['id']]=str(other)
    u.atomic(data/u.OWNED,marker)
    u.atomic(other/u.MANIFEST,{'schema':'pa2-install-v1','id':'unrelated','data_roots':[str(data)]})
    with pytest.raises(ValueError,match='소유 경로'):
        u.build_plan(install)
    assert (data/'projects/p1/model.step').exists()


def test_global_running_check_occurs_before_any_deletion(tmp_path,monkeypatch):
    install,data=fixture(tmp_path);plan=u.build_plan(install)
    def running(_):raise ValueError('다른 버전 PA2 실행 중')
    monkeypatch.setattr(u,'ensure_closed',running)
    with pytest.raises(ValueError,match='다른 버전'):
        u.execute(install,plan['approval'])
    assert (install/'PA2.exe').exists() and (data/'projects/p1/model.step').exists()


def test_multiple_data_roots_are_removed_but_not_their_parent(tmp_path):
    install,data=fixture(tmp_path);another=tmp_path/'another-data';another.mkdir()
    (another/'cache').mkdir();u.register_data(install,another)
    result=u.execute(install,u.build_plan(install)['approval'])
    assert result['ok'] and not any(p.exists() for p in (install,data,another))
    assert tmp_path.exists()


def test_unknown_file_inside_internal_is_never_removed(tmp_path):
    install,data=fixture(tmp_path);unknown=install/'_internal/user.txt';unknown.write_bytes(b'USER')
    result=u.execute(install,u.build_plan(install)['approval'])
    assert result['ok'] and unknown.read_bytes()==b'USER'
    assert not (install/'_internal/empty').exists()


def test_malformed_owner_schema_is_rejected(tmp_path):
    install,data=fixture(tmp_path)
    marker=u.read(data/u.OWNED);marker['schema']='unknown';u.atomic(data/u.OWNED,marker)
    with pytest.raises(ValueError,match='소유 정보'):
        u.build_plan(install)


def test_known_log_files_and_empty_containers_are_removed(tmp_path):
    install,data=fixture(tmp_path)
    u.atomic(install/'log/generation.json',{'schema_version':'pa2-generation-log-v1'})
    u.atomic(install/'log/accuracy_log/accuracy.json',{'schema_version':'pa2-accuracy-log-v1'})
    result=u.execute(install,u.build_plan(install)['approval'])
    assert result['ok'] and not install.exists() and not data.exists()
