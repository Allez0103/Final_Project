import copy
import json
from dataclasses import replace
import pytest
from PySide6.QtCore import Qt,QItemSelectionModel
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication,QLineEdit,QPushButton
from test_mentor_visuals import editor
from pa2.domain.models import Plan,PlanStep,PlanningStatus,Bounds
from pa2.domain.presentation import add_custom_camera,prune_custom_cameras
from pa2.rendering.scene import build_timeline,camera_for_step,camera_pose_angle
from pa2.settings.config import AppSettings,SettingsStore


def select_camera(page,value):
    index=page.camera.findData(value)
    assert index>=0
    page.camera.setCurrentIndex(index)


def capture(page):
    select_camera(page,'CUSTOM_NEW')
    assert page.camera_capture_button.isEnabled()
    cam=page.vtk_scene.renderer.GetActiveCamera()
    cam.SetPosition(100,-50,70);cam.SetFocalPoint(0,0,0);cam.SetViewUp(.2,.3,1)
    direction=cam.GetDirectionOfProjection()
    page.camera_capture_button.click()
    assert page._pending_custom_camera is not None
    return direction


def test_tabs_have_correct_fields_and_only_one_common_apply_button(editor):
    p=editor;p.show();QApplication.processEvents()
    assert [p.properties_tabs.tabText(i) for i in range(2)]==['동작설정','작업 안내']
    motion=p.properties_tabs.widget(0);guide=p.properties_tabs.widget(1)
    assert motion.isAncestorOf(p.camera) and motion.isAncestorOf(p.direction)
    assert all(guide.isAncestorOf(w) for w in (p.process,p.material,p.caution))
    assert p.apply_button is p.step_preview_button and not motion.isAncestorOf(p.apply_button)
    for tab in range(2):
        p.properties_tabs.setCurrentIndex(tab);QApplication.processEvents()
        assert p.apply_button.isVisible()
    assert not any(b.isVisible() and b.text() in {'미리보기','선택 단계에 적용'} for b in p.findChildren(QPushButton))


def test_combined_button_applies_then_previews_without_cad(editor,monkeypatch):
    from pa2.jobs.isolated import IsolatedCadWorker
    from pa2.cad.path_check import ConservativePathChecker
    def forbidden(*a,**k):pytest.fail('UI apply/preview invoked CAD')
    monkeypatch.setattr(IsolatedCadWorker,'call',forbidden);monkeypatch.setattr(ConservativePathChecker,'check',forbidden)
    p=editor;saves=[];p.save_requested.connect(lambda p:saves.append(copy.deepcopy(p.to_dict())))
    p.direction.setCurrentText('+X');p.distance.setValue(15);p.process.setPlainText('사용자 조립 설명')
    p.apply_button.click()
    assert p.plan.steps[0].removal_direction==(1,0,0) and p.plan.steps[0].travel_mm==15
    assert p.plan.steps[0].process_text=='사용자 조립 설명'
    assert p._step_preview and saves and not p.has_pending_fields()
    assert p._step_preview['plan'].to_dict()==p.plan.to_dict()


def test_batch_apply_changes_only_edited_fields_and_previews_first_stage(editor):
    p=editor
    first,second=p.plan.steps
    first.travel_mm=10.1234
    second.travel_mm=22.5678
    first.process_text='첫 단계'
    second.process_text='다음 단계'
    first.camera_mode='TOP'
    second.camera_mode='RIGHT'
    p.set_plan(p.plan,'test')
    p.order.setCurrentRow(1,QItemSelectionModel.ClearAndSelect)
    p.order.item(0).setSelected(True)
    assert p.order.currentRow()==1 and p.apply_button.isEnabled()
    assert not p.process.isEnabled()
    assert not any('이 뒤로 과정 문구' in b.text() for b in p.findChildren(QPushButton))
    before=copy.deepcopy(p.plan.to_dict())
    p.apply_button.click()
    assert p.plan.to_dict()==before
    assert p._step_preview['time']==p._step_preview['timeline'].segments[0].camera_start
    p._stop_preview()
    p.material.setPlainText('공통 자재')
    p.caution.setPlainText('공통 주의')
    p.process.setPlainText('적용 불가')
    assert p.has_pending_fields()
    p.apply_button.click()
    assert [s.travel_mm for s in p.plan.steps]==[10.1234,22.5678]
    assert [s.camera_mode for s in p.plan.steps]==['TOP','RIGHT']
    assert [s.process_text for s in p.plan.steps]==['첫 단계','다음 단계']
    assert all(s.material_text=='공통 자재' and s.caution_text=='공통 주의' for s in p.plan.steps)
    assert p._step_preview['plan'].to_dict()==p.plan.to_dict()
    p._stop_preview()
    p.direction.setCurrentText('-X')
    p.distance.setValue(40)
    capture(p)
    p.apply_button.click()
    assert all(s.assembly_direction==(1,0,0) and s.travel_mm==40 for s in p.plan.steps)
    assert len({s.camera_mode for s in p.plan.steps})==len(p.plan.custom_cameras)==1
    p._history(False)
    assert [s.camera_mode for s in p.plan.steps]==['TOP','RIGHT']
    assert p.process.isEnabled()


def test_custom_capture_stages_then_creates_numbered_project_camera(editor):
    p=editor;before=copy.deepcopy(p.plan.to_dict())
    assert not p.camera_capture_button.isEnabled()
    direction=capture(p)
    assert p.plan.to_dict()==before
    p.apply_button.click();mode=p.plan.steps[0].camera_mode
    assert mode.startswith('CUSTOM:') and p.camera.currentText()=='사용자 지정1'
    assert p.plan.custom_cameras[mode]['name']=='사용자 지정1'
    assert not p.camera_capture_button.isEnabled() and not p.has_pending_fields()
    pose=p._step_preview['timeline'].step_cameras[0]
    assert pose.view_direction==pytest.approx(direction)
    assert p._step_preview['timeline'].first_view_landscape_roll_deg==0
    p._stop_preview();p.order.setCurrentRow(1,QItemSelectionModel.ClearAndSelect);select_camera(p,mode)
    assert p.apply_button.isEnabled(), (p.order.currentRow(),[i.data(Qt.UserRole) for i in p.order.selectedItems()])
    assert p.order.currentItem().data(Qt.UserRole)=='cover'
    p.apply_button.click()
    assert p.plan.steps[1].camera_mode==mode and len(p.plan.custom_cameras)==1
    p._stop_preview();capture(p);p.apply_button.click()
    assert {v['name'] for v in p.plan.custom_cameras.values()}=={'사용자 지정1','사용자 지정2'}
    assert p.plan.steps[0].camera_mode==mode


def test_last_reference_cleanup_undo_redo_and_pending_capture(editor):
    p=editor;capture(p);p.apply_button.click();mode=p.plan.steps[0].camera_mode
    p._stop_preview();select_camera(p,'TOP');p.apply_button.click()
    assert mode not in p.plan.custom_cameras and p.camera.findData(mode)<0
    p._history(False);assert mode in p.plan.custom_cameras and p.plan.steps[0].camera_mode==mode
    p._history(True);assert not p.plan.custom_cameras
    capture(p);assert p._pending_custom_camera and not p.plan.custom_cameras
    p.order.setCurrentRow(1,QItemSelectionModel.ClearAndSelect);assert p._pending_custom_camera is None


def test_capture_required_and_multi_base_selection_disables_capture(editor):
    p=editor;select_camera(p,'CUSTOM_NEW');before=copy.deepcopy(p.plan.to_dict())
    p.apply_button.click();assert p.plan.to_dict()==before and not p._step_preview
    assert '캡처' in p.status.text()
    p.order.item(1).setSelected(True);assert not p.camera_capture_button.isEnabled()
    p.base_card.click();assert not p.camera_capture_button.isEnabled()


@pytest.mark.parametrize('swap',[False,True])
def test_swap_only_affects_drag_and_keeps_modifier_pan(editor,swap):
    scene=editor.vtk_scene;editor.apply_settings(replace(AppSettings(),swap_mouse_buttons=swap))
    assert scene.drag_is_pan('Left')==swap
    assert scene.drag_is_pan('Right')==(not swap)
    assert scene.drag_is_pan('Middle')
    assert scene.drag_is_pan('Left',control=True) and scene.drag_is_pan('Right',shift=True)
    editor._picked('bolt');assert not editor.parts.selectedItems()
    editor._picked('bolt');assert editor.parts.selectedItems()[0].data(Qt.UserRole)=='bolt'
    scene.pan_mode=True;assert scene.drag_is_pan('Left') and scene.drag_is_pan('Right')


def test_toggle_persists_reset_and_legacy_settings(tmp_path,editor):
    from pa2.ui.settings_dialog import SettingsDialog
    from pa2.ui.toggle import ToggleSwitch
    store=SettingsStore(tmp_path/'settings.json');store.path.write_text('{}',encoding='utf-8')
    assert not store.load().swap_mouse_buttons
    dialog=SettingsDialog(store,store.load());switch=dialog.widgets['swap_mouse_buttons']
    assert isinstance(switch,ToggleSwitch)
    switch.setChecked(True);dialog._save();assert store.load().swap_mouse_buttons
    dialog=SettingsDialog(store,store.load());dialog._defaults();assert not dialog.widgets['swap_mouse_buttons'].isChecked()
    assert store.load().swap_mouse_buttons  # defaults without save do not write
    with pytest.raises(ValueError):replace(AppSettings(),swap_mouse_buttons=1).validate()
    dialog.close()


def test_mouse_preference_does_not_change_learning_policy_or_family(editor):
    from pa2.learning.pipeline import policy_signature
    from pa2.learning.collection import family_fingerprint
    before=family_fingerprint(editor.result.snapshot)
    editor.apply_part_name('bolt','사용자 표시만 변경')
    assert family_fingerprint(editor.result.snapshot)==before
    assert policy_signature(AppSettings())==policy_signature(replace(AppSettings(),swap_mouse_buttons=True))


def test_frozen_native_diagnostic_checks_cannot_be_optimized_away():
    import ast
    from pathlib import Path
    path=Path(__file__).resolve().parents[1]/'src/pa2/ui_verify_v32.py'
    tree=ast.parse(path.read_text(encoding='utf-8'))
    assert not any(isinstance(node,ast.Assert) for node in ast.walk(tree))
    assert any(isinstance(node,ast.FunctionDef) and node.name=='require' for node in ast.walk(tree))


def test_right_click_edits_raw_name_enter_applies_escape_cancels_before_generation(editor):
    p=editor;p.set_result(p.result,p.settings);assert p.plan is None
    p.resize(1440,900);p.show();QApplication.processEvents()
    p.rename_requested.connect(p.apply_part_name)
    item=p.parts.item(1);original=next(g for g in p.result.snapshot.groups if g.id=='bolt').display_name
    def open_editor():
        QTest.mouseClick(p.parts.viewport(),Qt.RightButton,Qt.NoModifier,p.parts.visualItemRect(item).center())
        QApplication.processEvents()
        return next(e for e in p.parts.findChildren(QLineEdit) if e.isVisible())
    line=open_editor();assert line.text()==original
    line.setText('새 체결볼트');QTest.keyClick(line,Qt.Key_Return);QApplication.processEvents()
    group=next(g for g in p.result.snapshot.groups if g.id=='bolt')
    assert group.label=='새 체결볼트' and group.display_name==original
    assert p.base.itemText(p.base.findData('bolt'))=='새 체결볼트'
    line=open_editor();line.setText('취소할 이름');QTest.keyClick(line,Qt.Key_Escape);QApplication.processEvents()
    assert group.label=='새 체결볼트' and item.text().startswith('새 체결볼트')


def test_rename_keeps_identity_custom_text_pending_camera_and_grouping(editor):
    p=editor;group=next(g for g in p.result.snapshot.groups if g.id=='bolt');before=copy.deepcopy(group)
    step=p.plan.steps[0];step.material_text='사용자 자재';step.process_text='사용자 과정';step.caution_text='유지'
    p.set_plan(p.plan,'test');p.thumbnail_timer.stop();capture(p)
    pending=copy.deepcopy(p._pending_custom_camera)
    p.apply_part_name('bolt','표시용 볼트')
    assert group.display_name==before.display_name and group.id==before.id and group.body_ids==before.body_ids
    assert group.part_type==before.part_type and group.bounds==before.bounds
    assert p._pending_custom_camera==pending
    assert (step.material_text,step.process_text,step.caution_text)==('사용자 자재','사용자 과정','유지')
    assert '표시용 볼트' in p.order.item(0).text() and p.plan.display_names['bolt']=='표시용 볼트'


def test_auto_text_rename_follows_name_but_new_manual_input_survives(editor):
    p=editor;step=p.plan.steps[0];step.material_auto=step.process_auto=True
    step.material_text='bolt';step.process_text='bolt 조립'
    p.set_plan(p.plan,'test');p.thumbnail_timer.stop()
    p.apply_part_name('bolt','새 볼트');assert p.material.toPlainText()=='새 볼트'
    assert step.material_text=='새 볼트' and step.process_text=='새 볼트 조립'
    p.material.setPlainText('별도 입력');p.apply_button.click();p._stop_preview()
    assert not p.plan.steps[0].material_auto
    p.apply_part_name('bolt','다시 변경');assert p.plan.steps[0].material_text=='별도 입력'


def sample_plan():
    return Plan('p','q',1,'base',['base','part'],[PlanStep('part',1,(0,0,1),(0,0,-1),10)],PlanningStatus.COMPLETE)


@pytest.mark.parametrize('direction,up',[
    ((0,0,0),(0,1,0)),((0,0,-1),(0,0,1)),((float('nan'),0,1),(0,1,0)),
    ((1,0),(0,1,0)),((0,0,-1),(float('inf'),0,0))])
def test_invalid_capture_vectors_are_rejected(direction,up):
    plan=sample_plan()
    with pytest.raises(ValueError):add_custom_camera(plan,direction,up)
    assert not plan.custom_cameras


def test_custom_pose_is_exact_and_fixed_framing_not_auto_landscape(editor):
    plan=sample_plan();key=add_custom_camera(plan,(0,0,-1),(1,0,0));plan.steps[0].camera_mode=key
    plan.validate();timeline=build_timeline(plan,AppSettings(),Bounds(0,0,0,10,200,3))
    pose=timeline.step_cameras[0]
    assert pose.view_up==pytest.approx((1,0,0)) and timeline.first_view_landscape_roll_deg==0
    assert camera_pose_angle(timeline.start_camera,pose)==0
    from pa2.rendering.scene import scene_at
    scene=editor.vtk_scene
    for t in (0,timeline.base_end,timeline.segments[0].move_end):
        scene.apply(scene_at(plan,t,AppSettings(),timeline))
        cam=scene.renderer.GetActiveCamera()
        assert cam.GetFocalPoint()==scene.group_bounds['base'].center
        assert sum((a-b)**2 for a,b in zip(cam.GetPosition(),cam.GetFocalPoint()))**.5==pytest.approx(scene.camera_distance)


def test_missing_library_reference_and_dangling_cleanup():
    plan=sample_plan();key=add_custom_camera(plan,(1,2,3),(0,0,1));plan.steps[0].camera_mode=key
    missing=copy.deepcopy(plan);missing.custom_cameras={}
    with pytest.raises(ValueError):missing.validate()
    with pytest.raises(ValueError):camera_for_step(plan.steps[0])
    plan.steps[0].camera_mode='TOP';prune_custom_cameras(plan);assert not plan.custom_cameras


@pytest.fixture
def database(tmp_path):
    from pa2.storage.database import Database
    from pa2.storage.layout import DataLayout
    from pa2.application.project_service import ProjectService
    db=Database(DataLayout(tmp_path/'data'));db.initialize()
    project=ProjectService(db).create('appearance test','vehicle','product')
    yield db,project
    db.engine.dispose()


def test_db_roundtrip_project_library_gc_and_confirmation_immutability(database):
    from pa2.application.plan_service import PlanService
    from pa2.application.appearance import AppearanceService
    db,project=database;service=PlanService(db);plan=sample_plan();plan.project_id=project.id
    key=add_custom_camera(plan,(1,2,-3),(0,0,1));plan.steps[0].camera_mode=key
    plan.display_names={'part':'사용자 부품'};plan.steps[0].material_auto=True
    service.save_draft(plan);loaded=service.load_current_draft(project.id)
    assert loaded.custom_cameras==plan.custom_cameras and loaded.display_names==plan.display_names
    assert loaded.steps[0].material_auto
    cid=service.confirm(plan);signature=service.content_signature(plan)
    assert service.matches_confirmation(loaded,cid)
    plan.steps[0].camera_mode='TOP';service.save_draft(plan)
    assert not AppearanceService(db).load(project.id)['custom_cameras']
    confirmed=service.load_confirmation(cid)
    assert key in confirmed.custom_cameras and service.content_signature(confirmed)==signature
    assert not service.matches_confirmation(plan,cid)
    other=sample_plan();assert not other.custom_cameras


@pytest.mark.parametrize('name',['','  ','line\nbreak','x'*201])
def test_invalid_part_names_never_write(database,name):
    from pa2.application.appearance import AppearanceService
    db,project=database;service=AppearanceService(db)
    with pytest.raises(ValueError):service.rename(project.id,'part',name)
    assert service.load(project.id)=={}


def test_project_names_before_sequence_persist_without_rewriting_group(database):
    from pa2.storage.database import Project,ImportSnapshotRecord,AssemblyGroupRecord
    from pa2.application.appearance import AppearanceService
    from pa2.domain.models import AssemblyGroup,PartType
    db,project=database;bounds=Bounds(0,0,0,1,1,1)
    with db.session() as session:
        session.add(ImportSnapshotRecord(id='s',project_id=project.id,project_revision=1,assembly_asset_hash='hash'))
        session.flush();session.add(AssemblyGroupRecord(id='s:part',snapshot_id='s',display_name='BLT-original',
            part_type='BOLT',matching_status='UNMATCHED',bounds_json=bounds.__dict__ if hasattr(bounds,'__dict__') else dict(xmin=0,ymin=0,zmin=0,xmax=1,ymax=1,zmax=1),geometry_valid=True))
        session.get(Project,project.id).current_snapshot_id='s'
    group=AssemblyGroup('part','BLT-original',['body'],PartType.BOLT,bounds,1,(.5,.5,.5),True)
    service=AppearanceService(db);service.rename(project.id,'part','표시 볼트')
    service.apply_names(project.id,[group]);assert group.label=='표시 볼트' and group.display_name=='BLT-original'
    with db.session() as session:
        assert session.get(AssemblyGroupRecord,'s:part').display_name=='BLT-original'
        assert session.get(Project,project.id).current_draft_plan_id is None
    from pa2.application.project_service import ProjectService
    other=ProjectService(db).create('other','vehicle','product')
    assert service.load(other.id)=={}


def test_old_plan_and_database_defaults_stay_compatible(database):
    from pa2.application.plan_service import PlanService
    db,project=database;service=PlanService(db);plan=sample_plan();plan.project_id=project.id
    old=plan.to_dict()
    for field in ('custom_cameras','display_names','next_custom_camera_index','camera_rolls'):old.pop(field)
    for step in old['steps']:
        step.pop('material_auto');step.pop('process_auto')
    restored=service._from_dict(old);restored.validate()
    assert restored.custom_cameras=={} and not restored.steps[0].material_auto
    service.save_draft(restored);db.initialize()
    assert service.content_signature(service.load_current_draft(project.id))==service.content_signature(restored)


def test_additive_tables_leave_existing_legacy_plan_rows_intact(database):
    from sqlalchemy import text
    from pa2.storage.database import PlanStepRecord
    from pa2.application.plan_service import PlanService
    db,project=database;service=PlanService(db);plan=sample_plan();plan.project_id=project.id
    service.save_draft(plan)
    with db.session() as session:
        row=session.query(PlanStepRecord).filter_by(plan_id=plan.id).one()
        row.camera_json={'mode':'TOP','roll_deg':0}
    with db.engine.begin() as conn:
        before=[tuple(row) for row in conn.execute(text('SELECT * FROM plan_steps'))]
        conn.execute(text('DROP TABLE plan_appearances'))
        conn.execute(text('DROP TABLE project_appearances'))
    db.initialize()
    with db.engine.connect() as conn:
        after=[tuple(row) for row in conn.execute(text('SELECT * FROM plan_steps'))]
    assert after==before
    loaded=service.load_current_draft(project.id)
    assert loaded.steps[0].camera_mode=='TOP' and not loaded.steps[0].material_auto
    assert loaded.custom_cameras=={} and loaded.display_names=={}
