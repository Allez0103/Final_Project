import copy
import pytest
from PySide6.QtCore import Qt,QSignalBlocker,QItemSelectionModel
from test_mentor_visuals import editor


def select(p,*keys):
    with QSignalBlocker(p.parts):
        p.parts.clearSelection()
        for item in p.parts.all_items():item.setSelected(item.data(Qt.UserRole) in keys)
    p._select_group()


def test_v44_checkbox_button_and_selected_group_agree(editor):
    p=editor;before=copy.deepcopy(p.plan.to_dict())
    select(p,'body:cover');child=next(i for i in p.parts.all_items() if i.data(Qt.UserRole)=='body:cover')
    child.setCheckState(0,Qt.Unchecked)
    assert p.visibility_button.isChecked() and p.visibility_button.toolTip()=='선택 부품 표시'
    select(p,'bolt');assert not p.visibility_button.isChecked()
    select(p,'cover');assert p.visibility_button.isChecked()
    p.visibility_button.click()
    assert 'cover' not in p.vtk_scene.hidden_body_ids and child.checkState(0)==Qt.Checked
    assert not p.visibility_button.isChecked() and p.plan.to_dict()==before


def test_v44_switching_selection_does_not_restore_previous_batch(editor):
    p=editor;select(p,'bolt');p.visibility_button.click()
    assert p.vtk_scene.hidden_body_ids=={'bolt'} and p.visibility_button.isChecked()
    select(p,'cover');assert not p.visibility_button.isChecked()
    p.visibility_button.click();assert p.vtk_scene.hidden_body_ids=={'bolt','cover'}
    select(p,'bolt');p.visibility_button.click()
    assert p.vtk_scene.hidden_body_ids=={'cover'}
    select(p);assert not p.visibility_button.isEnabled() and not p.visibility_button.isChecked()


def test_v44_mixed_multi_selection_and_partial_state(editor):
    p=editor;select(p,'body:cover');p.visibility_button.click()
    select(p,'bolt','cover')
    assert not p.visibility_button.isChecked() and '일부 숨김' in p.visibility_button.toolTip()
    p.visibility_button.click();assert {'bolt','cover'}<=p.vtk_scene.hidden_body_ids
    p.visibility_button.click()
    assert p.vtk_scene.hidden_body_ids=={'cover'}  # Cover was hidden independently.
    select(p,'body:cover');p.visibility_button.click();assert not p.vtk_scene.hidden_body_ids


def test_v44_sequence_card_selection_uses_the_same_visibility(editor):
    p=editor;select(p,'body:cover');p.visibility_button.click()
    p.order.setCurrentRow(0);p._order_selection();assert not p.visibility_button.isChecked()
    p.visibility_button.click();assert {'bolt','cover'}<=p.vtk_scene.hidden_body_ids
    p.order.setCurrentRow(1);p._order_selection();assert p.visibility_button.isChecked()
    p.visibility_button.click();assert p.vtk_scene.hidden_body_ids=={'bolt'}


@pytest.fixture
def tree_editor(tmp_path,monkeypatch):
    from test_v43_tree_recovery import runtime,named_step
    from pa2.settings.config import AppSettings
    from pa2.ui.main_window import ModelPage
    from pa2.application.appearance import AppearanceService
    from PySide6.QtWidgets import QApplication
    monkeypatch.setenv('QT_QPA_PLATFORM','offscreen')
    app=QApplication.instance() or QApplication([])
    layout,db,projects,plans,imports=runtime(tmp_path)
    project=projects.create('visibility','test','test');result=imports.prepare(project.id,named_step(tmp_path/'named.step'),[],AppSettings())
    page=ModelPage();page.set_result(result,AppSettings())
    page.body_visibility_changed.connect(lambda payload:AppearanceService(db).save_hidden(project.id,payload['hidden_body_ids'],visibility_batches=payload['visibility_batches']))
    yield page,project,db,imports
    page._stop_preview();page.play_timer.stop();page.thumbnail_timer.stop();page.close();page.vtk_scene.render_window.Finalize()


def test_v44_group_restore_preserves_individual_hide_after_reopen(tree_editor):
    p,project,db,imports=tree_editor
    group=next(g for g in p.result.snapshot.groups if g.label=='COVER');bid=group.body_ids[0]
    select(p,'body:'+bid);p.visibility_button.click()
    select(p,group.id);p.visibility_button.click();assert set(group.body_ids)<=p.vtk_scene.hidden_body_ids
    p.set_result(imports.reopen(project.id),p.settings)
    select(p,group.id);assert p.visibility_button.isChecked()
    p.visibility_button.click();assert p.vtk_scene.hidden_body_ids=={bid}
    child=next(i for i in p.parts.all_items() if i.data(Qt.UserRole)=='body:'+bid)
    select(p,'body:'+bid);child.setCheckState(0,Qt.Checked)
    assert not p.vtk_scene.hidden_body_ids and not p.visibility_button.isChecked()


def test_v44_regroup_keeps_individual_hide_and_targeted_restore(tree_editor):
    from pa2.application.manual_grouping import ManualGroupingService
    p,project,db,imports=tree_editor
    group=next(g for g in p.result.snapshot.groups if g.label=='COVER');bid=group.body_ids[0]
    base=next(g.id for g in p.result.snapshot.groups if g.label=='BASE')
    select(p,'body:'+bid);child=next(i for i in p.parts.all_items() if i.data(Qt.UserRole)=='body:'+bid);child.setCheckState(0,Qt.Unchecked)
    select(p,group.id);p.visibility_button.click()
    ManualGroupingService(db).change(p.result,[group.id,base],name='merged',base_id=base)
    p.set_result(imports.reopen(project.id),p.settings)
    merged=next(g for g in p.result.snapshot.groups if g.id.startswith('manual-'))
    select(p,merged.id);assert '일부 숨김' in p.visibility_button.toolTip()
    p.visibility_button.click();p.visibility_button.click()
    assert p.vtk_scene.hidden_body_ids==set(group.body_ids)
    # The previously hidden COVER remains an independent scope after merging.
    nested=next(i for i in p.parts.all_items() if i.data(Qt.UserRole)=='node:'+group.id)
    with QSignalBlocker(p.parts):p.parts.clearSelection();nested.setSelected(True)
    p._select_group();p.visibility_button.click()
    assert p.vtk_scene.hidden_body_ids=={bid}


def test_v44_child_checkbox_hit_box_and_paint(editor,tmp_path):
    from PySide6.QtWidgets import QApplication,QStyle,QStyleOptionViewItem
    from PySide6.QtTest import QTest
    p=editor;p.show();p.parts.item(2).setExpanded(True);QApplication.processEvents()
    child=next(i for i in p.parts.all_items() if i.data(Qt.UserRole)=='body:cover')
    p.parts.scrollToItem(child);QApplication.processEvents()
    index=p.parts.indexFromItem(child);opt=QStyleOptionViewItem();opt.initFrom(p.parts)
    opt.rect=p.parts.visualItemRect(child);p.parts.itemDelegate().initStyleOption(opt,index)
    rect=p.parts.style().subElementRect(QStyle.SE_ItemViewItemCheckIndicator,opt,p.parts)
    assert rect.width()==rect.height()==14 and p.parts.viewport().rect().contains(rect.center())
    p.parts.viewport().grab().save(str(tmp_path/'checkbox-before.png'))
    QTest.mouseClick(p.parts.viewport(),Qt.LeftButton,Qt.NoModifier,rect.center());QApplication.processEvents()
    assert child.checkState(0)==Qt.Unchecked and 'cover' in p.vtk_scene.hidden_body_ids
    p.parts.viewport().grab().save(str(tmp_path/'checkbox-after.png'))
