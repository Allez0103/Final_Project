import copy
from PySide6.QtCore import Qt,QSignalBlocker
from test_mentor_visuals import editor
from test_v44_visibility_sync import tree_editor,select
from pa2.ui.part_list import VISIBILITY_STATE


def group_item(page,gid):return next(page.parts.item(i) for i in range(page.parts.count()) if page.parts.item(i).data(Qt.UserRole)==gid)


def test_v45_regular_part_status_follows_checkbox_and_3d_button(editor):
    p=editor;before=copy.deepcopy(p.plan.to_dict());part=group_item(p,'cover')
    assert part.data(VISIBILITY_STATE)=='visible' and not part.icon(0).isNull()
    assert part.data(Qt.CheckStateRole) is None
    child=part.child(0);select(p,'body:cover');child.setCheckState(0,Qt.Unchecked)
    assert part.data(VISIBILITY_STATE)=='hidden' and '표시 0 / 전체 1' in part.toolTip(0)
    assert group_item(p,'bolt').data(VISIBILITY_STATE)=='visible'
    select(p,'cover');p.visibility_button.click()
    assert part.data(VISIBILITY_STATE)=='visible' and child.checkState(0)==Qt.Checked
    assert p.plan.to_dict()==before


def test_v45_partial_status_reopen_merge_and_ungroup(tree_editor):
    from pa2.application.manual_grouping import ManualGroupingService
    p,project,db,imports=tree_editor
    cover=next(g for g in p.result.snapshot.groups if g.label=='COVER');bid=cover.body_ids[0]
    base=next(g.id for g in p.result.snapshot.groups if g.label=='BASE')
    child=next(i for i in p.parts.all_items() if i.data(Qt.UserRole)=='body:'+bid)
    child.setCheckState(0,Qt.Unchecked)
    assert group_item(p,cover.id).data(VISIBILITY_STATE)=='partial'
    assert '일부 하위 부품 숨김' in group_item(p,cover.id).toolTip(0)
    select(p,cover.id);p.visibility_button.click()
    assert group_item(p,cover.id).data(VISIBILITY_STATE)=='hidden'
    p.visibility_button.click();assert group_item(p,cover.id).data(VISIBILITY_STATE)=='partial'
    p.set_result(imports.reopen(project.id),p.settings)
    assert group_item(p,cover.id).data(VISIBILITY_STATE)=='partial'
    service=ManualGroupingService(db)
    service.change(p.result,[cover.id,base],name='merged',base_id=base)
    p.set_result(imports.reopen(project.id),p.settings)
    merged=next(g for g in p.result.snapshot.groups if g.id.startswith('manual-'))
    assert group_item(p,merged.id).data(VISIBILITY_STATE)=='partial'
    assert '표시 2 / 전체 3' in group_item(p,merged.id).toolTip(0)
    service.change(p.result,[merged.id],ungroup=True,base_id=merged.id)
    p.set_result(imports.reopen(project.id),p.settings)
    assert group_item(p,cover.id).data(VISIBILITY_STATE)=='partial'
    assert group_item(p,base).data(VISIBILITY_STATE)=='visible'


def test_v45_status_icon_click_selects_without_hiding(editor):
    from PySide6.QtWidgets import QApplication,QStyle,QStyleOptionViewItem
    from PySide6.QtTest import QTest
    p=editor;p.show();QApplication.processEvents()
    item=group_item(p,'cover');p.parts.scrollToItem(item);QApplication.processEvents()
    index=p.parts.indexFromItem(item);opt=QStyleOptionViewItem();opt.initFrom(p.parts)
    opt.decorationSize=p.parts.iconSize()
    opt.rect=p.parts.visualItemRect(item);p.parts.itemDelegate().initStyleOption(opt,index)
    rect=p.parts.style().subElementRect(QStyle.SE_ItemViewItemDecoration,opt,p.parts)
    assert rect.isValid()
    QTest.mouseClick(p.parts.viewport(),Qt.LeftButton,Qt.NoModifier,rect.center())
    assert not p.vtk_scene.hidden_body_ids and item.data(VISIBILITY_STATE)=='visible'
    assert item.isSelected()
