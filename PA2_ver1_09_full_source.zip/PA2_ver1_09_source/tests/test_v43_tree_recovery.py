"""Real STEP occurrence import plus persisted manual recovery/visibility workflow."""
import copy
from dataclasses import replace
from pathlib import Path
import pytest
from test_mentor_visuals import editor


def named_step(path,*,surface=False):
    from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
    from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeFace
    from OCP.gp import gp_Pnt,gp_Trsf,gp_Vec,gp_Pln,gp_Dir
    from OCP.TDocStd import TDocStd_Document
    from OCP.TCollection import TCollection_ExtendedString
    from OCP.TDataStd import TDataStd_Name
    from OCP.XCAFDoc import XCAFDoc_DocumentTool
    from OCP.TopLoc import TopLoc_Location
    from OCP.STEPCAFControl import STEPCAFControl_Writer
    from OCP.STEPControl import STEPControl_AsIs
    from pa2.cad.shapes import compound
    doc=TDocStd_Document(TCollection_ExtendedString('BinXCAF'))
    tool=XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
    base=tool.AddShape(BRepPrimAPI_MakeBox(20,20,5).Shape(),False)
    TDataStd_Name.Set_s(base,TCollection_ExtendedString('BASE'))
    partshape=(BRepBuilderAPI_MakeFace(gp_Pln(gp_Pnt(0,0,0),gp_Dir(0,0,1)),0,10,0,10).Shape() if surface else
               compound([BRepPrimAPI_MakeBox(gp_Pnt(x,0,0),3,4,5).Shape() for x in (0,5)]))
    part=tool.AddShape(partshape,False);TDataStd_Name.Set_s(part,TCollection_ExtendedString('COVER'))
    sub=tool.NewShape();TDataStd_Name.Set_s(sub,TCollection_ExtendedString('SUB ASSEMBLY'))
    shift=gp_Trsf();shift.SetTranslation(gp_Vec(25,0,0))
    tool.AddComponent(sub,part,TopLoc_Location(shift))
    root=tool.NewShape();TDataStd_Name.Set_s(root,TCollection_ExtendedString('PRODUCT'))
    tool.AddComponent(root,base,TopLoc_Location());tool.AddComponent(root,sub,TopLoc_Location())
    shift2=gp_Trsf();shift2.SetTranslation(gp_Vec(0,30,0));tool.AddComponent(root,part,TopLoc_Location(shift2))
    tool.UpdateAssemblies();writer=STEPCAFControl_Writer();writer.SetNameMode(True)
    writer.Transfer(doc,STEPControl_AsIs);writer.Write(str(path));return path


def runtime(tmp_path):
    from pa2.cli import _runtime
    from pa2.application.import_service import ImportService
    from pa2.storage.assets import AssetStore
    from pa2.storage.cache import CacheStore
    from pa2.application.plan_service import PlanService
    layout,db,projects,imports=_runtime(tmp_path/'data')
    return layout,db,projects,PlanService(db),imports


def test_v43_named_nested_occurrences_and_multi_solid_parts(tmp_path):
    from pa2.cad.importer import StepImporter
    from pa2.cad.step_tree import groups_from_tree
    from pa2.storage.assets import sha256_file
    path=named_step(tmp_path/'nested.step');before=sha256_file(path)
    scene=StepImporter().read(path,before,'source.step')
    assert len(scene.bodies)==5
    assert not scene.recovery_required,scene.import_diagnostics
    assert scene.tree[0]['label']=='PRODUCT' and len(scene.tree[0]['children'])==3
    assert scene.tree[0]['children'][1]['children'][0]['label']=='COVER'
    groups=groups_from_tree(scene).groups
    assert sorted(len(g.body_ids) for g in groups)==[1,2,2]
    covers=[g for g in groups if g.display_name=='COVER']
    assert {tuple(g.bounds.center) for g in covers}=={(29.,2.,2.5),(4.,32.,2.5)}
    assert len({b.occurrence_path for b in scene.bodies})==3
    assert sha256_file(path)==before


def test_v43_surface_recovery_cache_and_auto_guard_persist(tmp_path):
    from pa2.settings.config import AppSettings
    from pa2.application.import_audit import recovery_reason
    from pa2.cad.brep_cache import load_scene,save_scene
    from pa2.planning.manual import ManualPlanner
    from pa2.video.renderer import VideoRenderer
    layout,db,projects,plans,imports=runtime(tmp_path)
    path=named_step(tmp_path/'surface.step',surface=True);original=path.read_bytes()
    project=projects.create('surface','test','test')
    result=imports.prepare(project.id,path,[],AppSettings())
    assert recovery_reason(result.snapshot,result.assembly_scene)
    assert result.assembly_scene.non_solid_count==2 and len(result.snapshot.groups)==3
    assert not result.snapshot.calculation_ready
    with pytest.raises(ValueError,match='수동생성'):imports.ensure_contacts(result,AppSettings())
    reopened=imports.reopen(project.id)
    assert recovery_reason(reopened.snapshot,reopened.assembly_scene)
    assert reopened.assembly_scene.tree==result.assembly_scene.tree
    groups=reopened.snapshot.groups;base=next(g.id for g in groups if g.label=='BASE')
    generated=ManualPlanner(AppSettings()).generate(project.id,1,reopened.snapshot.id,groups,[],reopened.assembly_scene.shapes,base)
    assert len(generated.assembly_plan.steps)==2 and generated.metrics['actual_native_path_calls']==0
    plan=generated.assembly_plan;plans.save_draft(plan);cid=plans.confirm(plan)
    assert plans.load_confirmation(cid).group_ids==plan.group_ids
    root=Path(__file__).resolve().parents[1]
    settings=replace(AppSettings(),video_width=320,video_height=180,video_fps=10,video_encoder='libx264',highlight_sec=.1,assembly_move_sec=.1,final_hold_sec=.1)
    video=VideoRenderer(settings,root/'assets/video_template_v1.json').render(plan,reopened.assembly_scene,groups,tmp_path/'recovered.mp4',vehicle_name='test',product_name='test',project_name='surface')
    assert video.path.is_file() and path.read_bytes()==original


def test_v43_explicit_definitions_take_precedence_and_hidden_survives_merge(tmp_path):
    from pa2.settings.config import AppSettings
    from pa2.application.appearance import AppearanceService
    from pa2.application.manual_grouping import ManualGroupingService
    layout,db,projects,plans,imports=runtime(tmp_path)
    path=named_step(tmp_path/'nested.step');project=projects.create('nested','test','test')
    result=imports.prepare(project.id,path,[],AppSettings())
    groups=result.snapshot.groups;bid=groups[1].body_ids[0]
    AppearanceService(db).save_hidden(project.id,[bid]);grouping=ManualGroupingService(db)
    grouping.change(result,[g.id for g in groups[:2]],name='manual',base_id=groups[0].id)
    merged=imports.reopen(project.id)
    assert next(b for b in merged.assembly_scene.bodies if b.id==bid).hidden
    manual=next(g for g in merged.snapshot.groups if g.id.startswith('manual-'))
    assert bid in manual.body_ids
    grouping.change(merged,[manual.id],ungroup=True,base_id=manual.id)
    restored=imports.reopen(project.id)
    assert next(b for b in restored.assembly_scene.bodies if b.id==bid).hidden
    assert {frozenset(g.body_ids) for g in restored.snapshot.groups}=={frozenset(g.body_ids) for g in groups}
    with pytest.raises(ValueError,match='자동 그룹'):
        grouping.change(restored,[restored.snapshot.groups[0].id],ungroup=True)


def test_v43_child_selection_hide_does_not_change_plan(editor):
    from PySide6.QtCore import Qt,QSignalBlocker
    p=editor;before=copy.deepcopy(p.plan.to_dict())
    root=next(p.parts.item(i) for i in range(p.parts.count()) if p.parts.item(i).data(Qt.UserRole)=='cover')
    child=root.child(0);assert child.data(Qt.UserRole)=='body:cover'
    with QSignalBlocker(p.parts):p.parts.clearSelection();child.setSelected(True)
    p._select_group()
    assert child.isSelected() and not p.group_button.isEnabled() and not p.apply_button.isEnabled()
    assert p.vtk_scene._selection_overlay_ids[0][1]=='body:cover'
    child.setCheckState(0,Qt.Unchecked)
    assert 'cover' in p.vtk_scene.hidden_body_ids and not p.vtk_scene.actors['cover'].GetVisibility()
    p._sync_selection({'bolt'})
    assert not p.vtk_scene.actors['cover'].GetVisibility()
    child.setCheckState(0,Qt.Checked)
    assert not p.vtk_scene.hidden_body_ids and p.vtk_scene.actors['cover'].GetVisibility()
    assert p.plan.to_dict()==before


def test_v43_explicit_part_files_keep_existing_matching_priority(tmp_path):
    from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
    from OCP.gp import gp_Pnt
    from OCP.STEPControl import STEPControl_Writer,STEPControl_AsIs
    from pa2.cad.shapes import compound
    from pa2.settings.config import AppSettings
    layout,db,projects,plans,imports=runtime(tmp_path)
    path=named_step(tmp_path/'assembly.step');part=tmp_path/'CUSTOM-COVER.step'
    writer=STEPControl_Writer();writer.Transfer(compound([BRepPrimAPI_MakeBox(gp_Pnt(x,0,0),3,4,5).Shape() for x in (0,5)]),STEPControl_AsIs);writer.Write(str(part))
    project=projects.create('explicit','test','test')
    result=imports.prepare(project.id,path,[part],AppSettings())
    matched=[g for g in result.snapshot.groups if g.part_definition_id]
    assert len(matched)==2 and all(g.display_name.startswith('CUSTOM-COVER') for g in matched)
    assert all(not g.id.startswith('group-step-') for g in result.snapshot.groups)
    assert sum(len(g.body_ids) for g in result.snapshot.groups)==5


def test_v43_mesh_failure_proxy_and_normal_reanalysis(monkeypatch,tmp_path):
    import pa2.rendering.vtk_scene as rendering
    from pa2.settings.config import AppSettings
    from pa2.application.import_audit import recovery_reason
    from pa2.application.manual_grouping import ManualGroupingService
    layout,db,projects,plans,imports=runtime(tmp_path)
    path=named_step(tmp_path/'mesh.step');before=path.read_bytes();project=projects.create('mesh','test','test')
    original=rendering.tessellate_shape
    def failed(shape,value):
        # Original BASE has this volume; the display proxy is a distinct shape.
        from pa2.cad.importer import _properties
        if abs((_properties(shape)[0] or 0)-2000)<1e-7:
            if shape not in failed.seen:failed.seen.append(shape)
            if shape.IsSame(failed.seen[0]):raise RuntimeError('injected display meshing failure')
        return original(shape,value)
    failed.seen=[];monkeypatch.setattr(rendering,'tessellate_shape',failed)
    result=imports.prepare(project.id,path,[],AppSettings())
    assert recovery_reason(result.snapshot,result.assembly_scene)
    proxy=next(b for b in result.assembly_scene.bodies if b.display_mode=='proxy')
    assert proxy.bounds.size==(20.,20.,5.) and result.assembly_scene.shapes[proxy.id].IsSame(failed.seen[0])
    assert path.read_bytes()==before
    monkeypatch.setattr(rendering,'tessellate_shape',original)
    reopened=imports.reopen(project.id)
    assert recovery_reason(reopened.snapshot,reopened.assembly_scene)
    assert next(b for b in reopened.assembly_scene.bodies if b.id==proxy.id).display_mode=='proxy'
    groups=reopened.snapshot.groups
    ManualGroupingService(db).change(reopened,[g.id for g in groups[:2]],name='recovered group',base_id=groups[0].id)
    assert recovery_reason(imports.reopen(project.id).snapshot)
    corrected=imports.prepare(project.id,path,[],AppSettings())
    # Geometry cache retains raw shapes; the failed display outcome belongs to
    # the old snapshot, so a fresh successful analysis may re-enable automatic mode.
    assert not recovery_reason(corrected.snapshot,corrected.assembly_scene)


def test_v43_null_body_cache_is_listed_and_can_be_manually_sequenced(tmp_path):
    from OCP.TopoDS import TopoDS_Shape
    from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
    from pa2.cad.brep_cache import save_scene,load_scene
    from pa2.cad.importer import CadScene
    from pa2.domain.models import AtomicBody,Bounds,AssemblyGroup,PartType
    from pa2.settings.config import AppSettings
    from pa2.planning.manual import ManualPlanner
    box=Bounds(0,0,0,10,10,10)
    valid=AtomicBody('base','hash','source',0,'/base','base',box,1000,600,box.center,True)
    absent=AtomicBody('missing','hash','source',1,'/missing','unconverted',Bounds(0,0,0,0,0,0),None,None,None,False,display_mode='missing')
    scene=CadScene(tmp_path/'source.step','hash','source','mm',[valid,absent],{'base':BRepPrimAPI_MakeBox(10,10,10).Shape(),'missing':TopoDS_Shape()},recovery_required=True)
    save_scene(scene,tmp_path/'cache');restored=load_scene(tmp_path/'cache',scene.source_path)
    assert len(restored.bodies)==2 and restored.shapes['missing'].IsNull() and restored.recovery_required
    groups=[AssemblyGroup(b.id,b.display_name,[b.id],PartType.UNKNOWN,b.bounds,b.volume_mm3,b.centroid,b.geometry_valid) for b in restored.bodies]
    result=ManualPlanner(AppSettings()).generate('p',1,'s',groups,[],restored.shapes,'base')
    assert len(result.assembly_plan.steps)==1 and result.assembly_plan.steps[0].group_id=='missing'


def test_v43_unreadable_step_does_not_invent_geometry(tmp_path):
    from pa2.cad.importer import StepImporter,CadImportError
    from pa2.storage.assets import sha256_file
    path=tmp_path/'broken.step';path.write_text('this is not a STEP file',encoding='utf-8')
    before=path.read_bytes()
    with pytest.raises(CadImportError):StepImporter().read(path,sha256_file(path),'source.step')
    assert path.read_bytes()==before


def test_v43_partial_root_transfer_is_diagnosed(monkeypatch,tmp_path):
    import pa2.cad.importer as importer
    from pa2.storage.assets import sha256_file
    original=importer.STEPControl_Reader
    class PartialReader:
        def __init__(self):self.real=original()
        def __getattr__(self,name):return getattr(self.real,name)
        def NbRootsForTransfer(self):return self.real.NbRootsForTransfer()+1
    monkeypatch.setattr(importer,'STEPControl_Reader',PartialReader)
    path=named_step(tmp_path/'partial.step')
    scene=importer.StepImporter().read(path,sha256_file(path),'source.step')
    assert scene.recovery_required and len(scene.bodies)==5
    report=next(d for d in scene.import_diagnostics if d['code']=='ROOT_TRANSFER_INCOMPLETE')
    assert report['expected']>report['transferred'] and report['recovery']


def test_v43_brep_write_failure_keeps_source_and_marks_proxy(monkeypatch,tmp_path):
    import pa2.cad.brep_cache as cache
    from pa2.cad.importer import StepImporter
    from pa2.storage.assets import sha256_file
    path=named_step(tmp_path/'cache.step');before=path.read_bytes()
    scene=StepImporter().read(path,sha256_file(path),'source.step')
    first=scene.bodies[0];shape=scene.shapes[first.id];write=cache.write_shape
    def fail_original(value,target):
        if value.IsSame(shape):raise RuntimeError('injected BREP serialization failure')
        write(value,target)
    monkeypatch.setattr(cache,'write_shape',fail_original)
    cache.save_scene(scene,tmp_path/'cache');restored=cache.load_scene(tmp_path/'cache',path)
    assert scene.recovery_required and restored.recovery_required and first.display_mode=='proxy'
    assert scene.shapes[first.id].IsSame(shape) and path.read_bytes()==before
    assert next(b for b in restored.bodies if b.id==first.id).display_mode=='proxy'

