"""Opt-in status icon checks over the complete tree/visibility GUI workflow."""
import copy,json,os,time
from pathlib import Path


def verify(window,output_dir):
    from .ui_verify_v44 import verify as visibility_workflow
    from .ui.part_list import VISIBILITY_STATE
    from PySide6.QtCore import Qt,QSignalBlocker,QItemSelectionModel
    from PySide6.QtWidgets import QApplication
    out=Path(output_dir);prior=visibility_workflow(window,out);checks=[];p=window.model_page
    def require(value,label):
        if not value:raise AssertionError(label)
        checks.append(label)
    def item(gid):return next(p.parts.item(i) for i in range(p.parts.count()) if p.parts.item(i).data(Qt.UserRole)==gid)
    def select(gid):
        with QSignalBlocker(p.parts):
            p.parts.clearSelection();item(gid).setSelected(True)
        p._select_group()
    group=next(g for g in window.import_result.snapshot.groups if g.label=='COVER' and set(g.body_ids)&p.vtk_scene.hidden_body_ids)
    bid=next(b for b in group.body_ids if b in p.vtk_scene.hidden_body_ids)
    base=next(g.id for g in window.import_result.snapshot.groups if g.label=='BASE')
    require(all(not p.parts.item(i).icon(0).isNull() for i in range(p.parts.count())),'Every regular part has a visibility status icon')
    require(item(group.id).data(VISIBILITY_STATE)=='partial' and '일부 하위 부품 숨김' in item(group.id).toolTip(0),'Partially hidden group has its own icon and tooltip')
    require(item(base).data(VISIBILITY_STATE)=='visible','Visible part icon remains independent')
    select(group.id);p.visibility_button.click()
    require(item(group.id).data(VISIBILITY_STATE)=='hidden','3D hide button updates regular part icon to hidden')
    p.visibility_button.click()
    require(item(group.id).data(VISIBILITY_STATE)=='partial','Group restore updates icon to partial while preserving individual hide')
    child=next(i for i in p.parts.all_items() if i.data(Qt.UserRole)=='body:'+bid)
    child.setCheckState(0,Qt.Checked)
    require(item(group.id).data(VISIBILITY_STATE)=='visible','Individual show immediately updates regular part icon')
    child.setCheckState(0,Qt.Unchecked)
    project=window.current_project
    window._reopen(next(x for x in window.projects.list() if x.id==project.id))
    deadline=time.monotonic()+90
    while window.thread and time.monotonic()<deadline:QApplication.processEvents();time.sleep(.005)
    require(window.thread is None and item(group.id).data(VISIBILITY_STATE)=='partial','Reopen restores visibility icons from saved body state')
    p.parts.expandAll();QApplication.processEvents();p.thumbnail_timer.stop()
    p.parts.viewport().grab().save(str(out/'part-visibility-icons.png'))
    window.grab().save(str(out/'part-visibility-editor.png'))
    icon_checks=len(checks)
    window._generate_manual(dict(base=base,display_order=[g.id for g in window.import_result.snapshot.groups]))
    deadline=time.monotonic()+90
    while window.thread and time.monotonic()<deadline:QApplication.processEvents();time.sleep(.005)
    require(p.plan is not None and p.order.count()>=2,'Reopened sequence supports a batch edit')
    p.order.setCurrentRow(1,QItemSelectionModel.ClearAndSelect)
    p.order.item(0).setSelected(True)
    require(p.apply_button.isEnabled() and not p.process.isEnabled(),'Batch editing enables Apply and locks process text')
    before=copy.deepcopy(p.plan.to_dict()['steps'])
    p.caution.setPlainText('일괄 주의사항 검증')
    p.apply_button.click()
    expected=copy.deepcopy(before)
    for step in expected[:2]:step['caution_text']='일괄 주의사항 검증'
    actual=p.plan.to_dict()['steps']
    for target,step in zip(expected[:2],actual[:2]):target['geometry_status']=step['geometry_status']
    require(actual==expected,'Batch apply updates the edited field on selected stages only')
    preview=p._step_preview
    require(preview and preview['time']==preview['timeline'].segments[0].camera_start and
            preview['end']==preview['timeline'].segments[0].move_end,'Batch preview plays only the earliest selected stage')
    p._history(False)
    require(p.plan.to_dict()['steps']==before,'Undo restores the entire batch')
    batch_checks=len(checks)-icon_checks
    if os.environ.get('PA2_SMOKE_PART_COLORS') == '1':
        verify_part_colors(window, out, require)
    color_checks=len(checks)-icon_checks-batch_checks
    if os.environ.get('PA2_SMOKE_MANUAL_VIEW') == '1':
        scene=p.vtk_scene
        action=next(a for a in p.view_action_group.actions() if a.text()=='등각')
        action.trigger()
        direction=scene.renderer.GetActiveCamera().GetDirectionOfProjection()
        interactor=p.vtk_widget.GetRenderWindow().GetInteractor()
        style=scene._interaction_style
        button='Right' if scene.swap_mouse_buttons else 'Left'
        interactor.SetEventInformation(100,100,0,0)
        style.InvokeEvent(button+'ButtonPressEvent')
        interactor.SetEventInformation(150,125,0,0)
        style.InvokeEvent('MouseMoveEvent')
        style.InvokeEvent(button+'ButtonReleaseEvent')
        require(p.views.currentIndex()==-1 and not action.isChecked(),'Mouse rotation clears the selected fixed viewpoint')
        action.trigger()
        actual=scene.renderer.GetActiveCamera().GetDirectionOfProjection()
        require(action.isChecked() and all(abs(a-b)<1e-8 for a,b in zip(actual,direction)),
                'The isometric preset can be selected again after rotation')
    report=dict(ok=True,verified_check_count=prior['verified_check_count']+len(checks),
        icon_check_count=icon_checks,batch_check_count=batch_checks,
        part_color_check_count=color_checks,manual_view_checks=len(checks)-icon_checks-batch_checks-color_checks,
        checks=checks,visibility_workflow=prior)
    (out/'part-visibility-workflow.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report


def verify_part_colors(window, output, require):
    import imageio_ffmpeg
    import numpy as np
    from PIL import Image
    from PySide6.QtCore import QPoint, Qt, QTimer
    from PySide6.QtGui import QColor
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QApplication, QColorDialog
    from .application.appearance import AppearanceService
    from .ui.part_list import BODY_COLORS, COLOR_COLUMN

    page = window.model_page
    project_id = window.current_project.id

    def wait():
        deadline = time.monotonic() + 120
        while window.thread and time.monotonic() < deadline:
            QApplication.processEvents()
            time.sleep(.005)
        require(window.thread is None, 'Color workflow background task completed')

    def color_hex(body_id):
        return QColor.fromRgbF(*page.vtk_scene.body_colors[body_id]).name()

    def click_swatch(body_id, hex_color):
        item = next(item for item in page.parts.all_items() if item.data(Qt.UserRole) == 'body:' + body_id)
        page.parts.expandAll()
        page.parts.scrollToItem(item)
        QApplication.processEvents()
        point = QPoint(page.parts.columnViewportPosition(COLOR_COLUMN) + 12, page.parts.visualItemRect(item).center().y())
        opened = []

        def accept_color():
            dialog = QApplication.activeModalWidget()
            if isinstance(dialog, QColorDialog):
                opened.append(True)
                dialog.setCurrentColor(QColor(hex_color))
                dialog.accept()

        QTimer.singleShot(100, accept_color)
        QTest.mouseClick(page.parts.viewport(), Qt.LeftButton, Qt.NoModifier, point)
        require(bool(opened), 'Clicking a body swatch opens the color picker')
        require(color_hex(body_id) == hex_color, 'Accepted color is reflected in the viewport palette')

    window.tabs.setCurrentIndex(1)
    base = next(group for group in window.import_result.snapshot.groups if group.label == 'BASE')
    covers = [group for group in window.import_result.snapshot.groups if group.label == 'COVER']
    first, second = covers[0].body_ids
    original = dict(page.vtk_scene.body_colors)
    green, purple = '#15ea35', '#f020c8'
    click_swatch(first, green)
    require(all(page.vtk_scene.body_colors[bid] == color for bid, color in original.items() if bid != first),
            'A body color change preserves the colors of every other body')
    window._change_grouping(dict(ids=[cover.id for cover in covers], name='색상 검증 그룹'))
    wait()
    merged = next(group for group in window.import_result.snapshot.groups if group.id.startswith('manual-'))
    require(color_hex(first) == green and all(page.vtk_scene.body_colors[bid] == original[bid]
            for bid in merged.body_ids if bid != first), 'Grouping retains each member color')
    click_swatch(second, purple)
    require(color_hex(first) == green, 'Sibling colors remain independent in a manual group')
    row = next(page.parts.item(i) for i in range(page.parts.count()) if page.parts.item(i).data(Qt.UserRole) == merged.id)
    require(len(row.data(COLOR_COLUMN, BODY_COLORS)) > 1, 'A group swatch indicates mixed colors')
    palette = AppearanceService(window.database).load(project_id)['body_colors']
    require({first, second} <= set(palette), 'Body colors are saved in project appearance data')
    window._reopen(next(project for project in window.projects.list() if project.id == project_id))
    wait()
    require(color_hex(first) == green and color_hex(second) == purple, 'Project reopen restores individual colors')
    page.parts.expandAll()
    window.grab().save(str(output/'body-color-editor.png'))

    window._generate_manual(dict(base=base.id, display_order=[group.id for group in window.import_result.snapshot.groups]))
    wait()
    window._confirm(page.plan)
    window._render()
    wait()
    require(bool(window.video_path and Path(window.video_path).is_file()), 'Colored grouped parts can be exported to MP4')
    stream = imageio_ffmpeg.read_frames(str(window.video_path))
    meta = next(stream)
    last_frame = None
    for last_frame in stream:
        pass
    require(last_frame is not None, 'Colored MP4 frames decode')
    image = Image.frombytes('RGB', meta['size'], last_frame)
    image.save(output/'body-color-video-frame.png')
    template = json.loads((window.app_root/'assets/video_template_v1.json').read_text(encoding='utf-8'))
    x, y, width, height = template['regions']['scene']
    pixels = np.asarray(image.crop((int(x*image.width), int(y*image.height),
                                    int((x+width)*image.width), int((y+height)*image.height))), dtype=np.int16)
    red, green_channel, blue = np.moveaxis(pixels, -1, 0)
    green_pixels = (green_channel > red+45) & (green_channel > blue+35)
    purple_pixels = (red > green_channel+45) & (blue > green_channel+35)
    require(np.count_nonzero(green_pixels) > 10 and np.count_nonzero(purple_pixels) > 10,
            'Final MP4 frame visibly contains both independently edited body colors')
    window._change_grouping(dict(ids=[merged.id], ungroup=True))
    wait()
    require(color_hex(first) == green and color_hex(second) == purple
            and len(window.import_result.snapshot.groups) == 3, 'Ungrouping retains both edited body colors')
