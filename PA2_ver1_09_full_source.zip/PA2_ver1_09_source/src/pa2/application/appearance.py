"""Project-local labels; imported classifier names/identities are never rewritten."""
import copy
import math
from pa2.storage.database import Project, ProjectAppearanceRecord


class AppearanceService:
    def __init__(self,database):self.database=database

    def load(self,project_id):
        with self.database.session() as session:
            row=session.get(ProjectAppearanceRecord,project_id)
            return copy.deepcopy(row.payload_json) if row else {}

    def apply_names(self,project_id,groups):
        names=self.load(project_id).get('display_names',{})
        for group in groups:group.user_display_name=names.get(group.id,'')
        return names

    def apply_bodies(self, project_id, scene):
        payload = self.load(project_id)
        hidden = set(payload.get('hidden_body_ids', []))
        colors = payload.get('body_colors', {})
        scene.body_color_overrides = {}
        for body in scene.bodies:
            body.hidden = body.id in hidden
            color = colors.get(body.id)
            if self._valid_color(color):
                scene.body_color_overrides[body.id] = tuple(color)

    @staticmethod
    def _valid_color(color):
        return isinstance(color, (tuple, list)) and len(color) == 3 and all(
            type(channel) in (int, float) and 0 <= channel <= 1 and math.isfinite(channel)
            for channel in color
        )

    def save_body_color(self, project_id, body_ids, color):
        from pa2.storage.database import AtomicBodyRecord

        if not self._valid_color(color):
            raise ValueError('유효한 RGB 색상이 아닙니다.')
        ids = set(body_ids)
        with self.database.session() as session:
            project = session.get(Project, project_id)
            if project is None:
                raise KeyError('프로젝트를 찾을 수 없습니다.')
            snapshot = project.current_snapshot_id
            if not snapshot or not ids or any(
                session.get(AtomicBodyRecord, f'{snapshot}:{body_id}') is None for body_id in ids
            ):
                raise ValueError('현재 모델에 없는 하위 부품입니다.')
            row = session.get(ProjectAppearanceRecord, project_id)
            if row is None:
                row = ProjectAppearanceRecord(project_id=project_id, payload_json={})
                session.add(row)
            payload = copy.deepcopy(row.payload_json or {})
            payload.setdefault('body_colors', {}).update({body_id: list(color) for body_id in ids})
            row.payload_json = payload

    def save_hidden(self,project_id,body_ids,*,visibility_batches=None):
        from sqlalchemy import select
        from pa2.storage.database import AtomicBodyRecord
        with self.database.session() as session:
            project=session.get(Project,project_id)
            if project is None:raise KeyError('프로젝트를 찾을 수 없습니다.')
            prefix=project.current_snapshot_id+':'
            valid={r.id.removeprefix(prefix) for r in session.scalars(select(AtomicBodyRecord).where(AtomicBodyRecord.snapshot_id==project.current_snapshot_id))}
            ids=set(body_ids)
            if ids-valid:raise ValueError('현재 모델에 없는 하위 부품입니다.')
            row=session.get(ProjectAppearanceRecord,project_id)
            if row is None:row=ProjectAppearanceRecord(project_id=project_id,payload_json={});session.add(row)
            payload=copy.deepcopy(row.payload_json or {});payload['hidden_body_ids']=sorted(ids)
            batches=visibility_batches if visibility_batches is not None else payload.get('visibility_batches',[])
            cleaned=[]
            for batch in batches:
                target=set(batch.get('body_ids',[]))&valid
                owned=set(batch.get('hidden_ids',[]))&target&ids
                if owned:cleaned.append(dict(body_ids=sorted(target),hidden_ids=sorted(owned)))
            payload['visibility_batches']=cleaned;row.payload_json=payload

    def rename(self,project_id,group_id,name):
        name=name.strip()
        if not name or len(name)>200 or any(ord(c)<32 for c in name):
            raise ValueError('부품 이름은 줄바꿈 없이 1~200자로 입력하세요.')
        with self.database.session() as session:
            project=session.get(Project,project_id)
            if project is None:raise KeyError('프로젝트를 찾을 수 없습니다.')
            from pa2.storage.database import AssemblyGroupRecord
            if not project.current_snapshot_id or session.get(AssemblyGroupRecord,project.current_snapshot_id+':'+group_id) is None:
                raise ValueError('현재 모델에 없는 부품입니다.')
            row=session.get(ProjectAppearanceRecord,project_id)
            if row is None:
                row=ProjectAppearanceRecord(project_id=project_id,payload_json={});session.add(row)
            payload=copy.deepcopy(row.payload_json or {})
            payload['display_names']=dict(payload.get('display_names',{}),**{group_id:name})
            row.payload_json=payload
        return name
