"""Persist recovery restrictions in the immutable snapshot's diagnostics JSON."""
from pa2.storage.database import ImportSnapshotRecord


def recovery_reason(snapshot,scene=None):
    report=next((d for d in getattr(snapshot,'diagnostics',[]) if d.get('code')=='IMPORT_AUDIT'),{})
    if report.get('recovery_required') or (scene and scene.recovery_required):
        return '오류 복구·강제 불러오기 상태입니다. 수동생성을 사용하세요. 정상 형상으로 다시 분석하면 자동생성을 사용할 수 있습니다.'
    return ''


def audit_record(scene):
    return dict(code='IMPORT_AUDIT',recovery_required=scene.recovery_required,tree=scene.tree,
        items=scene.import_diagnostics,body_display={b.id:dict(mode=b.display_mode,note=b.display_note) for b in scene.bodies})


def audit_display(scene,deflection):
    from pa2.rendering.vtk_scene import _display_mesh
    for body in scene.bodies:_display_mesh(scene,body.id,deflection)
    scene.import_diagnostics=[d for d in scene.import_diagnostics if d.get('code')!='DISPLAY_AUDIT']
    scene.import_diagnostics.append(dict(code='DISPLAY_AUDIT',body_count=len(scene.bodies),
        proxy_ids=[b.id for b in scene.bodies if b.display_mode=='proxy'],
        missing_ids=[b.id for b in scene.bodies if b.display_mode=='missing']))


def restore_audit(scene,diagnostics):
    row=next((d for d in diagnostics if d.get('code')=='IMPORT_AUDIT'),{})
    scene.recovery_required=scene.recovery_required or row.get('recovery_required',False)
    for body in scene.bodies:
        meta=row.get('body_display',{}).get(body.id,{})
        body.display_mode=meta.get('mode',body.display_mode);body.display_note=meta.get('note',body.display_note)


def persist_display_audit(database,result):
    snapshot=result.snapshot
    diagnostics=[d for d in snapshot.diagnostics if d.get('code')!='IMPORT_AUDIT']+[audit_record(result.assembly_scene)]
    with database.session() as session:
        row=session.get(ImportSnapshotRecord,snapshot.id)
        if row:
            row.diagnostics_json=diagnostics
            if result.assembly_scene.recovery_required:row.calculation_ready=False
    snapshot.diagnostics=diagnostics
    if result.assembly_scene.recovery_required:snapshot.calculation_ready=False
