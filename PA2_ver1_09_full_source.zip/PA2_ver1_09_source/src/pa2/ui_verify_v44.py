"""Opt-in native visibility synchronization and checkbox hit-test regression."""
import json,time
from pathlib import Path


def verify(window,output_dir):
    from .ui_verify_v43 import verify as tree_workflow
    from .application.appearance import AppearanceService
    from PySide6.QtWidgets import QApplication,QStyle,QStyleOptionViewItem
    from PySide6.QtCore import Qt,QSignalBlocker,QItemSelectionModel
    from PySide6.QtTest import QTest
    from PIL import Image
    out=Path(output_dir);prior=tree_workflow(window,out);checks=[]
    p=window.model_page;project=window.current_project
    def require(value,label):
        if not value:raise AssertionError(label)
        checks.append(label)
    def select(*keys):
        with QSignalBlocker(p.parts):
            p.parts.clearSelection()
            for item in p.parts.all_items():item.setSelected(item.data(Qt.UserRole) in keys)
        p._select_group();QApplication.processEvents()
    def wait():
        end=time.monotonic()+90
        while window.thread and time.monotonic()<end:QApplication.processEvents();time.sleep(.005)
        require(window.thread is None,'Project reopen task finished');QApplication.processEvents()
    groups=window.import_result.snapshot.groups
    cover=next(g for g in groups if g.label=='COVER');other=next(g for g in groups if g.label=='COVER' and g.id!=cover.id)
    base=next(g.id for g in groups if g.label=='BASE');bid=cover.body_ids[0]
    child=next(i for i in p.parts.all_items() if i.data(Qt.UserRole)=='body:'+bid)
    ancestor=child.parent()
    while ancestor:ancestor.setExpanded(True);ancestor=ancestor.parent()
    p.parts.scrollToItem(child);QApplication.processEvents()
    select('body:'+bid)
    index=p.parts.indexFromItem(child);option=QStyleOptionViewItem();option.initFrom(p.parts)
    option.rect=p.parts.visualItemRect(child);p.parts.itemDelegate().initStyleOption(option,index)
    rect=p.parts.style().subElementRect(QStyle.SE_ItemViewItemCheckIndicator,option,p.parts)
    require(rect.width()==rect.height()==14,'Native checkbox uses a 14px square hit target')
    QTest.mouseClick(p.parts.viewport(),Qt.LeftButton,Qt.NoModifier,rect.center());QApplication.processEvents()
    require(child.checkState(0)==Qt.Unchecked and bid in p.vtk_scene.hidden_body_ids,'Actual checkbox click hides the selected body')
    require(p.visibility_button.isChecked() and p.visibility_button.toolTip()=='선택 부품 표시','Individual checkbox updates 3D button state and label')
    select(base);require(not p.visibility_button.isChecked(),'Visible new selection changes button to hide')
    p.visibility_button.click();require(set(p.vtk_scene.group_body_ids[base])<=p.vtk_scene.hidden_body_ids,'Button hides current BASE without restoring previous child')
    select(other.id);require(not p.visibility_button.isChecked(),'Another visible part also updates button')
    p.visibility_button.click();require(set(other.body_ids)<=p.vtk_scene.hidden_body_ids and bid in p.vtk_scene.hidden_body_ids,'Second selected group is hidden without affecting prior hides')
    select(base);require(p.visibility_button.isChecked(),'Re-selecting hidden part changes button to show')
    p.visibility_button.click();require(not set(p.vtk_scene.group_body_ids[base])&p.vtk_scene.hidden_body_ids and set(other.body_ids)<=p.vtk_scene.hidden_body_ids,'Show affects only currently selected BASE')
    select('body:'+bid);p.visibility_button.click()
    require(child.checkState(0)==Qt.Checked and bid not in p.vtk_scene.hidden_body_ids,'3D button restores child and updates checkbox')
    select();require(not p.visibility_button.isEnabled() and not p.visibility_button.isChecked(),'No selection disables button instead of restoring a previous batch')
    select(other.id);p.visibility_button.click();require(not p.vtk_scene.hidden_body_ids,'Previously hidden group can be restored through current selection')
    select('body:'+bid);child.setCheckState(0,Qt.Unchecked)
    select(cover.id);require(not p.visibility_button.isChecked() and '일부 숨김' in p.visibility_button.toolTip(),'Partially hidden group is represented explicitly')
    p.visibility_button.click();require(set(cover.body_ids)<=p.vtk_scene.hidden_body_ids,'Partially hidden group can hide its remaining sibling')
    payload=AppearanceService(window.database).load(project.id)
    require(bool(payload['visibility_batches']),'Group-origin restore scope saved with project visibility')
    window._reopen(next(x for x in window.projects.list() if x.id==project.id));wait()
    select(cover.id);require(p.visibility_button.isChecked(),'Button reflects hidden group immediately after reopen')
    p.visibility_button.click();require(p.vtk_scene.hidden_body_ids=={bid},'Restore after reopen preserves earlier individual hidden body')
    p.thumbnail_timer.stop();p.parts.expandAll();QApplication.processEvents()
    window.grab().save(str(out/'visibility-sync.png'))
    p.parts.viewport().grab().save(str(out/'checkboxes.png'))
    Image.fromarray(p.vtk_scene.rgb_array()).save(out/'visibility-sync-scene.png')
    report=dict(ok=True,verified_check_count=prior['verified_check_count']+len(checks),
        visibility_check_count=len(checks),checks=checks,tree_workflow=prior)
    (out/'visibility-sync-workflow.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report
