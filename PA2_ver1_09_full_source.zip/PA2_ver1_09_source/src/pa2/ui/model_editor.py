"""PILOT-style horizontal sequence editor; manual edits never call CAD checks."""
import copy
import time
from dataclasses import replace
from PySide6.QtCore import Qt, QSize, Signal, QSignalBlocker, QItemSelectionModel, QTimer, QEvent
from PySide6.QtGui import QIcon, QImage, QPixmap, QAction, QActionGroup
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,QFormLayout, QSplitter,
    QLabel, QPushButton, QListWidget, QAbstractItemView, QSlider,
    QGroupBox, QScrollArea, QFrame, QMenu, QToolButton, QTabWidget, QMessageBox, QApplication,QSizePolicy)
from pa2.domain.models import GeometryStatus, MatchingStatus
from .group_dialog import ManualGroupDialog
from .generation_record import DetailMessage,GenerationRecordDialog
from .input_widgets import ScrollSafeComboBox as QComboBox,ScrollSafeSpinBox as QSpinBox
from pa2.rendering.scene import (build_timeline, scene_at, camera_view_key,
                                 shared_camera_roll, set_shared_camera_roll)
from .transport import configure_transport, update_play_button
from .viewport import ModelViewport, ViewportMenuButton, configure_viewport_button, viewport_icon


from .sequence_cards import SequenceCards


def enhanced_model_page(legacy):
    class ModelEditor(legacy):
        save_requested = Signal(object)
        manual_requested = Signal(object)
        grouping_requested = Signal(object)
        edit_state_changed = Signal()
        rename_requested = Signal(str,str)
        body_visibility_changed = Signal(object)

        def __init__(self):
            super().__init__()
            self._syncing = False; self._undo = []; self._redo = []; self._icons = {}
            self._step_preview = None
            self._play_clock=None;self._preview_clock=None
            self._part_isolation_snapshot = None
            self._visibility_restore = None
            self._visibility_batches = {}
            self._timeline_focus = False
            self._timeline_edit_state = None
            self._pending_custom_camera = None
            self._batch_fields = set()
            self.configuration_stale=False;self._base_editing=False;self._base_selected=False
            self._base_click_modifiers=Qt.NoModifier;self._selection_modifiers=Qt.NoModifier
            self._edit_epoch=0;self._signature_cache=None;self._timeline_cache=None
            self.selection_sync_count=0
            self._card_seek_on_click=False;self._action_issue='';self._recent_summary='최근 생성 기록이 없습니다.'
            self._recent_metrics={};self.generation_dialog=None
            self.parts.rename_requested.connect(self.rename_requested.emit)
            self.parts.body_visibility_requested.connect(self._set_body_visibility)
            self.preview_timer=QTimer(self); self.preview_timer.timeout.connect(self._preview_tick)
            self.thumbnail_timer=QTimer(self); self.thumbnail_timer.timeout.connect(self._next_thumbnail)
            self._legacy_container = QWidget(self)
            self._legacy_container.setLayout(self.layout()); self._legacy_container.hide()
            self.status=DetailMessage(self._legacy_container);self.status.hide()
            root = QVBoxLayout(self); root.setContentsMargins(16,10,16,8); root.setSpacing(8)
            bar = QHBoxLayout(); self.project_heading=QLabel('모델 · 조립 순서 편집'); bar.addWidget(self.project_heading); bar.addStretch()
            self.auto_generate = QPushButton('자동생성'); self.auto_generate.setProperty('primary', True)
            self.auto_generate.clicked.connect(lambda: self.plan_requested.emit(self.base.currentData() or ''))
            self.manual_generate = QPushButton('수동생성')
            self.manual_generate.setToolTip('목록 순서로 즉시 배치 · 일반 부품 분해 +Z 기본값 · 경로 검사 생략')
            self.manual_generate.clicked.connect(lambda: self.manual_requested.emit({
                'base': self.base.currentData() or '',
                'display_order': [self.parts.item(i).data(Qt.UserRole) for i in range(self.parts.count())]}))
            bar.addWidget(self.auto_generate); bar.addWidget(self.manual_generate); root.addLayout(bar)
            split = QSplitter(Qt.Horizontal)
            left = QFrame();left.setObjectName('whiteCard');left.setMinimumWidth(200)
            ll = QVBoxLayout(left);ll.setContentsMargins(14,12,14,12);ll.setSpacing(12)
            self.parts_heading=QLabel('부품 목록');self.parts_heading.setProperty('cardTitle',True)
            ll.addWidget(self.parts_heading);ll.addWidget(self.search);ll.addWidget(self.parts)
            self.parts.setSelectionMode(QAbstractItemView.ExtendedSelection)
            self.parts.setToolTip('Ctrl/Shift 다중선택: 선택 부품은 빨간색, 나머지는 회색·투명도 90%로 표시합니다. 직접 숨긴 부품은 유지됩니다.')
            grouping=QHBoxLayout()
            self.group_button=QPushButton('그룹화');self.ungroup_button=QPushButton('그룹해제')
            self.group_button.clicked.connect(self._group_selected);self.ungroup_button.clicked.connect(self._ungroup_selected)
            grouping.addWidget(self.group_button);grouping.addWidget(self.ungroup_button);ll.addLayout(grouping)
            center = QWidget(); cl = QVBoxLayout(center); cl.setContentsMargins(6,0,6,0); cl.setSpacing(6)
            self.orbit = QPushButton('회전'); self.pan = QPushButton('이동')
            self.orbit.setCheckable(True); self.pan.setCheckable(True); self.orbit.setChecked(True)
            self.orbit.clicked.connect(lambda: self._navigation(False)); self.pan.clicked.connect(lambda: self._navigation(True))
            self.views = QComboBox(); self.views.addItems(['등각','상면','하면','정면','후면','좌측','우측'])
            self.views.setParent(self._legacy_container)
            self.views.currentTextChanged.connect(self._view)
            self.viewer_surface=ModelViewport(self.vtk_widget)
            tools=self.viewer_surface.tools
            old_fit=self.fit_button;old_fit.hide();old_fit.deleteLater()
            self.fit_button=QPushButton(self.viewer_surface.toolbar)
            self.fit_button.clicked.connect(self.vtk_scene.fit)
            self.viewport_buttons={}
            for button,name,title in ((self.orbit,'rotate','회전'),(self.pan,'pan','이동'),(self.fit_button,'fit','화면 맞춤')):
                configure_viewport_button(button,name,title);tools.addWidget(button);self.viewport_buttons[name]=button
            self.view_menu_button=ViewportMenuButton();configure_viewport_button(self.view_menu_button,'view','시점 선택')
            menu=QMenu(self.view_menu_button);group=QActionGroup(menu);group.setExclusive(True)
            self.view_action_group=group
            for name in ('등각','상면','하면','정면','후면','좌측','우측'):
                action=QAction(name,menu);action.setCheckable(True);action.setChecked(name=='등각');group.addAction(action);menu.addAction(action)
                action.triggered.connect(lambda checked,n=name:self._activate_view(n))
                self.views.currentTextChanged.connect(lambda value,a=action:a.setChecked(a.text()==value))
            self.view_menu_button.setMenu(menu);tools.addWidget(self.view_menu_button);self.viewport_buttons['view']=self.view_menu_button
            for name,title,factor in [('zoom_out','축소',.8),('zoom_in','확대',1.25)]:
                button=QPushButton();configure_viewport_button(button,name,title)
                button.clicked.connect(lambda _,f=factor:self.vtk_scene.zoom(f));tools.addWidget(button);self.viewport_buttons[name]=button
            self.visibility_button=QPushButton();configure_viewport_button(self.visibility_button,'show','선택 부품 숨기기')
            self.visibility_button.setCheckable(True);self.visibility_button.setObjectName('visibilityToggle')
            self._visibility_icons={False:viewport_icon('show'),True:viewport_icon('hide')}
            self.visibility_button.clicked.connect(self._toggle_part_visibility)
            tools.addWidget(self.visibility_button);self.viewport_buttons['visibility']=self.visibility_button
            viewer=self.viewer_card=QFrame();viewer.setObjectName('whiteCard')
            vl=QVBoxLayout(viewer);vl.setContentsMargins(6,6,6,8);vl.setSpacing(6)
            vl.addWidget(self.viewer_surface,1);cl.addWidget(viewer,1)
            playback_widget=self.playback_bar=QWidget();playback_widget.setObjectName('playbackBar')
            playback=QGridLayout(playback_widget);playback.setContentsMargins(8,4,8,4);playback.setSpacing(4)
            self.playback_controls=QWidget();self.playback_controls.setSizePolicy(QSizePolicy.Fixed,QSizePolicy.Fixed)
            transport=QHBoxLayout(self.playback_controls);transport.setContentsMargins(0,0,0,0);transport.setSpacing(4)
            self.first_button=QPushButton(); self.previous_button=QPushButton()
            self.next_button=QPushButton(); self.last_button=QPushButton()
            for button,name,tooltip in ((self.first_button,'first','처음으로'),(self.previous_button,'previous','이전 단계'),
                                        (self.next_button,'next','다음 단계'),(self.last_button,'last','끝으로')):
                configure_transport(button,name,tooltip)
            self.first_button.clicked.connect(lambda:self._jump_end(False))
            self.previous_button.clicked.connect(lambda:self._neighbor(-1))
            self.next_button.clicked.connect(lambda:self._neighbor(1))
            self.last_button.clicked.connect(lambda:self._jump_end(True))
            update_play_button(self.play,False)
            for button in (self.first_button,self.previous_button,self.play,self.next_button,self.last_button):transport.addWidget(button)
            self.time_label=QLabel('0.0 / 0.0s');self.time_label.setProperty('muted',True)
            self.time_label.setMinimumWidth(0);self.time_label.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred)
            transport.addWidget(self.speed)
            self.speed.setFixedWidth(62); self.speed.setToolTip('재생 배속')
            transport.addWidget(QLabel('×'))
            self.playback_state=QLabel('완성 형상');self.playback_state.setProperty('muted',True)
            self.playback_state.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
            self.playback_state.setMinimumWidth(0);self.playback_state.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred)
            playback.addWidget(self.time_label,0,0);playback.addWidget(self.playback_controls,0,1,Qt.AlignCenter)
            playback.addWidget(self.playback_state,0,2);playback.setColumnStretch(0,1);playback.setColumnStretch(2,1)
            self.speed.setCurrentText('1')
            self.scrubber=QSlider(Qt.Horizontal);self.scrubber.setRange(0,10000);self.scrubber.valueChanged.connect(self._scrub_seek)
            self.playback_card=QFrame();self.playback_card.setObjectName('whiteCard')
            playback_box=QVBoxLayout(self.playback_card);playback_box.setContentsMargins(6,4,6,8);playback_box.setSpacing(6)
            playback_box.addWidget(playback_widget);playback_box.addWidget(self.scrubber);cl.addWidget(self.playback_card)
            right=QWidget(); right.setObjectName('propertiesBody'); form=QFormLayout(right)
            self.properties_tabs=QTabWidget()
            self.base_assign=QPushButton('선택 부품을 기준으로 지정'); self.base_assign.clicked.connect(self._assign_base)
            self.exception_add=QPushButton('선택 → 예외 지정'); self.exception_add.clicked.connect(lambda:self._set_selected_exceptions(True))
            self.exception_remove=QPushButton('선택 예외 해제'); self.exception_remove.clicked.connect(lambda:self._set_selected_exceptions(False))
            form.addRow('기준 부품',self.base); form.addRow(self.base_assign); form.addRow(self.exception_button)
            role_buttons=QHBoxLayout(); role_buttons.addWidget(self.exception_add); role_buttons.addWidget(self.exception_remove); form.addRow(role_buttons)
            form.addRow('분해 방향',self.direction); form.addRow('거리',self.distance)
            self._standard_cameras=[self.camera.itemText(i) for i in range(self.camera.count())]
            self._refresh_camera_options()
            self.camera_capture_button=QPushButton()
            configure_viewport_button(self.camera_capture_button,'camera','현재 3D 앵글 캡처')
            self.camera_capture_button.clicked.connect(self._capture_custom_camera)
            self.camera_capture_button.setEnabled(False)
            self.camera_capture_button.setToolTip('사용자 지정 선택 → 3D 회전 → 캡처 → 미리보기 & 적용')
            camera_row=QHBoxLayout();camera_row.addWidget(self.camera,1);camera_row.addWidget(self.camera_capture_button)
            form.addRow('카메라',camera_row)
            self._camera_roll_deg=0
            roll_row=QHBoxLayout()
            self.camera_roll_left=QPushButton('↶ 90°');self.camera_roll_right=QPushButton('↷ 90°')
            self.camera_roll_label=QLabel('0°')
            for button,delta,label in ((self.camera_roll_left,-90,'화면 왼쪽으로 90도 회전'),
                                      (self.camera_roll_right,90,'화면 오른쪽으로 90도 회전')):
                button.setToolTip(label+' · 모델/조립 방향은 유지 · 미리보기로 확인 후 적용')
                button.setAccessibleName(label)
                button.clicked.connect(lambda checked=False,d=delta:self._rotate_camera(d))
                roll_row.addWidget(button)
            roll_row.addWidget(self.camera_roll_label);form.addRow('화면 회전',roll_row)
            self.camera_roll_label.setToolTip('같은 시점을 사용하는 모든 단계에 공통 적용합니다. AUTO도 실제 6축 시점을 공유합니다.\n영상은 첫 실제 조립 단계의 시점으로 시작하며, 그 시점은 모델이 가로로 보이도록 추가 자동 보정됩니다.')
            self.camera.currentTextChanged.connect(self._camera_mode_changed)
            motion_scroll=QScrollArea();motion_scroll.setWidgetResizable(True);motion_scroll.setWidget(right)
            self.properties_tabs.addTab(motion_scroll,'동작설정')
            guide=QWidget();guide.setObjectName('propertiesBody');guide_form=QFormLayout(guide)
            for title,widget in [('조립 과정',self.process),('자재정보',self.material),('주의사항',self.caution)]:
                widget.setMaximumHeight(92); guide_form.addRow(title,widget)
            for widget in (self.process,self.material,self.caution):widget.installEventFilter(self)
            guide_scroll=QScrollArea();guide_scroll.setWidgetResizable(True);guide_scroll.setWidget(guide)
            self.properties_tabs.addTab(guide_scroll,'작업 안내')
            self.apply_button=QPushButton('미리보기 && 적용');self.apply_button.setAccessibleName('미리보기 & 적용');self.apply_button.setProperty('primary',True)
            self.apply_button.clicked.connect(self._apply_and_preview)
            self.apply_button.setToolTip('선택 단계의 동작·안내를 저장하고 재생합니다. 순서 확정은 별도이며 CAD 간섭 재검사는 하지 않습니다.')
            self.step_preview_button=self.apply_button  # one physical control, compatibility alias
            properties=QFrame();properties.setObjectName('whiteCard');properties.setMinimumWidth(310);properties.setMaximumWidth(365)
            properties_layout=QVBoxLayout(properties);properties_layout.setContentsMargins(14,12,14,12);properties_layout.setSpacing(12)
            self.properties_heading=QLabel('작업 속성');self.properties_heading.setProperty('cardTitle',True)
            properties_layout.addWidget(self.properties_heading);properties_layout.addWidget(self.properties_tabs,1)
            properties_layout.addWidget(self.apply_button)
            split.addWidget(left); split.addWidget(center); split.addWidget(properties); split.setSizes([215,920,345]); root.addWidget(split,1)
            self.order=SequenceCards(); self.order.currentItemChanged.connect(self._edit_step)
            self.order.itemSelectionChanged.connect(self._order_selection); self.order.itemChanged.connect(self._checked)
            self.order.itemClicked.connect(self._card_clicked)
            self.order.reordered.connect(self._reordered)
            self.order.drag_started.connect(self._pause_for_card_drag)
            stepsbox=self.sequence_card=QFrame();stepsbox.setObjectName('whiteCard')
            steps_layout=QVBoxLayout(stepsbox);steps_layout.setContentsMargins(14,12,14,12);steps_layout.setSpacing(12)
            self.sequence_heading=QLabel('조립 순서');self.sequence_heading.setProperty('cardTitle',True)
            steps_layout.addWidget(self.sequence_heading)
            actions=QHBoxLayout()
            self.selection_label=QLabel('0개 선택'); actions.addWidget(self.selection_label); actions.addStretch()
            self.undo_button=QPushButton('실행 취소'); self.undo_button.clicked.connect(lambda:self._history(False))
            self.redo_button=QPushButton('다시 실행'); self.redo_button.clicked.connect(lambda:self._history(True))
            for b in (self.undo_button,self.redo_button):actions.addWidget(b)
            saved_label=QLabel('초안·편집 자동 저장');saved_label.setProperty('muted',True);actions.addWidget(saved_label)
            confirm=self.confirm_button=QPushButton('순서 확정'); confirm.setProperty('primary',True); confirm.clicked.connect(lambda:self.confirm_requested.emit(self.plan) if self.plan and not self.configuration_stale else None); actions.addWidget(confirm)
            cards=QHBoxLayout()
            self.base_card=QToolButton();self.base_card.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
            self.base_card.setObjectName('baseSequenceCard');self.base_card.setCheckable(True)
            self.base_card.setFixedSize(170,148);self.base_card.setIconSize(QSize(105,62))
            self.base_card.setToolTip('첫 단계 · 기준 부품 배치 · 고정 위치, 이동/순서 변경 없음')
            self.base_card.clicked.connect(self._show_base_step);self.base_card.hide()
            self._order_viewport=self.order.viewport()
            self.base_card.installEventFilter(self);self._order_viewport.installEventFilter(self)
            cards.addWidget(self.base_card);cards.addWidget(self.order,1)
            steps_layout.addLayout(cards); steps_layout.addLayout(actions)
            move=QHBoxLayout()
            for text,fn in [('전체 선택',self.order.selectAll),('현재 부품만',self._single),('앞으로',lambda:self._move(-1)),('뒤로',lambda:self._move(1))]:
                b=QPushButton(text); b.clicked.connect(fn); move.addWidget(b)
            move.addWidget(QLabel('묶음 시작 단계')); self.position=QSpinBox(); self.position.setMinimum(1); move.addWidget(self.position)
            jump=QPushButton('이동'); jump.clicked.connect(lambda:self.order.move_selection(self.position.value()-1)); move.addWidget(jump)
            preview=QPushButton('미리보기 갱신'); preview.clicked.connect(self.preview); move.addWidget(preview)
            self.diagnostics_button.hide()  # Keep diagnostic collection, not a user-facing control.
            steps_layout.addLayout(move)
            root.addWidget(stepsbox)
            footer=QHBoxLayout();self.state_label=QLabel('순서를 생성하세요.');self.state_label.setWordWrap(False)
            self.state_label.setMinimumWidth(0);self.state_label.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred)
            footer.addWidget(self.state_label,1)
            self.issue_button=QPushButton();self.issue_button.hide();self.issue_button.clicked.connect(self._show_generation_record)
            self.generation_button=QPushButton('생성 기록');self.generation_button.clicked.connect(self._show_generation_record)
            footer.addWidget(self.issue_button);footer.addWidget(self.generation_button);root.addLayout(footer)
            self.import_audit_button=QPushButton('불러오기 진단');self.import_audit_button.clicked.connect(self._show_import_audit)
            footer.insertWidget(0,self.import_audit_button)
            self.status.changed.connect(self._status_notice)
            if not self.headless:
                self.vtk_scene.configure_interaction(self.vtk_widget.GetRenderWindow().GetInteractor(),self._picked,
                    self.vtk_widget,on_rotate=self._manual_view_rotation)
            self.base.currentIndexChanged.connect(self._base_changed)
            for field, signal in (
                ('direction',self.direction.currentTextChanged), ('direction',self.direction.activated),
                ('distance',self.distance.valueChanged), ('distance',self.distance.lineEdit().textEdited),
                ('camera',self.camera.currentIndexChanged), ('camera',self.camera.activated),
                ('process',self.process.textChanged), ('material',self.material.textChanged),
                ('caution',self.caution.textChanged),
            ):
                signal.connect(lambda *_, name=field: self._field_edited(name))
            self._update_group_buttons()
            self._sync_playback()

        def _notify_edit(self,*_):
            if not self._syncing:self.edit_state_changed.emit()

        def _field_edited(self,field):
            if self._syncing:return
            if field!='process' and len(self._selected_steps())>1:
                self._batch_fields.add(field)
            self._notify_edit()

        def _selected_steps(self):
            if not self.plan or self.configuration_stale or self._base_selected:return []
            ids={item.data(Qt.UserRole) for item in self.order.selectedItems()}
            if any(item.data(Qt.UserRole) not in ids for item in self.parts.selectedItems()):return []
            return [step for step in self.plan.steps if step.group_id in ids]

        def eventFilter(self,watched,event):
            if watched is getattr(self,'base_card',None) and event.type()==QEvent.MouseButtonPress:
                self._base_click_modifiers=event.modifiers()
            if watched is getattr(self,'_order_viewport',None):
                if event.type()==QEvent.MouseButtonPress:
                    self._selection_modifiers=event.modifiers()
                    self._card_seek_on_click=bool(event.button()==Qt.LeftButton and not event.modifiers())
                elif event.type()==QEvent.MouseButtonRelease:self._selection_modifiers=Qt.NoModifier
            if watched in (self.process,self.material,self.caution) and event.type()==QEvent.FocusIn:
                self.play_timer.stop();self._stop_preview();self._sync_playback()
            return super().eventFilter(watched,event)

        def set_configuration_state(self,stale):
            was_stale=self.configuration_stale
            self.configuration_stale=bool(stale)
            self.order.setEnabled(not stale);self.base_card.setEnabled(not stale)
            self.order.setDragEnabled(not stale)
            self.confirm_button.setEnabled(bool(self.plan) and not stale)
            if stale:
                self._stop_preview();self.play_timer.stop();self._base_editing=False
                for w in (self.direction,self.distance,self.camera,self.camera_roll_left,self.camera_roll_right,
                          self.process,self.material,self.caution,self.apply_button):w.setEnabled(False)
                self.status.setText('구성 변경 · 이전 구성 순서는 참고용입니다. 설정을 마친 뒤 순서를 다시 생성하세요.')
            self.order.setToolTip('이전 구성 · 참고용 · 현재 구성과 달라 재생성해야 합니다.' if stale else '')
            self._sync_camera_capture();self._sync_playback()
            if was_stale and not stale:self._order_selection()

        def set_recent_generation(self,record):
            if not record:
                self._recent_summary='최근 생성 기록이 없습니다.';self._recent_metrics={}
            else:
                m=record.metrics_json or {};self._recent_metrics=dict(m)
                mode='수동생성' if record.generation_mode=='manual' else '자동생성'
                seconds=m.get('generation_wall_sec',m.get('elapsed_sec',0));steps=len((record.plan_snapshot_json or {}).get('steps',[]))
                self._recent_summary=(f"생성 방식: {mode}\n생성 시간: {seconds:.1f}초\n후보 수: {m.get('tested_candidates',0)}개\n"
                    f"신규 경로 검사 수: {m.get('native_path_calls',0)}회\n생성 단계 수: {steps}단계\n"
                    f"생성 당시 미해결 일반부품: {m.get('unresolved_general_steps',0)}개")
            self._refresh_generation_details()

        def _status_notice(self,text,issue=False):
            self._action_issue=text if issue else ''
            self.state_label.setToolTip(text);self._refresh_generation_details()

        def _refresh_generation_details(self):
            if not hasattr(self,'issue_button'):return
            names={g.id:g.label for g in self.result.snapshot.groups} if self.result else {}
            issues=[]
            if self.plan:
                for step in self.plan.steps:
                    if step.geometry_status in (GeometryStatus.DRAFT_UNRESOLVED,GeometryStatus.SUPPORT_UNVERIFIED):
                        label='경로 확인 필요' if step.geometry_status==GeometryStatus.DRAFT_UNRESOLVED else '지지 확인 필요'
                        issues.append(label+' · '+names.get(step.group_id,step.group_id))
            elif self._recent_metrics.get('unresolved_general_steps',0):
                issues.append(f"미해결 일반부품 {self._recent_metrics['unresolved_general_steps']}개")
            if self._action_issue:issues.append(self._action_issue)
            self.issue_button.setVisible(bool(issues));self.issue_button.setText(f'확인 필요 {len(issues)}개')
            self.generation_button.setToolTip(self._recent_summary)
            if self.generation_dialog:
                self.generation_dialog.update_record(self._recent_summary,issues,self.status.text(),getattr(self,'diagnostics_text',''))

        def _show_generation_record(self):
            if self.generation_dialog is None:self.generation_dialog=GenerationRecordDialog(self)
            self._refresh_generation_details();self.generation_dialog.show();self.generation_dialog.raise_();self.generation_dialog.activateWindow()

        def signature(self):
            key=(id(self.plan),self._edit_epoch)
            if not self._signature_cache or self._signature_cache[0]!=key:
                from pa2.application.plan_service import PlanService
                self._signature_cache=(key,PlanService.content_signature(self.plan))
            return self._signature_cache[1]

        def _changed(self):
            self._edit_epoch+=1;self._timeline_cache=None;self._signature_cache=None
            self._refresh_generation_details()

        def _timeline(self,plan=None):
            if plan is not None and plan is not self.plan:return super()._timeline(plan)
            key=(id(self.plan),self._edit_epoch,repr(self.settings))
            if not self._timeline_cache or self._timeline_cache[0]!=key:self._timeline_cache=(key,super()._timeline(plan))
            return self._timeline_cache[1]

        def apply_settings(self,settings):
            self.settings=settings
            self.vtk_scene.set_mouse_swap(settings.swap_mouse_buttons)
            self.vtk_widget.setAccessibleDescription(
                ('좌클릭 이동 · 우클릭 회전' if settings.swap_mouse_buttons else '좌클릭 회전 · 우클릭 이동')
                +' · 휠 확대 · Ctrl/Shift+클릭 다중 선택')

        def _camera_mode(self):
            return self.camera.currentData() or self.camera.currentText()

        def _refresh_camera_options(self,selected=None):
            selected=selected or self._camera_mode()
            with QSignalBlocker(self.camera):
                self.camera.clear()
                for mode in self._standard_cameras:self.camera.addItem(mode,mode)
                if self.plan:
                    for key,value in self.plan.custom_cameras.items():self.camera.addItem(value['name'],key)
                self.camera.addItem('사용자 지정','CUSTOM_NEW')
                index=self.camera.findData(selected);self.camera.setCurrentIndex(max(0,index))

        def _sync_camera_capture(self):
            if hasattr(self,'camera_capture_button'):
                self.camera_capture_button.setEnabled(bool(self.plan and not self.configuration_stale and (self._base_editing or self._selected_steps())
                    and self.camera.isEnabled() and self._camera_mode()=='CUSTOM_NEW'))

        def _capture_custom_camera(self):
            if not self.plan or self.configuration_stale or (not self._base_editing and not self._selected_steps()) or self._camera_mode()!='CUSTOM_NEW':return
            from pa2.domain.presentation import camera_vectors
            camera=self.vtk_scene.renderer.GetActiveCamera()
            direction,up=camera_vectors(camera.GetDirectionOfProjection(),camera.GetViewUp())
            self._stop_preview()
            self._pending_custom_camera={'direction':direction,'up':up,'framing':dict(
                position=list(camera.GetPosition()),focal_point=list(camera.GetFocalPoint()),
                parallel_scale=camera.GetParallelScale(),view_angle=camera.GetViewAngle(),
                parallel_projection=bool(camera.GetParallelProjection()),window_center=list(camera.GetWindowCenter()))}
            self.status.setText('현재 앵글을 캡처했습니다. 미리보기 & 적용을 누르면 프로젝트에 저장됩니다.')
            self._field_edited('camera')

        def apply_part_name(self,gid,name):
            if not self.result:return
            group=next(g for g in self.result.snapshot.groups if g.id==gid)
            group.user_display_name=name
            with QSignalBlocker(self.parts),QSignalBlocker(self.base):
                for i in range(self.parts.count()):
                    item=self.parts.item(i)
                    if item.data(Qt.UserRole)==gid:
                        suffix=item.text().rsplit('  [',1)[-1]
                        item.setText(f'{name}  [{suffix}')
                        item.setData(Qt.UserRole+1,name)
                index=self.base.findData(gid)
                if index>=0:self.base.setItemText(index,name)
            self.set_exceptions(self.exception_ids)
            if self.plan:
                self.plan.display_names=dict(self.plan.display_names,**{gid:name})
                for step in self.plan.steps:
                    if step.group_id==gid:
                        current=self.order.currentItem()
                        editing=current is not None and current.data(Qt.UserRole)==gid
                        if step.material_auto:
                            if editing and self.material.toPlainText()==step.material_text:
                                with QSignalBlocker(self.material):self.material.setPlainText(name)
                            step.material_text=name
                        if step.process_auto:
                            if editing and self.process.toPlainText()==step.process_text:
                                with QSignalBlocker(self.process):self.process.setPlainText(name+' 조립')
                            step.process_text=name+' 조립'
                for i in range(self.order.count()):
                    item=self.order.item(i)
                    if item.data(Qt.UserRole)==gid:
                        with QSignalBlocker(self.order):item.setText(f'{i+2:02d}  {name}\n'+item.text().split('\n',1)[-1])
                if self.plan.base_group_id==gid:self.base_card.setText(f'01  {name}\n기준 부품 · 고정')
                self._save()
            self._filter(self.search.text())
            self.status.setText('부품 표시명을 저장했습니다. 원본 파일·분류·그룹·조립 방향은 유지됩니다.')
            self.edit_state_changed.emit()

        def _pause_for_card_drag(self):
            self._card_seek_on_click=False
            self._stop_preview();self.play_timer.stop();self._leave_timeline();self._sync_playback()

        def _manual_ids(self):
            structure=getattr(self.result,'grouping_structure',None) if self.result else None
            return {n['id'] for n in (structure or {}).get('roots',[]) if n['kind']=='manual'}

        def _update_group_buttons(self):
            if not hasattr(self,'group_button'):return
            ids={i.data(Qt.UserRole) for i in self.parts.selectedItems()}
            base=self.base.currentData()
            self.group_button.setEnabled(len(ids)>=2 and ids<=self.vtk_scene.actors.keys())
            self.ungroup_button.setEnabled(len(ids)==1 and bool(ids & self._manual_ids()))
            self.ungroup_button.setToolTip('수동 그룹만 해제할 수 있습니다. 자동 그룹은 하나의 부품으로 잠겨 있습니다.')

        def _group_selected(self):
            if not self.result:return
            ids={i.data(Qt.UserRole) for i in self.parts.selectedItems()}
            if len(ids)<2 or not ids<=self.vtk_scene.actors.keys():return
            groups=[g for g in self.result.snapshot.groups if g.id in ids]
            dialog=ManualGroupDialog(groups,self)
            try:
                if dialog.exec():
                    self.grouping_requested.emit({'ids':list(ids),'name':dialog.group_name(),'ungroup':False})
            finally:dialog.deleteLater()

        def _ungroup_selected(self):
            ids={i.data(Qt.UserRole) for i in self.parts.selectedItems()}
            if len(ids)==1 and ids & self._manual_ids():
                self.grouping_requested.emit({'ids':list(ids),'ungroup':True})

        def has_pending_fields(self):
            if self._base_editing:
                return bool(self.plan and (self._pending_custom_camera is not None or self._camera_mode()!=(self.plan.base_camera_mode or 'AUTO')
                    or self._camera_roll_deg!=0))
            steps=self._selected_steps()
            if not steps:return False
            if len(steps)>1:return bool(self._batch_fields)
            step=steps[0]
            return (self.direction.currentText()!=self._direction_text(step.removal_direction)
                or round(self.distance.value(),self.distance.decimals())!=round(step.travel_mm,self.distance.decimals())
                or self._camera_mode()!=step.camera_mode or self._camera_roll_deg!=shared_camera_roll(self.plan,step)
                or self._pending_custom_camera is not None
                or self.process.toPlainText()!=step.process_text
                or self.material.toPlainText()!=step.material_text or self.caution.toPlainText()!=step.caution_text)

        def set_result(self,result,settings):
            self._changed();self._base_editing=False;self._base_selected=False;self.configuration_stale=False
            self.set_recent_generation(None);self.state_label.setText('순서를 생성하세요.')
            if self.generation_dialog:self.generation_dialog.hide()
            self.base_card.hide()
            self._timeline_focus=False;self.order.set_active_step(None)
            self._clear_visibility_toggle(restore=False)
            self._stop_preview()
            self._leave_timeline()
            self.play_timer.stop(); self.play_time=0.0
            self._part_isolation_snapshot=None
            self.thumbnail_timer.stop()
            self._syncing=True
            try: super().set_result(result,settings)
            finally:self._syncing=False
            self._icons={}; self._undo=[]; self._redo=[]
            self._pending_custom_camera=None;self._refresh_camera_options()
            self.apply_settings(settings)
            if self.views.currentIndex()<0:self.views.setCurrentIndex(0)
            else:self._view(self.views.currentText())
            manual=self._manual_ids();groups={g.id:g for g in result.snapshot.groups}
            for i in range(self.parts.count()):
                item=self.parts.item(i);group=groups[item.data(Qt.UserRole)]
                origin='수동 · 해제 가능' if group.id in manual else '자동 · 잠금' if group.matching_status==MatchingStatus.MATCHED else '미매칭'
                item.setText(f'{group.label}  [{origin}]')
                item.setData(Qt.UserRole+1,group.label);item.setFlags(item.flags()|Qt.ItemIsEditable)
            self.parts.build_children(result)
            self.parts.sync_colors(self.vtk_scene.body_colors)
            valid=set(self.vtk_scene.body_polydata)
            self._visibility_batches={tuple(sorted(set(b.get('body_ids',[]))&valid)):set(b.get('hidden_ids',[]))&valid&self.vtk_scene.hidden_body_ids
                for b in getattr(result,'visibility_batches',[]) if set(b.get('hidden_ids',[]))&valid&self.vtk_scene.hidden_body_ids}
            from pa2.application.import_audit import recovery_reason
            reason=recovery_reason(result.snapshot,result.assembly_scene)
            self.auto_generate.setEnabled(not bool(reason));self.auto_generate.setToolTip(reason or '간섭 검사와 학습 모델을 이용해 순서를 추천합니다.')
            self.import_audit_button.setText('불러오기 진단 · 복구됨' if reason else '불러오기 진단')
            if reason:self.status.setText(reason)
            for widget in (self.direction,self.distance,self.camera,self.camera_roll_left,self.camera_roll_right,self.process,self.material,self.caution,self.apply_button,self.step_preview_button):
                widget.setEnabled(False)
            self._update_group_buttons()
            self._sync_camera_capture()
            self._sync_playback()

        def _icon(self,gid):
            if gid not in self._icons:
                rgb=self.vtk_scene.thumbnail(gid); h,w,_=rgb.shape
                self._icons[gid]=QIcon(QPixmap.fromImage(QImage(rgb.data,w,h,w*3,QImage.Format_RGB888).copy()))
            return self._icons[gid]

        def set_plan(self,plan,message):
            self._changed();self._base_editing=False;self._base_selected=False
            self._timeline_focus=False;self.order.set_active_step(None)
            self._stop_preview()
            self._leave_timeline()
            self._clear_visibility_toggle()
            self.play_timer.stop(); self.play_time=0.0
            self._clear_part_isolation()
            self.thumbnail_timer.stop()
            self._syncing=True
            try:
                plan.display_names.update({g.id:g.user_display_name for g in self.result.snapshot.groups if g.user_display_name})
                super().set_plan(plan,message)
                self._refresh_camera_options()
                names={g.id:g.label for g in self.result.snapshot.groups}
                for step in plan.steps:
                    if step.material_auto:step.material_text=names.get(step.group_id,plan.display_names.get(step.group_id,step.group_id))
                    if step.process_auto:step.process_text=names.get(step.group_id,plan.display_names.get(step.group_id,step.group_id))+' 조립'
                self.base_card.setText(f'01  {names.get(plan.base_group_id,plan.display_names.get(plan.base_group_id,plan.base_group_id))}\n기준 부품 · 고정')
                if plan.base_group_id in self.vtk_scene.actors:self.base_card.setIcon(self._icon(plan.base_group_id))
                self.base_card.show()
                for i,step in enumerate(plan.steps):
                    item=self.order.item(i)
                    if step.group_id in self._icons:item.setIcon(self._icons[step.group_id])
                    marker=' · 경로 확인 필요' if step.geometry_status==GeometryStatus.DRAFT_UNRESOLVED else ' · 예외' if step.geometry_status==GeometryStatus.USER_COLLISION_EXCEPTION else ''
                    item.setText(f'{i+2:02d}  {names.get(step.group_id,plan.display_names.get(step.group_id,step.group_id))}\n분해 {self._direction_text(step.removal_direction)} · {step.travel_mm:.1f} mm{marker}')
                    item.setFlags(item.flags()|Qt.ItemIsUserCheckable); item.setCheckState(Qt.Unchecked)
                if plan.steps:self.order.setCurrentRow(0)
            finally:self._syncing=False
            self._update_group_buttons()
            self._order_selection()
            self.undo_button.setEnabled(bool(self._undo)); self.redo_button.setEnabled(bool(self._redo))
            self.thumbnail_timer.start(10)
            self._sync_playback()
            self._refresh_generation_details()

        def _next_thumbnail(self):
            pending=[self.order.item(i) for i in range(self.order.count())
                     if self.order.item(i).data(Qt.UserRole) not in self._icons and self.order.item(i).data(Qt.UserRole) in self.vtk_scene.actors]
            if not pending:self.thumbnail_timer.stop(); return
            visible=[item for item in pending if self.order.viewport().rect().intersects(self.order.visualItemRect(item))]
            item=(visible or pending)[0]
            item.setIcon(self._icon(item.data(Qt.UserRole)))

        @staticmethod
        def _direction_text(direction):
            return next((name for name,d in {'+X':(1,0,0),'-X':(-1,0,0),'+Y':(0,1,0),'-Y':(0,-1,0),'+Z':(0,0,1),'-Z':(0,0,-1)}.items() if all(abs(a-b)<1e-10 for a,b in zip(direction,d))),
                        '기존 경로 ('+', '.join(f'{v:.4f}' for v in direction)+')')

        def _selected(self):
            return {item.data(Qt.UserRole) for item in self.parts.selectedItems()} & self.vtk_scene.actors.keys()

        def _filter(self,text):self.parts.filter_text(text)

        def _show_import_audit(self):
            if not self.result:return
            import json
            scene=self.result.assembly_scene
            recovery=scene.recovery_required
            message=QMessageBox(self);message.setWindowTitle('불러오기 진단')
            message.setText(f'부품 그룹 {len(self.result.snapshot.groups)}개 · 바디 {len(scene.bodies)}개\n'+
                ('오류 복구 상태 · 자동생성 비활성화 · 수동 작업 가능' if recovery else '정상 불러오기')+
                '\n상세 정보에서 트리 대조 및 형상·표시 실패 내역을 확인할 수 있습니다.')
            message.setDetailedText(json.dumps(scene.import_diagnostics,ensure_ascii=False,indent=2))
            message.exec();message.deleteLater()

        def apply_body_color(self, body_ids, color):
            self._stop_preview()
            self.play_timer.stop()
            self._leave_timeline()
            self.result.assembly_scene.body_color_overrides.update(dict.fromkeys(body_ids, color))
            affected = self.vtk_scene.set_body_colors(body_ids, color)
            self.parts.sync_colors(self.vtk_scene.body_colors)
            for group_id in affected:
                self._icons.pop(group_id, None)
            if self.plan:
                if self.plan.base_group_id in affected:
                    self.base_card.setIcon(self._icon(self.plan.base_group_id))
                for row in range(self.order.count()):
                    item = self.order.item(row)
                    group_id = item.data(Qt.UserRole)
                    if group_id in affected:
                        item.setIcon(self._icon(group_id))
            self._sync_playback()

        def _set_body_visibility(self,ids,hidden,*,from_button=False):
            if not self.result:return
            self._stop_preview();self.play_timer.stop();self._leave_timeline()
            ids=set(ids)&self.vtk_scene.body_polydata.keys()
            current=self._effective_hidden_bodies()
            if not from_button:
                self._visibility_batches={key:values-ids for key,values in self._visibility_batches.items() if values-ids}
            self.vtk_scene.set_hidden_bodies(current|set(ids) if hidden else current-set(ids))
            for gid,bids in self.vtk_scene.group_body_ids.items():
                if ids.intersection(bids):self.vtk_scene.actors[gid].SetVisibility(bool(set(bids)-self.vtk_scene.hidden_body_ids))
            self.parts.sync_hidden(self.vtk_scene.hidden_body_ids)
            self.body_visibility_changed.emit(dict(hidden_body_ids=sorted(self.vtk_scene.hidden_body_ids),
                visibility_batches=[dict(body_ids=list(key),hidden_ids=sorted(values)) for key,values in self._visibility_batches.items() if values]))
            from .part_list import BODY_IDS
            items=self.parts.selectedItems()
            if any(i.data(Qt.UserRole) not in self.vtk_scene.actors for i in items):
                self.vtk_scene.highlight_bodies({bid for item in items for bid in (item.data(BODY_IDS) or [])})
            else:self.vtk_scene.highlight(self._selected())
            self._sync_visibility_button();self._sync_playback()

        def _clear_part_isolation(self,restore=True):
            previous=self._part_isolation_snapshot
            self._part_isolation_snapshot=None
            if restore and previous is not None:
                for gid,actor in self.vtk_scene.actors.items():
                    actor.SetVisibility(previous.get(gid,True))

        def _isolate_selected_parts(self,ids):
            # Selection styles properties only, never reveal explicitly hidden parts.
            self._clear_part_isolation()
            self.vtk_scene.highlight(ids)

        def _visibility_selected(self):
            items=self.parts.selectedItems() or self.order.selectedItems()
            return {item.data(Qt.UserRole) for item in items} & self.vtk_scene.actors.keys()

        def _visibility_bodies(self):
            from .part_list import BODY_IDS
            items=self.parts.selectedItems() or self.order.selectedItems()
            return {bid for item in items for bid in
                (item.data(BODY_IDS) or self.vtk_scene.group_body_ids.get(item.data(Qt.UserRole),[]))} & self.vtk_scene.body_polydata.keys()

        def _effective_hidden_bodies(self):
            # Animation visibility is temporary. Buttons describe the saved edit
            # view, including legacy explicit actor hides, not unassembled steps.
            state=self._timeline_edit_state
            if self._step_preview:state=self._step_preview['selection_state']
            hidden=set(state.get('hidden_body_ids',set())) if state else set(self.vtk_scene.hidden_body_ids)
            for gid,bids in self.vtk_scene.group_body_ids.items():
                visible=state['actors'].get(gid,(True,))[0] if state else self.vtk_scene.actors[gid].GetVisibility()
                if not visible:hidden.update(bids)
            return hidden

        def _sync_visibility_button(self):
            if not hasattr(self,'visibility_button'):return
            ids=self._visibility_bodies();hidden_ids=ids&self._effective_hidden_bodies()
            hidden=bool(ids) and hidden_ids==ids
            self.visibility_button.setChecked(hidden);self.visibility_button.setIcon(self._visibility_icons[hidden])
            self.visibility_button.setEnabled(bool(ids))
            label='부품을 선택하세요' if not ids else '선택 부품 표시' if hidden else '선택 부품 숨기기'
            if hidden_ids and not hidden:label+=' · 일부 숨김'
            self.visibility_button.setToolTip(label);self.visibility_button.setAccessibleName(label)

        def _clear_visibility_toggle(self,restore=True):
            self._visibility_restore=None
            self._sync_visibility_button()

        def _toggle_part_visibility(self):
            self._stop_preview();self.play_timer.stop();self._leave_timeline();self._sync_playback()
            ids=self._visibility_bodies()
            if not ids:self._sync_visibility_button();return
            hidden=self._effective_hidden_bodies()
            if len(ids)==1:
                self._set_body_visibility(ids,not ids<=hidden)
                return
            if ids<=hidden:
                # Reverse only group-origin hides within the CURRENT selection.
                # Earlier individual hides remain; a selection hidden solely by
                # individual controls can also be shown from this button.
                key=tuple(sorted(ids))
                owned=self._visibility_batches.get(key)
                if owned is None:owned=set().union(*self._visibility_batches.values()) if self._visibility_batches else set()
                restore=(owned&ids) or ids
                self._visibility_batches={key:values-restore for key,values in self._visibility_batches.items() if values-restore}
                self._set_body_visibility(restore,False,from_button=True)
            else:
                self._clear_part_isolation()
                key=tuple(sorted(ids))
                self._visibility_batches[key]=self._visibility_batches.get(key,set())|(ids-hidden)
                self._set_body_visibility(ids,True,from_button=True)

        def _hide(self):
            from .part_list import BODY_IDS
            self._set_body_visibility({bid for i in self.parts.selectedItems() for bid in (i.data(BODY_IDS) or [])},True)

        def _solo(self):
            self._stop_preview();self._leave_timeline();self._clear_visibility_toggle();self._clear_part_isolation();super()._solo()

        def _show_all(self):
            self._set_body_visibility(self._effective_hidden_bodies(),False)
            self._clear_visibility_toggle(restore=False);self._clear_part_isolation(restore=False);super()._show_all()

        def _enter_timeline(self):
            if self._timeline_edit_state is None:
                # Remove edit-only pop/highlight before storing original visibility
                # and positions. Animation may hide/reposition actors temporarily.
                self.vtk_scene.clear_selection()
                self._timeline_edit_state=self.vtk_scene.capture_selection_state()
                self.vtk_scene.set_hidden_bodies(set(),update_metadata=False)

        def _leave_timeline(self):
            previous=self._timeline_edit_state
            self._timeline_edit_state=None;self._timeline_focus=False
            if previous is not None:self.vtk_scene.restore_selection_state(previous)

        def _order_selection(self,sync_parts=True):
            if self._syncing:return
            ids={i.data(Qt.UserRole) for i in self.order.selectedItems()}
            if self._selection_modifiers & (Qt.ControlModifier|Qt.ShiftModifier) and self._base_selected and self.plan:ids.add(self.plan.base_group_id)
            self._sync_selection(ids,self.order.currentItem().data(Qt.UserRole) if self.order.currentItem() else None,from_order=True)

        def _card_clicked(self,item):
            seek=self._card_seek_on_click;self._card_seek_on_click=False
            if not seek or not self.plan or self.configuration_stale or len(self.order.selectedItems())!=1:return
            row=next((i for i,s in enumerate(self.plan.steps) if s.group_id==item.data(Qt.UserRole)),None)
            if row is None:return
            self.play_timer.stop();self._stop_preview()
            self._seek_seconds(self._timeline().segments[row].camera_end)

        def _sync_selection(self,ids,current_gid=None,from_order=False):
            if self._syncing:return
            self.selection_sync_count+=1
            self._stop_preview()
            self.play_timer.stop();self._leave_timeline();self.order.set_active_step(None)
            self._clear_part_isolation()
            ids=set(ids)
            for w in (self.base_assign,self.exception_add,self.exception_remove):w.setEnabled(True)
            self._base_selected=bool(self.plan and self.plan.base_group_id in ids)
            self._base_editing=bool(self._base_selected and len(ids)==1 and not self.configuration_stale)
            self._syncing=True
            try:
                with QSignalBlocker(self.order),QSignalBlocker(self.parts):
                    for i in range(self.order.count()):
                        item=self.order.item(i);selected=item.data(Qt.UserRole) in ids
                        if not from_order:item.setSelected(selected)
                        item.setCheckState(Qt.Checked if selected else Qt.Unchecked)
                        if not from_order and item.data(Qt.UserRole)==current_gid:self.order.setCurrentItem(item,QItemSelectionModel.NoUpdate)
                    for item in self.parts.all_items():item.setSelected(item.data(Qt.UserRole) in ids)
                self.vtk_scene.highlight(ids)
                self.selection_label.setText(f'{len(ids)}개 선택')
                self.base_card.setChecked(self._base_selected)
                self.position.setMaximum(max(1,self.order.count()-len(self.order.selectedItems())+1))
                rows=[self.order.row(i) for i in self.order.selectedItems()]
                if rows:self.position.setValue(min(rows)+1)
                editable=bool(self._selected_steps())
                for w in (self.direction,self.distance,self.camera,self.material,self.caution,self.apply_button):w.setEnabled(editable)
                for w in (self.camera_roll_left,self.camera_roll_right):w.setEnabled(editable and len(ids)==1)
                self.process.setEnabled(editable and len(ids)==1)
                if self._base_editing:
                    for w in (self.camera,self.camera_roll_left,self.camera_roll_right,self.apply_button):w.setEnabled(True)
                    self._pending_custom_camera=None;self._camera_roll_deg=0
                    self._refresh_camera_options(self.plan.base_camera_mode or 'AUTO')
                    self.camera_roll_label.setText('0°')
            finally:self._syncing=False
            selected_items=self.order.selectedItems()
            self._batch_fields.clear()
            if self._selected_steps():
                first=min(selected_items,key=self.order.row)
                if len(selected_items)==1:
                    with QSignalBlocker(self.order):self.order.setCurrentItem(first,QItemSelectionModel.NoUpdate)
                self._edit_step(first,None)
            self._update_group_buttons()
            self._sync_visibility_button()
            self._sync_camera_capture()
            self._sync_playback()
            self.edit_state_changed.emit()

        def _checked(self,item):
            if self._syncing:return
            with QSignalBlocker(self.order):item.setSelected(item.checkState()==Qt.Checked)
            self._order_selection()

        def _select_group(self):
            if self._syncing:return
            self._timeline_focus=False
            selected=list(self.parts.selectedItems());current=self.parts.currentItem()
            ids={i.data(Qt.UserRole) for i in selected}
            self._sync_selection(ids & self.vtk_scene.actors.keys(),current.data(Qt.UserRole) if current else None)
            if ids-self.vtk_scene.actors.keys():
                from .part_list import BODY_IDS
                with QSignalBlocker(self.parts):
                    for item in selected:item.setSelected(True)
                    if current:self.parts.setCurrentItem(current,QItemSelectionModel.NoUpdate)
                body_ids={bid for item in selected for bid in (item.data(BODY_IDS) or [])}
                self.vtk_scene.highlight_bodies(body_ids)
                self.selection_label.setText(f'하위 구성 {len(body_ids)}개 선택')
                for w in (self.base_assign,self.exception_add,self.exception_remove,self.group_button,self.ungroup_button):w.setEnabled(False)
            else:
                for w in (self.base_assign,self.exception_add,self.exception_remove):w.setEnabled(True)
            self._sync_visibility_button()

        def _picked(self,gid,extend=False):
            if not gid:return
            if gid.startswith('body:'):
                item=next((i for i in self.parts.all_items() if i.data(Qt.UserRole)==gid),None)
                if item:
                    with QSignalBlocker(self.parts):
                        if not extend:self.parts.clearSelection()
                        item.setSelected(True);self.parts.setCurrentItem(item,QItemSelectionModel.NoUpdate)
                    self._select_group();self.parts.scrollToItem(item)
                return
            toggle_off = not extend and {i.data(Qt.UserRole) for i in self.parts.selectedItems()} == {gid}
            self.parts.blockSignals(True)
            for item in self.parts.all_items():
                item.setSelected(not toggle_off and ((item.isSelected() if extend else False) or item.data(Qt.UserRole)==gid))
            self.parts.blockSignals(False); self._select_group()
            if not toggle_off:
                item=next((self.parts.item(i) for i in range(self.parts.count()) if self.parts.item(i).data(Qt.UserRole)==gid),None)
                if item:self.parts.scrollToItem(item)

        def _edit_step(self,current,previous):
            if self._syncing or self.configuration_stale or not current or not self.plan:return
            steps=self._selected_steps()
            if len(steps)>1:
                current=min(self.order.selectedItems(),key=self.order.row)
            self._base_editing=False
            self._batch_fields.clear()
            self._stop_preview()
            self._syncing=True
            try:
                step=next(s for s in self.plan.steps if s.group_id==current.data(Qt.UserRole))
                self._pending_custom_camera=None
                self._refresh_camera_options(step.camera_mode)
                super()._edit_step(current,previous)
                label=self._direction_text(step.removal_direction)
                if self.direction.findText(label)<0:self.direction.addItem(label)
                self.direction.setCurrentText(self._direction_text(step.removal_direction))
                self._camera_roll_deg=shared_camera_roll(self.plan,step)
                self.camera_roll_label.setText(f'{self._camera_roll_deg}°')
            finally:self._syncing=False
            self._sync_camera_capture()
            self.edit_state_changed.emit()

        def _record(self):
            if self.plan:self._undo.append(copy.deepcopy(self.plan)); self._undo=self._undo[-30:]; self._redo=[]

        def _camera_mode_changed(self,*_):
            if self._syncing or not self.plan:return
            self._pending_custom_camera=None
            self._sync_camera_capture()
            if self._base_editing:return
            steps=self._selected_steps()
            if not steps:return
            step=steps[0]
            mode=self._camera_mode()
            if mode=='CUSTOM_NEW' or mode.startswith('CUSTOM:'):
                self._camera_roll_deg=step.camera_roll_deg if mode==step.camera_mode else 0
                self.camera_roll_label.setText(f'{self._camera_roll_deg}°');return
            key=camera_view_key(replace(step,camera_mode=mode))
            legacy=next((s.camera_roll_deg for s in self.plan.steps if camera_view_key(s)==key),0)
            self._camera_roll_deg=self.plan.camera_rolls.get(key,legacy)
            self.camera_roll_label.setText(f'{self._camera_roll_deg}°')

        def _rotate_camera(self,delta):
            if not self.plan or self.configuration_stale or (not self._base_editing and len(self._selected_steps())!=1):return
            self._stop_preview()
            self._camera_roll_deg=(self._camera_roll_deg+delta)%360
            self.camera_roll_label.setText(f'{self._camera_roll_deg}°')
            self._notify_edit()

        def _reordered(self):
            self._record(); self._commit_order(); self.status.setText('선택 단계 묶음 이동 · 내부 순서 유지'); self._renumber()
            self._save()
            self.edit_state_changed.emit()

        def _commit_order(self):
            if not self.plan:return
            ids=[self.order.item(i).data(Qt.UserRole) for i in range(self.order.count())]
            if ids!=[s.group_id for s in self.plan.steps]:self.plan.user_modified=True
            mapping={s.group_id:s for s in self.plan.steps}; self.plan.steps=[mapping[gid] for gid in ids]
            for i,step in enumerate(self.plan.steps,1):step.step_index=i

        def _renumber(self):
            selected=self._selected(); current=self.order.currentItem().data(Qt.UserRole) if self.order.currentItem() else None
            self._changed()
            names={g.id:g.label for g in self.result.snapshot.groups}
            self._syncing=True
            for i in range(self.order.count()):
                item=self.order.item(i);gid=item.data(Qt.UserRole)
                step=next(s for s in self.plan.steps if s.group_id==gid)
                with QSignalBlocker(self.order):
                    item.setText(f'{i+2:02d}  {names.get(gid,gid)}\n분해 {self._direction_text(step.removal_direction)} · {step.travel_mm:.1f} mm')
                    item.setSelected(gid in selected)
                if item.data(Qt.UserRole)==current:self.order.setCurrentItem(item,QItemSelectionModel.NoUpdate)
            self._syncing=False; self._order_selection()
            self.undo_button.setEnabled(bool(self._undo));self.redo_button.setEnabled(bool(self._redo))

        def _move(self,delta):
            rows=[self.order.row(i) for i in self.order.selectedItems()]
            if rows:self.order.move_selection(min(rows)+delta)

        def _single(self):
            current=self.order.currentItem()
            if current:self.order.clearSelection(); current.setSelected(True)

        def _history(self,redo):
            if self.configuration_stale:return
            source,target=(self._redo,self._undo) if redo else (self._undo,self._redo)
            if not source or not self.plan:return
            target.append(copy.deepcopy(self.plan)); restored=source.pop()
            restored.display_names.update({g.id:g.user_display_name for g in self.result.snapshot.groups if g.user_display_name})
            for field in restored.__dataclass_fields__:setattr(self.plan,field,copy.deepcopy(getattr(restored,field)))
            self.set_plan(self.plan,'편집 다시 실행' if redo else '편집 실행 취소')
            self._save()
            self.edit_state_changed.emit()

        def _edited_plan(self,steps):
            from pa2.domain.presentation import add_custom_camera,prune_custom_cameras
            batch=len(steps)>1
            fields=self._batch_fields if batch else {'direction','distance','camera','roll','material','process','caution'}
            candidate=copy.deepcopy(self.plan)
            if not fields:return candidate
            mode=self._camera_mode()
            if 'camera' in fields and mode=='CUSTOM_NEW':
                if self._pending_custom_camera is None:
                    self.status.set_issue('3D 화면을 회전한 뒤 카메라 버튼으로 앵글을 먼저 캡처하세요.')
                    return None
                mode=add_custom_camera(candidate,**self._pending_custom_camera)
            axes={'+X':(1,0,0),'-X':(-1,0,0),'+Y':(0,1,0),'-Y':(0,-1,0),'+Z':(0,0,1),'-Z':(0,0,-1)}
            selected={step.group_id:step for step in steps}
            for step in candidate.steps:
                original=selected.get(step.group_id)
                if original is None:continue
                if 'direction' in fields:
                    direction_text=self.direction.currentText()
                    if batch or direction_text!=self._direction_text(step.removal_direction):
                        step.removal_direction=axes.get(direction_text,step.removal_direction)
                    step.assembly_direction=tuple(-v for v in step.removal_direction)
                if 'distance' in fields and (batch or round(step.travel_mm,self.distance.decimals())!=round(self.distance.value(),self.distance.decimals())):
                    step.travel_mm=self.distance.value()
                if 'camera' in fields:
                    step.camera_mode=mode
                    if batch and mode!=original.camera_mode:
                        step.camera_roll_deg=self.plan.camera_rolls.get(camera_view_key(step),self._camera_roll_deg)
                if 'material' in fields:
                    value=self.material.toPlainText()
                    step.material_auto=not batch and step.material_auto and value==step.material_text
                    step.material_text=value
                if 'process' in fields:
                    value=self.process.toPlainText()
                    step.process_auto=step.process_auto and value==step.process_text
                    step.process_text=value
                if 'caution' in fields:step.caution_text=self.caution.toPlainText()
                if 'roll' in fields and (step.camera_mode!=original.camera_mode or self._camera_roll_deg!=shared_camera_roll(self.plan,original)):
                    set_shared_camera_roll(candidate,step,self._camera_roll_deg)
            prune_custom_cameras(candidate)
            candidate.validate(allow_partial=True)
            return candidate

        def _apply_step(self):
            if self.configuration_stale:return False
            if self._base_editing:return self._apply_base_camera()
            steps=self._selected_steps()
            if not steps:return False
            candidate=self._edited_plan(steps)
            if candidate is None:return False
            from pa2.application.plan_service import PlanService
            if PlanService.content_signature(candidate)==PlanService.content_signature(self.plan):
                self._batch_fields.clear()
                return True
            selected={step.group_id:step for step in steps}
            for step in candidate.steps:
                original=selected.get(step.group_id)
                if original is not None and step!=original and step.geometry_status!=GeometryStatus.USER_COLLISION_EXCEPTION:
                    step.geometry_status=GeometryStatus.USER_CONFIRMED_UNCHECKED
            candidate.user_modified=True
            self._record()
            for field in candidate.__dataclass_fields__:setattr(self.plan,field,copy.deepcopy(getattr(candidate,field)))
            self._pending_custom_camera=None
            self._renumber(); self.status.setText('수동 수정값 적용 · 간섭 재검사 없음')
            self._save()
            self.edit_state_changed.emit()
            return True

        def _apply_base_camera(self):
            if not self.plan or not self.has_pending_fields():return False
            from pa2.domain.presentation import set_base_camera,set_base_camera_mode
            mode=self._camera_mode();pending=self._pending_custom_camera
            direct=mode in self._standard_cameras or (mode in self.plan.custom_cameras and self.plan.custom_cameras[mode]['name']!='기준시점')
            if mode=='CUSTOM_NEW' and pending is None:
                self.status.set_issue('기준 앵글을 먼저 캡처하세요.');return False
            if not direct and pending is None:
                from types import SimpleNamespace
                from pa2.rendering.scene import camera_for_step
                pose=camera_for_step(SimpleNamespace(camera_mode=mode,camera_roll_deg=0,assembly_direction=(0,0,-1)),
                    custom_cameras=self.plan.custom_cameras,camera_rolls=self.plan.camera_rolls)
                pending=dict(direction=pose.view_direction,up=pose.view_up)
                if pose.position is not None:
                    pending['framing']={k:getattr(pose,k) for k in ('position','focal_point','parallel_scale','view_angle','parallel_projection','window_center')}
            if not direct and self._camera_roll_deg:
                from pa2.rendering.scene import CameraPose,_roll_camera
                pose=_roll_camera(CameraPose(tuple(pending['direction']),mode,tuple(pending['up'])),self._camera_roll_deg)
                pending=dict(pending,direction=pose.view_direction,up=pose.view_up)
            if QMessageBox.question(self,'기준시점 일괄 적용','전체 단계의 카메라를 변경합니다. 개별 설정을 덮어쓸까요?')!=QMessageBox.Yes:return False
            self._record()
            if direct:set_base_camera_mode(self.plan,mode,self._camera_roll_deg)
            else:set_base_camera(self.plan,**pending)
            self.plan.user_modified=True
            self._pending_custom_camera=None;self._camera_roll_deg=0;self._changed();self._save()
            self.camera_roll_label.setText('0°')
            self._refresh_camera_options(self.plan.base_camera_mode or 'AUTO')
            self.status.setText(('선택 시점으로 변경 · 기존 기준시점 해제' if direct else '기준시점 저장')+' · 전체 단계에 적용했습니다. 순서를 다시 확정하세요.')
            self.undo_button.setEnabled(True);self.edit_state_changed.emit()
            return True

        def _apply_and_preview(self):
            self._stop_preview()
            base=self._base_editing
            if base and not self.has_pending_fields():self._seek(0);return
            if self._apply_step():
                if base:self._seek(0)
                else:self._preview_step(committed=True)

        def _preview_step(self,committed=False):
            if self.configuration_stale:return
            if self._step_preview:
                self._stop_preview()
                return
            steps=self._selected_steps()
            if not steps:return
            preview=copy.deepcopy(self.plan) if committed else self._edited_plan(steps)
            if preview is None:return
            self._clear_visibility_toggle()
            self.play_timer.stop()
            self._sync_playback()
            step=next(s for s in preview.steps if s.group_id==steps[0].group_id)
            import vtk
            camera=vtk.vtkCamera(); camera.DeepCopy(self.vtk_scene.renderer.GetActiveCamera())
            selection_state=self.vtk_scene.capture_selection_state()
            self.vtk_scene.set_hidden_bodies(set(),update_metadata=False)
            timeline=self._timeline(preview)
            segment=next(s for s in timeline.segments if s.step_index==step.step_index)
            self._step_preview={'plan':preview,'timeline':timeline,'time':segment.camera_start,'end':segment.move_end,
                                'camera':camera,'selection_state':selection_state,
                                'framing':(self.vtk_scene.base_center,self.vtk_scene.camera_distance,self.vtk_scene.camera_base_id)}
            self.vtk_scene.apply(scene_at(preview,segment.camera_start,self.settings,timeline))
            self._preview_clock=time.monotonic();self.preview_timer.start(33)
            self._sync_playback()

        def _preview_tick(self):
            preview=self._step_preview
            if not preview:return
            now=time.monotonic();elapsed=max(0.,now-self._preview_clock) if self._preview_clock is not None else .033
            self._preview_clock=now
            preview['time']=min(preview['end'],preview['time']+elapsed*float(self.speed.currentText()))
            frame=scene_at(preview['plan'],preview['time'],self.settings,preview['timeline'])
            self.vtk_scene.apply(frame)
            self._sync_playback(frame)
            if preview['time']>=preview['end']:self._stop_preview()

        def _stop_preview(self):
            if not self._step_preview:return
            self.preview_timer.stop(); previous=self._step_preview; self._step_preview=None
            self._preview_clock=None
            self.vtk_scene.renderer.GetActiveCamera().DeepCopy(previous['camera'])
            self.vtk_scene.base_center,self.vtk_scene.camera_distance,self.vtk_scene.camera_base_id=previous['framing']
            self.vtk_scene.restore_selection_state(previous['selection_state'])
            self.step_preview_button.setText('미리보기 && 적용')
            self._sync_playback()

        def _save(self):
            if self.configuration_stale:return
            self._commit_order()
            self._changed()
            if self.plan:self.save_requested.emit(self.plan)

        def _assign_base(self):
            ids=self._selected()
            if len(ids)!=1:return
            gid=next(iter(ids))
            if gid in self.exception_ids:self.status.set_issue('예외 지정을 해제한 뒤 기준 부품으로 지정하세요.'); return
            self.base.setCurrentIndex(self.base.findData(gid))

        def _base_changed(self):
            gid=self.base.currentData()
            if gid in self.exception_ids:self.set_exceptions([x for x in self.exception_ids if x!=gid]); self.preset_changed.emit()
            self._update_group_buttons()

        def _set_selected_exceptions(self,enabled):
            selected=self._selected()-{self.base.currentData()}
            ids=set(self.exception_ids)
            ids=ids|selected if enabled else ids-selected
            self.set_exceptions(sorted(ids)); self.preset_changed.emit()

        def _navigation(self,pan):
            self.orbit.setChecked(not pan); self.pan.setChecked(pan); self.vtk_scene.pan_mode=pan

        def _view(self,name):
            if name:self.vtk_scene.set_view(name)

        def _activate_view(self,name):
            if self.views.currentText()==name:self._view(name)
            else:self.views.setCurrentText(name)

        def _manual_view_rotation(self):
            self.view_action_group.setExclusive(False)
            try:self.views.setCurrentIndex(-1)
            finally:self.view_action_group.setExclusive(True)

        def preview(self):
            if self.configuration_stale:return
            self._stop_preview();self._leave_timeline()
            self._clear_visibility_toggle()
            self._clear_part_isolation()
            super().preview()
            if self.plan:self.scrubber.setValue(10000); self.play_time=self._timeline().duration
            self._sync_playback()

        def _sync_playback(self,frame=None):
            self._sync_visibility_button()
            ready=bool(self.plan) and not self.configuration_stale
            for button in (self.first_button,self.previous_button,self.play,self.next_button,self.last_button,self.scrubber,self.speed):
                button.setEnabled(ready)
            duration=self._timeline().duration if ready else 0.0
            update_play_button(self.play,self.play_timer.isActive())
            self.time_label.setText(f'{self.play_time:.1f} / {duration:.1f}s')
            self.playback_state.setText('재생 중' if self.play_timer.isActive() else '완성 형상' if not ready or self.play_time>=duration else '일시정지' if self.play_time else '시작')
            if not self.scrubber.isSliderDown():
                with QSignalBlocker(self.scrubber):self.scrubber.setValue(round(self.play_time/max(duration,.001)*10000))
            if frame is None and self._step_preview:
                preview=self._step_preview
                frame=scene_at(preview['plan'],preview['time'],self.settings,preview['timeline'])
            elif frame is None and ready and self._timeline_focus:
                frame=scene_at(self.plan,self.play_time,self.settings,self._timeline())
            active=frame.active_group_id if frame else None
            if frame and not self._step_preview and self._timeline_focus:
                active=active or (self.plan.steps[frame.step_index-1].group_id if frame.step_index else self.plan.base_group_id)
                self._follow_playback_selection(active)
            self.order.set_active_step(active)
            self.base_card.setChecked(bool(frame and frame.active_group_id==self.plan.base_group_id) or self._base_selected)
            if frame and frame.active_group_id:
                state='미리보기' if self._step_preview else '재생 중' if self.play_timer.isActive() else '일시정지'
                self.playback_state.setText(f'{frame.step_index+1:02d}단계 · {state}')

        def _follow_playback_selection(self,gid):
            """Bind the visible stage without selection slots stopping/rewinding playback."""
            if self._syncing or not self.plan or self.configuration_stale:return
            base=gid==self.plan.base_group_id
            selected=self.order.selectedItems()
            if base and self._base_selected and not selected:return
            if not base and not self._base_selected and len(selected)==1 and selected[0].data(Qt.UserRole)==gid:return
            target=None;self._syncing=True
            try:
                with QSignalBlocker(self.order),QSignalBlocker(self.parts):
                    for i in range(self.order.count()):
                        item=self.order.item(i);chosen=item.data(Qt.UserRole)==gid
                        item.setSelected(chosen);item.setCheckState(Qt.Checked if chosen else Qt.Unchecked)
                        if chosen:target=item;self.order.setCurrentItem(item,QItemSelectionModel.NoUpdate)
                    for item in self.parts.all_items():item.setSelected(item.data(Qt.UserRole)==gid)
                self._base_selected=base;self._base_editing=base;self.base_card.setChecked(base)
                self.selection_label.setText('1개 선택');self.position.setMaximum(max(1,self.order.count()))
                if target:self.position.setValue(self.order.row(target)+1)
                for w in (self.direction,self.distance,self.camera,self.camera_roll_left,self.camera_roll_right,self.process,self.material,self.caution,self.apply_button):w.setEnabled(not base)
                if base:
                    for w in (self.camera,self.camera_roll_left,self.camera_roll_right,self.apply_button):w.setEnabled(True)
                    self._pending_custom_camera=None;self._camera_roll_deg=0;self.camera_roll_label.setText('0°')
                    self._refresh_camera_options(self.plan.base_camera_mode or 'AUTO')
            finally:self._syncing=False
            if target:self._edit_step(target,None)
            self._update_group_buttons();self._sync_camera_capture();self._sync_visibility_button()

        def _show_base_step(self,*_):
            if not self.plan or self.configuration_stale:return
            extend=self._base_click_modifiers & (Qt.ControlModifier|Qt.ShiftModifier)
            self._base_click_modifiers=Qt.NoModifier
            ids=self._selected() if extend else set()
            if extend and self.plan.base_group_id in ids:ids.remove(self.plan.base_group_id)
            else:ids.add(self.plan.base_group_id)
            self._sync_selection(ids,self.plan.base_group_id)
            if not self._base_editing:return
            self._seek(0)
            self.status.setText('01단계 · 기준 부품 배치 · 이동 없음')

        def _toggle_play(self):
            if not self.plan or self.configuration_stale:return
            self._clear_visibility_toggle()
            self._stop_preview()
            self._clear_part_isolation()
            self._commit_order()
            if self.play_timer.isActive():self.play_timer.stop(); self._sync_playback(); return
            if self.play_time>=self._timeline().duration:self.play_time=0
            self._enter_timeline()
            self._timeline_focus=True
            self._play_clock=time.monotonic();self.play_timer.start(33); self._sync_playback()

        def _play_tick(self):
            if not self.plan or self.configuration_stale:return
            self._enter_timeline()
            self._timeline_focus=True
            now=time.monotonic()
            elapsed=max(0.,now-self._play_clock) if self._play_clock is not None and self.play_timer.isActive() else .033
            self._play_clock=now;timeline=self._timeline()
            self.play_time=min(timeline.duration,self.play_time+elapsed*float(self.speed.currentText()))
            if self.play_time>=timeline.duration:self.play_timer.stop();self._play_clock=None
            frame=scene_at(self.plan,self.play_time,self.settings,timeline)
            self.vtk_scene.apply(frame);self._sync_playback(frame)

        def _seek(self,value):
            if not self.plan or self.configuration_stale:return
            self._seek_seconds(self._timeline().duration*(value/10000))

        def _scrub_seek(self,value):
            self.play_timer.stop();self._seek(value)

        def _seek_seconds(self,seconds):
            if not self.plan or self.configuration_stale:return
            self._clear_visibility_toggle()
            self._stop_preview()
            self._clear_part_isolation()
            self._enter_timeline()
            timeline=self._timeline()
            self.play_time=max(0.,min(timeline.duration,seconds))
            self._timeline_focus=True
            frame=scene_at(self.plan,self.play_time,self.settings,timeline)
            self.vtk_scene.apply(frame)
            self._sync_playback(frame)

        def _jump_end(self,end):
            if not self.plan:return
            self.play_timer.stop(); self._stop_preview()
            if self.order.count():self.order.setCurrentRow(self.order.count()-1 if end else 0)
            self._seek(10000 if end else 0)

        def _neighbor(self,delta):
            if not self.plan or not self.order.count():return
            self.play_timer.stop(); self._stop_preview()
            if delta<0 and self.order.currentRow()<=0:
                self._show_base_step();return
            if delta>0 and self.play_time<self._timeline().base_end:
                row=0
            else:
                row=max(0,min(self.order.count()-1,self.order.currentRow()+delta))
            self.order.setCurrentRow(row)
            timeline=self._timeline()
            self._seek(round(timeline.segments[row].camera_start/max(timeline.duration,.001)*10000))

    return ModelEditor

