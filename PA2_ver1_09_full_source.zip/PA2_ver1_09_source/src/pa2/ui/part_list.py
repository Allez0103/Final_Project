"""Expandable part tree with list-compatible access to planning units only."""
from PySide6.QtCore import Qt,Signal,QItemSelectionModel,QSignalBlocker,QSize
from PySide6.QtGui import QColor,QPen,QPolygonF,QPainter
from PySide6.QtCore import QPointF
from PySide6.QtWidgets import QApplication,QColorDialog,QTreeWidget,QTreeWidgetItem,QStyledItemDelegate,QAbstractItemView,QHeaderView,QStyle,QStyleOptionViewItem

BODY_IDS=Qt.UserRole+3
IS_GROUP=Qt.UserRole+4
VISIBILITY_STATE=Qt.UserRole+5
BODY_COLORS=Qt.UserRole+6
COLOR_COLUMN=1


class PartItem(QTreeWidgetItem):
    def data(self,*args):return super().data(0,args[0]) if len(args)==1 else super().data(*args)
    def setData(self,*args):return super().setData(0,*args) if len(args)==2 else super().setData(*args)
    def text(self,column=0):return super().text(column)
    def setText(self,*args):return super().setText(0,args[0]) if len(args)==1 else super().setText(*args)
    def setToolTip(self,*args):return super().setToolTip(0,args[0]) if len(args)==1 else super().setToolTip(*args)


class PartNameDelegate(QStyledItemDelegate):
    def paint(self,painter,option,index):
        super().paint(painter,option,index)
        if not str(index.data(Qt.UserRole)).startswith('body:'):return
        opt=QStyleOptionViewItem(option);self.initStyleOption(opt,index)
        widget=opt.widget or self.parent()
        rect=widget.style().subElementRect(QStyle.SE_ItemViewItemCheckIndicator,opt,widget)
        if not rect.isValid():return
        painter.save();painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(QPen(QColor('#BBC3CC'),1));painter.setBrush(QColor('#E8ECF0'))
        painter.drawRoundedRect(rect.adjusted(0,0,-1,-1),2,2)
        state=index.data(Qt.CheckStateRole)
        pen=QPen(QColor('#40536A'),1.8,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin);painter.setPen(pen)
        x,y,w,h=rect.x(),rect.y(),rect.width(),rect.height()
        if state in (Qt.Checked,Qt.Checked.value):
            painter.drawPolyline(QPolygonF([QPointF(x+w*.22,y+h*.51),QPointF(x+w*.43,y+h*.72),QPointF(x+w*.77,y+h*.28)]))
        elif state in (Qt.PartiallyChecked,Qt.PartiallyChecked.value):
            painter.drawLine(QPointF(x+w*.25,y+h*.5),QPointF(x+w*.75,y+h*.5))
        painter.restore()

    def setEditorData(self,editor,index):
        editor.setText(index.data(Qt.UserRole+1) or index.data(Qt.DisplayRole))
        editor.selectAll()

    def setModelData(self,editor,model,index):
        self.parent().rename_requested.emit(index.data(Qt.UserRole),editor.text())


class PartColorDelegate(QStyledItemDelegate):
    def paint(self, painter, option, index):
        super().paint(painter, option, index)
        colors = index.data(BODY_COLORS)
        if not colors:
            return
        rect = option.rect.adjusted(5, 3, -5, -3)
        rect.setHeight(min(16, rect.height()))
        if len(colors) == 1:
            painter.fillRect(rect, QColor.fromRgbF(*colors[0]))
        else:
            left = rect.adjusted(0, 0, -(rect.width() // 2), 0)
            right = rect.adjusted(left.width(), 0, 0, 0)
            painter.fillRect(left, QColor.fromRgbF(*colors[0]))
            painter.fillRect(right, QColor.fromRgbF(*colors[1]))
        painter.save()
        painter.setPen(QPen(QColor('#536174'), 1))
        painter.drawRect(rect.adjusted(0, 0, -1, -1))
        painter.restore()


class PartListWidget(QTreeWidget):
    rename_requested = Signal(str,str)
    body_visibility_requested=Signal(object,bool)
    body_color_requested = Signal(object, object)
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('partTree')
        from .viewport import viewport_icon
        self._status_icons={state:viewport_icon(name) for state,name in
            (('visible','show'),('hidden','hide'),('partial','partial'))}
        self.setIconSize(QSize(16,16))
        self.setStyleSheet('QTreeWidget#partTree::indicator { width: 14px; height: 14px; }')
        self._group_items=[]
        self._toggle_press = None
        self._color_press = None
        self.setColumnCount(2);self.setHeaderHidden(True);self.setIndentation(18)
        self.setUniformRowHeights(True);self.setTextElideMode(Qt.ElideRight)
        self.header().setStretchLastSection(False)
        self.header().setSectionResizeMode(0, QHeaderView.Stretch)
        self.header().setSectionResizeMode(COLOR_COLUMN, QHeaderView.Fixed)
        self.setColumnWidth(COLOR_COLUMN, 32)
        self.setItemDelegate(PartNameDelegate(self))
        self.setItemDelegateForColumn(COLOR_COLUMN, PartColorDelegate(self))
        self.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.itemChanged.connect(self._visibility_changed)

    def count(self):return len(self._group_items)
    def item(self,index):return self._group_items[index] if 0<=index<len(self._group_items) else None
    def row(self,item):return self._group_items.index(item) if item in self._group_items else -1
    def setCurrentRow(self,index):self.setCurrentItem(self.item(index))
    def setCurrentItem(self,item,*args):
        if args and isinstance(args[0],QItemSelectionModel.SelectionFlag):return super().setCurrentItem(item,0,args[0])
        return super().setCurrentItem(item,*args)
    def addItem(self,item):
        node=PartItem([item.text()]);node.setData(Qt.UserRole,item.data(Qt.UserRole))
        node.setData(IS_GROUP,True);self.addTopLevelItem(node);self._group_items.append(node)
    def clear(self):self._group_items=[];super().clear()
    def all_items(self):
        def walk(item):
            yield item
            for i in range(item.childCount()):yield from walk(item.child(i))
        return [n for i in range(self.topLevelItemCount()) for n in walk(self.topLevelItem(i))]
    def _visibility_changed(self,item,column):
        if column != 0 or not str(item.data(Qt.UserRole)).startswith('body:') or item.data(BODY_IDS) is None:return
        self.body_visibility_requested.emit(list(item.data(BODY_IDS)),item.checkState(0)!=Qt.Checked)
    def sync_colors(self, body_colors):
        with QSignalBlocker(self):
            for item in self.all_items():
                colors = list(dict.fromkeys(body_colors[bid] for bid in item.data(BODY_IDS) or [] if bid in body_colors))
                item.setData(COLOR_COLUMN, BODY_COLORS, colors)
                label = '혼합 색상' if len(colors) > 1 else QColor.fromRgbF(*colors[0]).name().upper() if colors else ''
                action = '클릭하여 이 항목의 색상 변경'
                item.setToolTip(COLOR_COLUMN, f'{label}\n{action}' if colors else '')
    def sync_hidden(self,hidden):
        hidden=set(hidden)
        with QSignalBlocker(self):
            for item in self.all_items():
                ids=set(item.data(BODY_IDS) or [])
                if ids and str(item.data(Qt.UserRole)).startswith('body:'):
                    item.setCheckState(0,Qt.Unchecked if ids<=hidden else Qt.PartiallyChecked if ids&hidden else Qt.Checked)
                elif ids:
                    count=len(ids&hidden)
                    state='hidden' if count==len(ids) else 'partial' if count else 'visible'
                    if item.data(VISIBILITY_STATE)!=state:
                        item.setData(VISIBILITY_STATE,state);item.setIcon(0,self._status_icons[state])
                    label={'visible':'표시됨','hidden':'숨김','partial':'일부 하위 부품 숨김'}[state]
                    item.setToolTip(f'표시 상태: {label}\n표시 {len(ids)-count} / 전체 {len(ids)}\n표시·숨김 변경: 하위 체크박스 또는 3D 숨기기 버튼')
    def build_children(self,result):
        from pa2.application.manual_grouping import node_id
        scene=result.assembly_scene;body_map={getattr(b,'id',None):b for b in scene.bodies}
        groups={g.id:g for g in result.snapshot.groups};items={n.data(Qt.UserRole):n for n in self._group_items}
        structure=(getattr(result,'grouping_structure',None) or {}).get('roots',[])
        structures={node_id(n):n for n in structure}
        def inspect(label,key,ids,parent):
            item=PartItem([label]);item.setData(Qt.UserRole,key);item.setData(BODY_IDS,list(ids));parent.addChild(item)
            item.setFlags(item.flags()&~Qt.ItemIsEditable)
            if not key.startswith('body:'):item.setFlags(item.flags()&~Qt.ItemIsUserCheckable)
            return item
        def bodies(parent,ids):
            for i,bid in enumerate(ids):
                body=body_map.get(bid);label=getattr(body,'display_name',None) or f'바디 {i+1}'
                if len(ids)>1:label+=f' · 바디 {i+1}'
                mode=getattr(body,'display_mode','solid');note=getattr(body,'display_note','')
                if mode!='solid':label+=f' [{"대체 표시" if mode=="proxy" else "표시 불가" if mode=="missing" else "복구"}]'
                item=inspect(label,'body:'+bid,[bid],parent)
                item.setToolTip('\n'.join(x for x in (getattr(body,'occurrence_path',''),note) if x))
        def source_children(parent,ids):
            candidates=[]
            def visit(node):
                if set(ids)<=set(node['body_ids']):candidates.append(node)
                for n in node['children']:visit(n)
            for node in getattr(scene,'tree',[]):visit(node)
            if not candidates:bodies(parent,ids);return
            source=min(candidates,key=lambda n:(len(n['body_ids']),-n['id'].count('/')))
            def append(node,target):
                selected=[bid for bid in node['body_ids'] if bid in ids]
                if not selected:return
                if node['children']:
                    child=inspect(node['label'],'tree-member:'+node['id'],selected,target)
                    for n in node['children']:append(n,child)
                else:
                    if set(selected)==set(ids):bodies(target,selected)
                    else:bodies(inspect(node['label'],'tree-member:'+node['id'],selected,target),selected)
            append(source,parent)
        def manual(parent,node):
            if node['kind']=='manual':
                from pa2.application.manual_grouping import composed_group
                for n in node['members']:
                    g=composed_group(n);child=inspect(g.label,'node:'+g.id,g.body_ids,parent);manual(child,n)
            else:source_children(parent,node['group']['body_ids'])
        with QSignalBlocker(self):
            for gid,item in items.items():
                item.setData(BODY_IDS,groups[gid].body_ids)
                if gid in structures:manual(item,structures[gid])
                else:source_children(item,groups[gid].body_ids)
            tree=getattr(scene,'tree',[])
            by_bodies={frozenset(g.body_ids):items[g.id] for g in groups.values() if g.id.startswith('group-step-')}
            if by_bodies and not any(n['kind']=='manual' for n in structure):
                def assembly(node,parent=None):
                    group_item=by_bodies.get(frozenset(node['body_ids']))
                    if group_item is not None and not node.get('children'):
                        index=self.indexOfTopLevelItem(group_item)
                        if index>=0:self.takeTopLevelItem(index)
                        if parent:parent.addChild(group_item)
                        else:self.addTopLevelItem(group_item)
                        return
                    if not node.get('children'):return
                    container=PartItem([node['label']]);container.setData(Qt.UserRole,'tree:'+node['id'])
                    container.setData(BODY_IDS,node['body_ids']);container.setFlags(container.flags()&~Qt.ItemIsUserCheckable)
                    if parent:parent.addChild(container)
                    else:self.addTopLevelItem(container)
                    for n in node['children']:assembly(n,container)
                    container.setExpanded(True)
                for node in tree:assembly(node)
            self.sync_hidden({b.id for b in scene.bodies if getattr(b,'hidden',False)})
    def filter_text(self,text):
        text=text.casefold()
        def visit(item):
            own=text in item.text().casefold();children=[visit(item.child(i)) for i in range(item.childCount())]
            visible=own or any(children);item.setHidden(not visible)
            if text and any(children):item.setExpanded(True)
            if own:
                for i in range(item.childCount()):item.child(i).setHidden(False)
            return visible
        for i in range(self.topLevelItemCount()):visit(self.topLevelItem(i))

    def mousePressEvent(self, event):
        self._toggle_press = None
        self._color_press = None
        point = event.position().toPoint()
        item = self.itemAt(point)
        if event.button() == Qt.LeftButton and item is not None and self.columnAt(point.x()) == COLOR_COLUMN:
            self._color_press = item
            event.accept()
            return
        if event.button()==Qt.RightButton:
            if item is not None and item.data(IS_GROUP):self.editItem(item)
            event.accept();return
        if (event.button() == Qt.LeftButton and not event.modifiers()
                and item is not None and self.selectedItems() == [item]
                and event.position().x()>self.visualItemRect(item).left()+24):
            self._toggle_press = (item, event.position().toPoint())
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        color_item = self._color_press
        self._color_press = None
        if color_item is not None and event.button() == Qt.LeftButton:
            point = event.position().toPoint()
            colors = color_item.data(COLOR_COLUMN, BODY_COLORS)
            if self.itemAt(point) is color_item and self.columnAt(point.x()) == COLOR_COLUMN and colors:
                color = QColorDialog.getColor(QColor.fromRgbF(*colors[0]), self, '부품 색상 변경',
                                              QColorDialog.DontUseNativeDialog)
                if color.isValid():
                    self.body_color_requested.emit(list(color_item.data(BODY_IDS)), color.getRgbF()[:3])
            event.accept()
            return
        pending = self._toggle_press
        self._toggle_press = None
        super().mouseReleaseEvent(event)
        if pending and event.button() == Qt.LeftButton and not event.modifiers():
            item, origin = pending
            point = event.position().toPoint()
            if (self.itemAt(point) is item and self.selectedItems() == [item]
                    and (point-origin).manhattanLength() < QApplication.startDragDistance()):
                self.clearSelection()
