"""Manifest-only runtime removal; no wildcard deletion of the source/workspace."""
import base64,ctypes,errno,hashlib,json,os,shutil,stat,subprocess,sys,tempfile,time,uuid
from pathlib import Path

MANIFEST='.pa2-install.json'
OWNED='.pa2-owned.json'
MANAGED=('projects','database','assets','cache','jobs','learning','logs','settings.json')

def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def atomic(p,value):
    tmp=p.with_name(p.name+'.'+uuid.uuid4().hex+'.tmp')
    tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(p)
def no_links(p):
    p=Path(p).absolute()
    for node in (p,*p.parents):
        if node.exists() and (node.is_symlink() or getattr(node.lstat(),'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',1024)):
            raise ValueError('링크/정션 경로는 삭제하지 않습니다: '+str(node))
    return p.resolve()
def safe_root(p):
    root=no_links(p)
    forbidden={Path.home().resolve(),Path(root.anchor),Path(os.environ.get('WINDIR','C:/Windows')).resolve()}
    if root in forbidden or len(root.parts)<3:raise ValueError('광범위 경로 삭제 금지: '+str(root))
    return root
def child(root,relative):
    part=Path(relative)
    if part.is_absolute() or '..' in part.parts or not part.parts:raise ValueError('관리 영역 밖 경로')
    p=no_links(root/part)
    if not p.is_relative_to(root) or p==root:raise ValueError('관리 영역 밖 경로')
    return p

def register_data(install,data):
    """Called only by the running application, never by the uninstaller itself."""
    install=safe_root(install);data=safe_root(data);path=install/MANIFEST
    if not path.exists():return  # Source checkouts are never uninstall targets.
    m=read(path);assert m['schema']=='pa2-install-v1'
    if data==install or install.is_relative_to(data):raise ValueError('데이터 경로가 프로그램/소스 상위입니다.')
    marker=data/OWNED
    owners=read(marker).get('owners',{}) if marker.exists() else {}
    owners[m['id']]=str(install)
    atomic(marker,{'schema':'pa2-owned-data-v1','owners':owners})
    m['data_roots']=sorted(set(m.get('data_roots',[]))|{str(data)});atomic(path,m)

def inventory(install):
    install=safe_root(install)
    paths=[install/'PA2.exe',install/'uninst.exe']+list((install/'_internal').rglob('*'))
    files={str(p.relative_to(install)):sha(p) for p in paths if p.is_file()}
    if 'PA2.exe' not in files or 'uninst.exe' not in files:raise ValueError('실행 파일 누락')
    existing=read(install/MANIFEST) if (install/MANIFEST).exists() else {}
    value={'schema':'pa2-install-v1','id':existing.get('id',str(uuid.uuid4())),
           'files':files,'data_roots':existing.get('data_roots',[])}
    atomic(install/MANIFEST,value);return value

def build_plan(install):
    install=safe_root(install);m=read(install/MANIFEST)
    if m.get('schema')!='pa2-install-v1':raise ValueError('올바른 설치 명세가 아닙니다.')
    files=[];preserved=[];directories=set();roots=[install];shared=[];ownership={}
    for relative,digest in m['files'].items():
        parts=Path(relative).parts
        if relative not in ('PA2.exe','uninst.exe') and parts[0]!='_internal':raise ValueError('프로그램 관리 목록 위반')
        p=child(install,relative)
        if not p.exists():continue
        if sha(p)!=digest:preserved.append(str(p));continue
        files.append(str(p))
    log=install/'log'
    if log.exists():
        no_links(log)
        for p in log.iterdir():
            no_links(p)
            if not p.is_file() or p.suffix!='.json':continue
            try:owned=str(read(p).get('schema_version','')).startswith('pa2-')
            except (ValueError,OSError):owned=False
            if owned:
                files.append(str(p))
                if p.with_suffix('.lck').exists():files.append(str(no_links(p.with_suffix('.lck'))))
        # Only this known child directory and this exact schema are managed.
        # Unknown files remain intact; never recursively delete the log root.
        summaries=log/'accuracy_log'
        if summaries.exists():
            no_links(summaries)
            for p in summaries.iterdir():
                no_links(p)
                if not p.is_file() or p.suffix!='.json':continue
                try:owned=read(p).get('schema_version')=='pa2-accuracy-log-v1'
                except (ValueError,OSError,AttributeError):owned=False
                if owned:files.append(str(p))
    for text in m.get('data_roots',[]):
        root=safe_root(text)
        if not root.exists():continue
        if root==install or install.is_relative_to(root):raise ValueError('광범위 데이터 경로')
        marker=read(root/OWNED);owners=marker.get('owners',{})
        if marker.get('schema')!='pa2-owned-data-v1' or not isinstance(owners,dict) or not owners:
            raise ValueError('올바른 프로젝트 소유 정보가 아닙니다: '+str(root))
        if m['id'] not in owners:raise ValueError('등록된 프로젝트 소유 경로가 다릅니다: '+str(root))
        # A copied ZIP can retain the same installation ID at another path.
        # Accept that exact collision only when the other manifest confirms it.
        owner=safe_root(owners[m['id']])
        if owner!=install:
            other=read(owner/MANIFEST)
            if other.get('schema')!='pa2-install-v1' or other.get('id')!=m['id'] or str(root) not in other.get('data_roots',[]):
                raise ValueError('등록된 프로젝트 소유 경로가 다릅니다: '+str(root))
        ownership[str(root)]=sha(root/OWNED)
        if len(owners)>1 or owner!=install:shared.append(str(root))
        roots.append(root)
        for name in MANAGED:
            target=child(root,name)
            if not target.exists():continue
            if target.is_file():files.append(str(target))
            else:
                for base,dirs,names in os.walk(target,followlinks=False):
                    no_links(base)
                    for d in dirs:no_links(Path(base)/d)
                    for n in names:files.append(str(no_links(Path(base)/n)))
                    directories.add(str(Path(base)))
        files.append(str(root/OWNED))
    # Include empty managed containers as well as directories containing files.
    # Only rmdir is used: unknown files are never removed to empty a directory.
    for container in (install/'_internal',install/'log'):
        if container.exists():
            for base,dirs,names in os.walk(no_links(container),followlinks=False):
                no_links(base)
                for d in dirs:no_links(Path(base)/d)
                directories.add(str(Path(base)))
    for text in files:
        p=Path(text)
        for parent in p.parents:
            if parent in roots:break
            if any(parent.is_relative_to(root) for root in roots):directories.add(str(parent))
    files.append(str(install/MANIFEST))
    directories.update(map(str,roots))
    # Include hashes and manifest so approval cannot silently cover a changed plan.
    value=dict(schema='pa2-uninstall-plan-v2',install=str(install),installation_id=m['id'],roots=list(map(str,roots)),
        shared_data_roots=sorted(shared),remove_shared_data=True,manifest_digest=sha(install/MANIFEST),ownership_digests=ownership,
        files=sorted(set(files)),directories=sorted(directories,key=lambda s:(len(Path(s).parts),s.casefold()),reverse=True),preserved=preserved)
    value['approval']=hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest()
    return value

def ensure_closed(install):
    """All frozen versions and their workers are PA2.exe processes."""
    if os.name!='nt':return
    from ctypes import wintypes
    class Entry(ctypes.Structure):
        _fields_=[('dwSize',wintypes.DWORD),('cntUsage',wintypes.DWORD),('th32ProcessID',wintypes.DWORD),
            ('th32DefaultHeapID',ctypes.c_size_t),('th32ModuleID',wintypes.DWORD),('cntThreads',wintypes.DWORD),
            ('th32ParentProcessID',wintypes.DWORD),('pcPriClassBase',wintypes.LONG),('dwFlags',wintypes.DWORD),
            ('szExeFile',wintypes.WCHAR*260)]
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.CreateToolhelp32Snapshot.argtypes=[wintypes.DWORD,wintypes.DWORD]
    kernel.CreateToolhelp32Snapshot.restype=wintypes.HANDLE
    kernel.Process32FirstW.argtypes=[wintypes.HANDLE,ctypes.POINTER(Entry)]
    kernel.Process32NextW.argtypes=[wintypes.HANDLE,ctypes.POINTER(Entry)]
    kernel.CloseHandle.argtypes=[wintypes.HANDLE]
    handle=kernel.CreateToolhelp32Snapshot(2,0)
    if handle==ctypes.c_void_p(-1).value:raise ctypes.WinError(ctypes.get_last_error())
    try:
        entry=Entry();entry.dwSize=ctypes.sizeof(entry)
        more=kernel.Process32FirstW(handle,ctypes.byref(entry))
        if not more:raise ctypes.WinError(ctypes.get_last_error())
        while more:
            if entry.szExeFile.casefold()=='pa2.exe':
                raise ValueError('다른 버전을 포함한 모든 PA²와 CAD/학습 작업을 종료한 뒤 다시 실행하세요. (PID '+str(entry.th32ProcessID)+')')
            more=kernel.Process32NextW(handle,ctypes.byref(entry))
        if ctypes.get_last_error()!=18:raise ctypes.WinError(ctypes.get_last_error())
    finally:kernel.CloseHandle(handle)

def execute(install,approval):
    ensure_closed(install)
    plan=build_plan(install)
    if plan['approval']!=approval:raise ValueError('삭제 범위가 바뀌었습니다. 다시 확인하세요.')
    # Preflight ALL paths before the first deletion. Every target is rechecked.
    for text in plan['files']+plan['directories']:no_links(text)
    removed=[];errors=[]
    # Manifest goes last, leaving recovery information if another file is locked.
    markers=[p for p in plan['files'] if Path(p).name==OWNED]
    targets=[p for p in plan['files'] if Path(p).name not in (MANIFEST,OWNED)]+markers+[str(Path(install)/MANIFEST)]
    for text in targets:
        p=no_links(text)
        if not any(p.is_relative_to(Path(root)) and p!=Path(root) for root in plan['roots']):raise ValueError('삭제 경로 이탈')
        if p.name in (MANIFEST,OWNED) and errors:continue
        try:
            if p.exists():p.unlink();removed.append(str(p))
        except OSError as exc:errors.append(dict(path=str(p),error=str(exc)))
    removed_directories=[];remaining_directories=[]
    for text in plan['directories']:
        p=no_links(text)
        if not any(p==Path(root) or p.is_relative_to(Path(root)) for root in plan['roots']):raise ValueError('삭제 경로 이탈')
        try:p.rmdir();removed_directories.append(str(p))
        except FileNotFoundError:pass
        except OSError as exc:
            remaining_directories.append(str(p))
            if exc.errno not in (errno.ENOTEMPTY,errno.EEXIST):errors.append(dict(path=str(p),error=str(exc)))
    return dict(ok=not errors,removed=removed,errors=errors,preserved=plan['preserved'],roots=plan['roots'],
        shared_data_roots=plan['shared_data_roots'],removed_directories=removed_directories,remaining_directories=remaining_directories)

def cleanup_helper():
    """An external, hidden PowerShell waits for this process and removes only
    its exact temp helper file and then the empty helper directory."""
    if os.name!='nt' or not getattr(sys,'frozen',False):return
    helper=no_links(sys.executable);folder=helper.parent;temporary=no_links(tempfile.gettempdir())
    if helper.name!='uninst.exe' or folder.parent!=temporary or not folder.name.startswith('PA2-uninstall-'):return
    def quote(text):return "'"+str(text).replace("'","''")+"'"
    script=(f"$ErrorActionPreference='Stop'; $helper={quote(helper)}; $folder={quote(folder)}; "
        f"$temporary={quote(temporary)}; $parentId={os.getpid()}; "
        "if ((Split-Path -Parent $folder) -ne $temporary -or (Split-Path -Leaf $folder) -notlike 'PA2-uninstall-*' "
        "-or (Split-Path -Parent $helper) -ne $folder -or (Split-Path -Leaf $helper) -ne 'uninst.exe') { exit 2 }; "
        "Wait-Process -Id $parentId -ErrorAction SilentlyContinue; "
        "for ($attempt=0; $attempt -lt 50; $attempt++) { try { "
        "if (Test-Path -LiteralPath $helper) { Remove-Item -LiteralPath $helper -Force }; "
        "if ((Test-Path -LiteralPath $folder) -and @(Get-ChildItem -LiteralPath $folder -Force).Count -eq 0) { "
        "Remove-Item -LiteralPath $folder -Force }; break } catch { Start-Sleep -Milliseconds 200 } }")
    encoded=base64.b64encode(script.encode('utf-16-le')).decode('ascii')
    powershell=Path(os.environ.get('WINDIR','C:/Windows'))/'System32/WindowsPowerShell/v1.0/powershell.exe'
    subprocess.Popen([str(powershell),'-NoProfile','-NonInteractive','-WindowStyle','Hidden','-EncodedCommand',encoded],
        cwd=temporary,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),close_fds=True)

def message(text,title='PA² 제거',flags=0):
    return ctypes.windll.user32.MessageBoxW(None,text,title,flags)

def main():
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--root');parser.add_argument('--approved');parser.add_argument('--parent',type=int)
    parser.add_argument('--report');parser.add_argument('--test-remove',action='store_true');args=parser.parse_args()
    root=Path(args.root).resolve() if args.root else Path(sys.executable).resolve().parent
    try:
        plan=build_plan(root)
        ensure_closed(root)
        if args.report and any(Path(args.report).resolve().is_relative_to(Path(r)) for r in plan['roots']):
            raise ValueError('보고서는 삭제 대상 밖이어야 합니다.')
        if args.test_remove:
            marker=read(root/'.pa2-uninstall-test.json')
            boundary=safe_root(marker['boundary'])
            if not root.is_relative_to(boundary) or root==boundary or any(not Path(p).is_relative_to(boundary) for p in plan['roots']):
                raise ValueError('시험 복사본 경계 이탈')
            if marker['id']!=plan['installation_id'] or not args.report:raise ValueError('시험 승인 누락')
        elif not args.approved:
            text='프로그램과 다른 버전이 공유하는 데이터를 포함해 등록된 PA² 관리 데이터를 모두 삭제합니다.\n다른 버전에서도 기존 프로젝트를 사용할 수 없으며 복구할 수 없습니다.\n\n'+ '\n'.join(plan['roots'])+f"\n\n삭제 파일: {len(plan['files'])}개\n빈 설치·데이터 폴더도 정리합니다.\n외부 원본 CAD·백업·미등록 파일과 다른 버전의 실행 파일은 보존합니다.\n계속하시겠습니까?"
            if message(text,flags=0x34)!=6:return 0
            helper=Path(tempfile.mkdtemp(prefix='PA2-uninstall-'))/'uninst.exe';shutil.copy2(sys.executable,helper)
            subprocess.Popen([str(helper),'--root',str(root),'--approved',plan['approval'],'--parent',str(os.getpid())],
                             cwd=tempfile.gettempdir(),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),close_fds=True)
            return 0
        if args.parent:
            kernel=ctypes.windll.kernel32;kernel.OpenProcess.restype=ctypes.c_void_p
            kernel.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_ulong]
            handle=kernel.OpenProcess(0x100000,False,args.parent)
            if handle:
                result=kernel.WaitForSingleObject(handle,15000);kernel.CloseHandle(handle)
                if result!=0:raise ValueError('제거 프로그램 종료 대기 실패')
        if not args.approved:raise ValueError('삭제 승인 없음')
        # Explorer/launchers may have set the installation as the working dir.
        os.chdir(tempfile.gettempdir())
        result=execute(root,args.approved)
        if args.report:
            output=Path(args.report).resolve()
            if any(output.is_relative_to(Path(r)) for r in plan['roots']):raise ValueError('보고서는 삭제 대상 밖이어야 합니다.')
            atomic(output,result)
        elif not args.test_remove:
            message(('프로그램과 등록된 공유 관리 데이터 제거를 완료했습니다.\n'+
                ('미등록·변경 파일이 있는 폴더는 보존했습니다.' if result['remaining_directories'] else '빈 설치·데이터 폴더도 정리했습니다.'))
                if result['ok'] else '일부 파일 또는 폴더를 제거하지 못했습니다. 실행 중인 프로그램을 종료하고 다시 시도하세요.')
        return 0 if result['ok'] else 1
    except Exception as exc:
        if args.report:atomic(Path(args.report),{'ok':False,'error':str(exc)})
        else:message(str(exc),flags=0x10)
        return 1
    finally:
        if args.parent:
            try:cleanup_helper()
            except OSError:pass  # Cleanup cannot turn a completed removal into a failure.
