"""Read occurrence metadata without changing successful solid IDs or placements.

Only explicit leaf product occurrences are grouping units. Assemblies remain
tree containers; a flat multi-solid STEP is never guessed to be one part.
"""
from OCP.STEPCAFControl import STEPCAFControl_Reader
from OCP.TDocStd import TDocStd_Document
from OCP.TCollection import TCollection_ExtendedString
from OCP.TDataStd import TDataStd_Name
from OCP.TDF import TDF_Label
from OCP.TopAbs import TopAbs_SOLID, TopAbs_SHELL, TopAbs_FACE
from OCP.TopExp import TopExp_Explorer
from OCP.TopLoc import TopLoc_Location
from OCP.TopoDS import TopoDS_Shape
from OCP.XCAFDoc import XCAFDoc_DocumentTool
from OCP.collections import Sequence_TDF_Label
from pa2.domain.models import AtomicBody, Bounds, MatchingStatus


def subshapes(shape, kind):
    if shape.IsNull():return []
    if shape.ShapeType()==kind:return [shape]
    ex=TopExp_Explorer(shape,kind);result=[]
    while ex.More():result.append(ex.Current());ex.Next()
    return result


def read_tree(reader,bodies,shapes,source_hash,relative_path):
    from .importer import _bounds,_properties
    diagnostics=[];claimed=set();roots=[];node_count=0
    try:
        caf=STEPCAFControl_Reader(reader.WS(),False)
        caf.SetNameMode(True);caf.SetColorMode(False);caf.SetLayerMode(False)
        doc=TDocStd_Document(TCollection_ExtendedString('BinXCAF'))
        if not caf.Transfer(doc):raise ValueError('XCAF 트리 변환 실패')
        tool=XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
        labels=Sequence_TDF_Label();tool.GetFreeShapes(labels)
        def name(label):
            attr=TDataStd_Name()
            return attr.Get().ToExtString().strip() if label.FindAttribute(TDataStd_Name.GetID_s(),attr) else ''
        def match(shape):
            available=[b for b in bodies if b.id not in claimed]
            exact=[b for b in available if shapes[b.id].IsSame(shape)]
            if exact:return exact[0]
            try:
                box=_bounds(shape);volume,area,_=_properties(shape)
                def same(b):
                    return (max(abs(a-c) for a,c in zip(
                        (box.xmin,box.ymin,box.zmin,box.xmax,box.ymax,box.zmax),
                        (b.bounds.xmin,b.bounds.ymin,b.bounds.zmin,b.bounds.xmax,b.bounds.ymax,b.bounds.zmax)))<=1e-5
                        and abs((volume or 0)-(b.volume_mm3 or 0))<=max(1e-6,abs(volume or 0)*1e-8)
                        and abs((area or 0)-(b.area_mm2 or 0))<=max(1e-6,abs(area or 0)*1e-8))
                candidates=[b for b in available if same(b)]
                # Identical coincident occurrences consume distinct existing bodies.
                if candidates:return candidates[0]
            except Exception:pass
            return None
        def recover(shape,node,mode):
            index=len(bodies);bid=f'body-{source_hash[:12]}-{index:06d}'
            try:box=_bounds(shape)
            except Exception:box=Bounds(0,0,0,0,0,0)
            try:volume,area,centroid=_properties(shape)
            except Exception:volume=area=centroid=None
            note={'surface':'솔리드가 아닌 곡면/셸 · 수동 작업 전용',
                  'missing':'형상 변환 실패 · 실제 형상 표시 불가',
                  'recovered':'부분 변환에서 복구한 형상 · 수동 작업 전용'}[mode]
            body=AtomicBody(bid,source_hash,relative_path,index,node['id'],node['label'],box,
                volume,area,centroid,False,display_mode=mode,display_note=note)
            bodies.append(body);shapes[bid]=shape
            diagnostics.append(dict(code='RECOVERED_BODY',body_id=bid,name=node['label'],detail=note,recovery=True))
            return body
        def walk(label,parent,path,depth=0,occ_name=''):
            nonlocal node_count
            node_count+=1
            if depth>64 or node_count>50000:raise ValueError('STEP 트리 깊이/항목 수 제한')
            ref=TDF_Label()
            if tool.GetReferredShape_s(label,ref):
                return walk(ref,parent.Multiplied(tool.GetLocation_s(label)),path,depth+1,name(label))
            node=dict(id=path,label=name(label) or occ_name or f'부품 {path.rsplit("/",1)[-1]}',
                      kind='part',body_ids=[],children=[])
            children=Sequence_TDF_Label()
            if tool.GetComponents_s(label,children) and children.Length():
                node['kind']='assembly'
                for i in range(1,children.Length()+1):
                    node['children'].append(walk(children.Value(i),parent,f'{path}/{i}',depth+1))
                node['body_ids']=[bid for n in node['children'] for bid in n['body_ids']]
                return node
            shape=tool.GetShape_s(label)
            if not shape.IsNull():shape=shape.Moved(parent)
            solids=subshapes(shape,TopAbs_SOLID)
            for solid in solids:
                body=match(solid) or recover(solid,node,'recovered')
                claimed.add(body.id);node['body_ids'].append(body.id)
                body.occurrence_path=path;body.display_name=node['label']
            # Non-solid leaves, and orphan shells/faces alongside valid solids.
            shells=[];ex=TopExp_Explorer(shape,TopAbs_SHELL,TopAbs_SOLID)
            while ex.More():shells.append(ex.Current());ex.Next()
            faces=[];ex=TopExp_Explorer(shape,TopAbs_FACE,TopAbs_SHELL)
            while ex.More():faces.append(ex.Current());ex.Next()
            for item in shells+faces:
                body=recover(item,node,'surface');claimed.add(body.id);node['body_ids'].append(body.id)
            if not node['body_ids']:
                body=recover(shape,node,'missing');claimed.add(body.id);node['body_ids'].append(body.id)
            return node
        for i in range(1,labels.Length()+1):roots.append(walk(labels.Value(i),TopLoc_Location(),f'step/{i}'))
        mapped={bid for n in roots for bid in n['body_ids']}
        unmapped=[b.id for b in bodies if b.id not in mapped]
        diagnostics.append(dict(code='STEP_TREE_AUDIT',tree_available=bool(roots),nodes=node_count,
            tree_body_count=len(mapped),imported_body_count=len(bodies),unmapped_body_ids=unmapped,
            limitation='STEP에서 제거된 원본 CAD 부품은 확인할 수 없습니다.'))
    except Exception as exc:
        diagnostics.append(dict(code='STEP_TREE_UNAVAILABLE',detail=f'{type(exc).__name__}: {exc}',
            recovery=bool(roots),limitation='원본 트리와 전체 대조 불가 · 가져온 형상은 보존'))
    return roots,diagnostics


def groups_from_tree(scene):
    from .grouping import GroupingResult,_make_group
    from pa2.domain.classification import classify_part
    if not any(n.get('children') for n in scene.tree):return None
    body_map={b.id:b for b in scene.bodies};groups=[];claimed=set()
    def walk(node):
        if node['children']:
            for n in node['children']:walk(n)
        else:
            ids=node['body_ids']
            if not ids or set(ids)&claimed:return
            gid=f"group-step-{scene.source_hash[:10]}-"+node['id'].replace('/','-')
            groups.append(_make_group(gid,node['label'],[body_map[bid] for bid in ids],
                classify_part(node['label']),MatchingStatus.MATCHED,None));claimed.update(ids)
    for root in scene.tree:walk(root)
    if not groups:return None
    for body in scene.bodies:
        if body.id not in claimed:
            groups.append(_make_group(f'group-{body.id}',body.display_name,[body],classify_part(body.display_name),MatchingStatus.UNMATCHED,None))
    result=GroupingResult(groups,[],[b.id for b in scene.bodies if b.id not in claimed])
    result.assert_partition(body_map)
    return result
