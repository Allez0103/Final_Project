"""Opt-in real GUI tests for STEP trees, persistent body visibility and recovery."""
import hashlib,json,time
from dataclasses import replace
from pathlib import Path


def write_model(path,surface=False):
    from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
    from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeFace
    from OCP.gp import gp_Pnt,gp_Trsf,gp_Vec,gp_Pln,gp_Dir
    from OCP.TDocStd import TDocStd_Document
    from OCP.TCollection import TCollection_ExtendedString
    from OCP.TDataStd import TDataStd_Name
    from OCP.XCAFDoc import XCAFDoc_DocumentTool
    from OCP.TopLoc import TopLoc_Location
    from OCP.STEPCAFControl import STEPCAFControl_Writer
    from OCP.STEPControl import STEPControl_AsIs
    from .cad.shapes import compound
    doc=TDocStd_Document(TCollection_ExtendedString('BinXCAF'));tool=XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
    base=tool.AddShape(BRepPrimAPI_MakeBox(20,20,5).Shape(),False)
    TDataStd_Name.Set_s(base,TCollection_ExtendedString('BASE'))
    shape=(BRepBuilderAPI_MakeFace(gp_Pln(gp_Pnt(0,0,0),gp_Dir(0,0,1)),0,10,0,10).Shape() if surface else
           compound([BRepPrimAPI_MakeBox(gp_Pnt(x,0,0),3,4,5).Shape() for x in (0,5)]))
    part=tool.AddShape(shape,False);TDataStd_Name.Set_s(part,TCollection_ExtendedString('COVER'))
    sub=tool.NewShape();TDataStd_Name.Set_s(sub,TCollection_ExtendedString('SUB ASSEMBLY'))
    shift=gp_Trsf();shift.SetTranslation(gp_Vec(25,0,0));tool.AddComponent(sub,part,TopLoc_Location(shift))
    root=tool.NewShape();TDataStd_Name.Set_s(root,TCollection_ExtendedString('PRODUCT'))
    tool.AddComponent(root,base,TopLoc_Location());tool.AddComponent(root,sub,TopLoc_Location())
    shift=gp_Trsf();shift.SetTranslation(gp_Vec(0,30,0));tool.AddComponent(root,part,TopLoc_Location(shift))
    tool.UpdateAssemblies();writer=STEPCAFControl_Writer();writer.SetNameMode(True)
    writer.Transfer(doc,STEPControl_AsIs);writer.Write(str(path));return path


def verify(window,output_dir):
    from PySide6.QtWidgets import QApplication,QMessageBox
    from PySide6.QtCore import Qt,QSignalBlocker,QItemSelectionModel,QTimer
    from .application.appearance import AppearanceService
    from .application.import_audit import recovery_reason
    from .application.manual_grouping import ManualGroupingService
    import imageio_ffmpeg
    from PIL import Image
    out=Path(output_dir);checks=[]
    def require(ok,message):
        if not ok:raise AssertionError(message)
        checks.append(message)
    def wait():
        end=time.monotonic()+120
        while window.thread and time.monotonic()<end:QApplication.processEvents();time.sleep(.005)
        require(window.thread is None,'Background task completed');QApplication.processEvents()
    def snap(name):
        window.model_page.thumbnail_timer.stop();QApplication.processEvents();window.grab().save(str(out/(name+'.png')))
        Image.fromarray(window.model_page.vtk_scene.rgb_array()).save(out/(name+'-scene.png'))
    window.settings=replace(window.settings,video_width=640,video_height=360,video_fps=10,video_encoder='libx264',
        highlight_sec=.1,assembly_move_sec=.1,final_hold_sec=.1,camera_180_sec=.2)
    path=write_model(out/'nested.step');digest=hashlib.sha256(path.read_bytes()).hexdigest()
    project=window.projects.create('트리 검증','검증 차종','검증 품종');window._analyze(project,path,[]);wait()
    p=window.model_page;r=window.import_result
    require(len(r.snapshot.groups)==3 and len(r.assembly_scene.bodies)==5,'Nested STEP and repeated multi-solid parts grouped without separate files')
    require(p.auto_generate.isEnabled() and p.manual_generate.isEnabled(),'Normal model allows automatic and manual generation')
    require(any(n.text()=='SUB ASSEMBLY' for n in p.parts.all_items()),'Part list exposes original subassembly ancestry')
    group=next(g for g in r.snapshot.groups if g.label=='COVER');bid=group.body_ids[0]
    child=next(n for n in p.parts.all_items() if n.data(Qt.UserRole)=='body:'+bid)
    ancestor=child.parent()
    while ancestor:ancestor.setExpanded(True);ancestor=ancestor.parent()
    p.parts.setCurrentItem(child,QItemSelectionModel.ClearAndSelect);QApplication.processEvents()
    require(child.isSelected() and not p.group_button.isEnabled() and not p.apply_button.isEnabled(),'Child is independently selected and cannot change group sequence/role')
    require(any(gid=='body:'+bid for _,gid in p.vtk_scene._selection_overlay_ids),'Selected child is highlighted red separately')
    child.setCheckState(0,Qt.Unchecked);QApplication.processEvents()
    require(bid in p.vtk_scene.hidden_body_ids,'Child visibility checkbox hides only that body')
    require(len(group.body_ids)==2 and p.vtk_scene.actors[group.id].GetVisibility(),'Sibling body remains visible')
    require(bid in AppearanceService(window.database).load(project.id)['hidden_body_ids'],'Body visibility persisted in project')
    group_item=next(p.parts.item(i) for i in range(p.parts.count()) if p.parts.item(i).data(Qt.UserRole)==group.id)
    p.parts.setCurrentItem(group_item,QItemSelectionModel.ClearAndSelect)
    p.visibility_button.click();require(set(group.body_ids)<=p.vtk_scene.hidden_body_ids,'Group hide includes remaining visible sibling')
    p.visibility_button.click();require(p.vtk_scene.hidden_body_ids=={bid},'Group show preserves independently hidden child')
    snap('tree-child-hidden')
    base=next(g.id for g in r.snapshot.groups if g.label=='BASE')
    window._change_grouping(dict(ids=[group.id,base],name='수동 묶음'));wait()
    require(bid in p.vtk_scene.hidden_body_ids,'Hidden child remains hidden after merging with base')
    merged=next(g for g in window.import_result.snapshot.groups if g.id.startswith('manual-'))
    require(any(n.data(Qt.UserRole)=='body:'+bid for n in p.parts.all_items()),'Manual group exposes imported inner tree')
    window._change_grouping(dict(ids=[merged.id],ungroup=True));wait()
    require(bid in p.vtk_scene.hidden_body_ids and len(window.import_result.snapshot.groups)==3,'Ungroup restores components and retains hidden body')
    window._reopen(next(x for x in window.projects.list() if x.id==project.id));wait()
    require(bid in p.vtk_scene.hidden_body_ids,'Project reopen preserves child visibility')
    try:ManualGroupingService(window.database).change(window.import_result,[base],ungroup=True)
    except ValueError:locked=True
    else:locked=False
    require(locked,'Imported automatic groups cannot be ungrouped')
    p.search.setText('SUB ASSEMBLY');QApplication.processEvents()
    require(any(n.text()=='SUB ASSEMBLY' and not n.isHidden() for n in p.parts.all_items()),'Tree search keeps matching ancestry visible')
    p.search.clear()
    window._generate(base);wait()
    require(window.current_plan is not None and len(window.current_plan.steps)==2,'Normal model completes automatic sequence generation')
    auto_steps=len(window.current_plan.steps)
    window._generate_manual(dict(base=base,display_order=[g.id for g in window.import_result.snapshot.groups]));wait()
    require(len(window.current_plan.steps)==2,'Manual generation preserves leaf-part sequence units')
    p.order.setCurrentRow(0);p._order_selection();p.direction.setCurrentText('-X');p._apply_step()
    require(p.plan.steps[0].removal_direction==(-1.,0.,0.),'Sequence direction edit applied without collision check')
    window._confirm(p.plan);require(bool(window.confirmation_id),'Edited sequence confirmed')
    window._render();wait();require(bool(window.video_path and Path(window.video_path).is_file()),'Confirmed normal sequence produces MP4')
    normal_video=str(window.video_path)
    recovery_path=write_model(out/'surfaces.step',True);recovery_digest=hashlib.sha256(recovery_path.read_bytes()).hexdigest()
    project=window.projects.create('복구 검증','검증 차종','검증 품종');window._analyze(project,recovery_path,[]);wait()
    require(window.import_result.assembly_scene.recovery_required and not p.auto_generate.isEnabled(),'Surface recovery disables automatic generation')
    require(p.manual_generate.isEnabled() and p.auto_generate.toolTip(),'Manual generation available and automatic restriction explained')
    window._generate(p.base.currentData());require(window.thread is None,'Programmatic automatic generation also blocked')
    window._reopen(next(x for x in window.projects.list() if x.id==project.id));wait()
    require(not p.auto_generate.isEnabled(),'Automatic restriction remains after project reopen')
    base=next(g.id for g in window.import_result.snapshot.groups if g.label=='BASE')
    window._generate_manual(dict(base=base,display_order=[g.id for g in window.import_result.snapshot.groups]));wait()
    require(window.current_plan is not None and len(window.current_plan.steps)==2,'Recovered surface parts can be manually sequenced')
    window._confirm(p.plan);window._render();wait()
    require(bool(window.video_path and Path(window.video_path).is_file()),'Recovered sequence confirms and renders')
    stream=imageio_ffmpeg.read_frames(str(window.video_path));meta=next(stream);count=0
    for pixels in stream:
        if count==0:Image.frombytes('RGB',meta['size'],pixels).save(out/'recovered-video-frame.png')
        count+=1
    require(count>0 and meta['size']==(640,360),'Recovered MP4 fully decodes')
    snap('recovery-editor')
    def close_audit():
        for widget in QApplication.topLevelWidgets():
            if isinstance(widget,QMessageBox) and widget.windowTitle()=='불러오기 진단':widget.accept()
    QTimer.singleShot(100,close_audit);p.import_audit_button.click()
    require(True,'Import diagnostic popup opens and closes')
    recovered_steps=len(window.current_plan.steps);recovered_video=str(window.video_path)
    window._analyze(project,path,[]);wait()
    require(p.auto_generate.isEnabled() and not window.import_result.assembly_scene.recovery_required,'Normal reanalysis clears recovery restriction')
    require(hashlib.sha256(path.read_bytes()).hexdigest()==digest and hashlib.sha256(recovery_path.read_bytes()).hexdigest()==recovery_digest,'All STEP originals unchanged')
    report=dict(ok=True,verified_check_count=len(checks),checks=checks,auto_steps=auto_steps,recovered_manual_steps=recovered_steps,
        decoded_frames=count,normal_video=normal_video,recovered_video=recovered_video)
    (out/'tree-recovery-workflow.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report
