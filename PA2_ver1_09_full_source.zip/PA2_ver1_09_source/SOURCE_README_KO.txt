PA² ver1_09 GitHub 소스 전달 안내

전체 애플리케이션 소스·테스트·문서·빌드 설정과 아이콘·로고·영상 템플릿·폰트를 포함합니다.
개발 환경은 Windows x64 및 Python 3.13 x64이며 requirements-lock.txt로 의존성을 맞춥니다.

개발 실행은 scripts/setup.ps1로 환경을 구성한 뒤 run_pa2.bat를 사용합니다.
실행 파일 빌드는 scripts/build.ps1과 packaging/pa2.spec를 사용합니다.
제거 프로그램은 packaging/uninst.spec로 별도 빌드합니다.
최신 기능 안내는 docs/RELEASE_VER1_09.md와 packaging/PORTABLE_README_KO.txt를 확인하세요.

기존 공개 저장소의 데이터 경계에 따라 CAD·BREP·프로젝트 DB·로그·영상·학습 데이터와 assets/pilot 번들을 제외합니다.
별도 모델 번들이 없는 소스 빌드는 기존 규칙을 사용하며, 학습·모델 관리 코드가 포함되어 있습니다.
사내 실행 배포본에는 승인된 순서·방향 초기 모델을 함께 제공합니다.

개발 검증에서는 PA2_DATA_ROOT와 PA2_INSTALL_ROOT를 격리된 임시 경로로 설정하고
PA2_DISABLE_BACKGROUND_LEARNING=1을 사용합니다.

assets/pilot 번들에 의존하는 tests/test_v28.py의 세 항목은 별도 번들이 있을 때 실행합니다.
- test_bootstrap_is_once_only_common_models_and_rollback
- test_fixed_eval_never_in_fit_and_ties_preserved
- test_automatic_promotion_gate_and_exact_pair_rollback

SOURCE_MANIFEST.json에는 파일별 해시와 대응 EXE·사내 배포 ZIP 해시가 있습니다.
Documents의 과거 상세 명세는 해당 버전의 이력이며 최신 기능은 현재 코드 및 1_09 안내를 함께 확인하세요.
