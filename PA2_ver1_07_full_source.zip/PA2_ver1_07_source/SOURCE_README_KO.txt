PA² ver1_07 GitHub 소스 전달 안내

이 ZIP은 전체 프로그램 소스·테스트·문서·빌드 설정과 아이콘/로고/템플릿/폰트를 포함합니다.
실행 배포 ZIP과 달리 CAD/BREP·프로젝트 DB·로그·영상·학습 데이터 및 assets/pilot 전체는 제외했습니다.
초기 학습 모델/고정 참조 번들이 없으므로 별도 제공하지 않은 빌드는 기존 규칙으로 시작합니다.
학습·모델 관리 코드와 사용자 데이터의 기존 모델은 삭제하거나 변경하지 않습니다.
Windows x64, Python 3.13 x64와 requirements-lock.txt의 의존성이 필요합니다.

개발 실행: scripts/setup.ps1 → run_pa2.bat
빌드: scripts/build.ps1 (모델 번들을 별도 공급하지 않으면 초기 모델 없는 빌드)
검증은 PA2_DATA_ROOT·PA2_INSTALL_ROOT를 별도 임시 경로로 지정하고
PA2_DISABLE_BACKGROUND_LEARNING=1을 설정하세요. 실제 업무 DB로 테스트하지 마세요.

모델 번들 제외로 tests/test_v28.py 중 아래 세 테스트는 별도 번들 없이는 실행할 수 없습니다.
- test_bootstrap_is_once_only_common_models_and_rollback
- test_fixed_eval_never_in_fit_and_ties_preserved
- test_automatic_promotion_gate_and_exact_pair_rollback

이번 변경은 docs/RELEASE_VER1_07.md와 V33~V41 문서를 참고하세요.
SOURCE_MANIFEST.json에 각 파일의 해시와 대응 EXE/실행 ZIP 해시가 있습니다.
이전의 상세 기술 명세는 당시 이력이며 변경 문서를 함께 확인하세요.
