# Video font

Noto Sans KR variable font, unmodified upstream Google Fonts asset.

- Font: https://github.com/google/fonts/blob/main/ofl/notosanskr/NotoSansKR%5Bwght%5D.ttf
- License: https://github.com/google/fonts/blob/main/ofl/notosanskr/OFL.txt
- Retrieved: 2026-10-29
- SHA-256: `194018e6b2b293a7964f037b25c0249ce1418bc9ab3c971060a03aa57861e252`

The complete SIL Open Font License and copyright notice accompany the font in
`OFL-NotoSansKR.txt`. Video body weight is 400; header weight is 700. No system
installation or download is required at runtime.
