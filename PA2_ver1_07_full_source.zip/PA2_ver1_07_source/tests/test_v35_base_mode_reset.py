import copy
import pytest
from PySide6.QtWidgets import QMessageBox
from test_mentor_visuals import editor
from test_v33_improvements import capture
from pa2.domain.presentation import validate_custom_cameras,add_custom_camera


@pytest.mark.parametrize('mode',['AUTO','TOP','BOTTOM','FRONT','BACK','LEFT','RIGHT','numbered'])
def test_v35_switch_base_view_removes_named_reference_and_keeps_selected_mode(editor,monkeypatch,mode):
    p=editor;p.base_card.click();capture(p)
    monkeypatch.setattr(QMessageBox,'question',lambda *a,**k:QMessageBox.Yes)
    assert p._apply_step();old=p.plan.base_camera_mode
    if mode=='numbered':
        mode=add_custom_camera(p.plan,(0,1,0),(0,0,1));p._refresh_camera_options()
    before=copy.deepcopy(p.plan.to_dict());p.camera.setCurrentIndex(p.camera.findData(mode))
    assert p._apply_step() and old not in p.plan.custom_cameras
    assert all(s.camera_mode==mode for s in p.plan.steps)
    assert p.plan.base_camera_mode==('' if mode=='AUTO' else mode)
    assert not any(v['name']=='기준시점' for v in p.plan.custom_cameras.values())
    assert p.camera.currentData()==mode and not p.has_pending_fields()
    validate_custom_cameras(p.plan);timeline=p._timeline()
    assert timeline.start_camera is not None
    for a,b in zip(before['steps'],p.plan.to_dict()['steps']):
        assert all(a[k]==b[k] for k in ('group_id','removal_direction','assembly_direction','travel_mm'))
    p._history(False);assert p.plan.base_camera_mode==old and p.plan.custom_cameras[old]['name']=='기준시점'
