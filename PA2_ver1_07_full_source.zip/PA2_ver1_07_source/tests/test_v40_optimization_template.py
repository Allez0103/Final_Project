import copy,gc,time,weakref
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pytest
from PySide6.QtCore import QEvent,QThread,QTimer
from PySide6.QtWidgets import QApplication
from test_mentor_visuals import editor
from pa2.video.renderer import VideoRenderer
from pa2.settings.config import AppSettings

ROOT=Path(__file__).resolve().parents[1]


def test_v40_fonts_do_not_retain_renderers_and_template_is_solid_noto():
    refs=[]
    for n in range(8):
        renderer=VideoRenderer(AppSettings(),ROOT/'assets/video_template_v1.json')
        for i in range(4):
            frame=renderer._compose(np.zeros((2,2,3),np.uint8),SimpleNamespace(
                process_text=f'커버 {i} 조립',material_text='커버',caution_text=''),
                'KD1','HVJB','완제품.step',1920,1080)
        if n==0:
            pixels=np.asarray(frame)
            for name in ('header','process'):
                x,y,w,h=renderer.template['regions'][name]
                region=pixels[int(y*1080)+8:int((y+h)*1080)-8,int(x*1920)+20:int((x+w)*1920)-20]
                assert ((region==[38,51,197]).all(2)).mean()>.85
                assert ((region==255).all(2)).sum()>100
            assert renderer._font(28).getname()[0]=='Noto Sans KR'
            assert bytes(renderer._font(40,True).getmask('제목'))!=bytes(renderer._font(40).getmask('제목'))
        refs.append(weakref.ref(renderer));del frame,renderer;gc.collect()
        assert all(ref() is None for ref in refs)


def test_v40_render_cleanup_runs_on_success_failure_and_cancel(monkeypatch,tmp_path):
    renderer=VideoRenderer(AppSettings(),ROOT/'assets/video_template_v1.json')
    from PIL import Image
    for outcome in (42,RuntimeError('Scene failure'),InterruptedError('cancel')):
        renderer._overlays['test']=Image.new('RGB',(32,32))
        def run(*a,**kw):
            if isinstance(outcome,Exception):raise outcome
            return outcome
        monkeypatch.setattr(renderer,'_render_once',run)
        if isinstance(outcome,Exception):
            with pytest.raises(type(outcome)):renderer.render(None,None,None,tmp_path/'x.mp4')
        else:assert renderer.render(None,None,None,tmp_path/'x.mp4')==outcome
        assert not renderer._overlays


def test_v40_playback_computes_once_and_tracks_real_elapsed_time(editor,monkeypatch):
    import pa2.ui.model_editor as module
    import pa2.ui.transport as transport
    p=editor;p._seek(0);before=copy.deepcopy(p.plan.to_dict());calls=[];icons=[]
    original=module.scene_at
    def scene(*a,**kw):calls.append(1);return original(*a,**kw)
    monkeypatch.setattr(module,'scene_at',scene)
    original_icon=transport.transport_icon
    def icon(*a,**kw):icons.append(1);return original_icon(*a,**kw)
    monkeypatch.setattr(transport,'transport_icon',icon)
    clock=[100.];monkeypatch.setattr(module.time,'monotonic',lambda:clock[0])
    p._toggle_play();calls.clear();icons.clear()
    for _ in range(12):clock[0]+=.05;p._play_tick()
    assert p.play_time==pytest.approx(.6) and len(calls)==12 and not icons
    p._toggle_play();old=p.play_time;clock[0]+=90;p._toggle_play();clock[0]+=.1;p._play_tick()
    assert p.play_time==pytest.approx(old+.1) and p.plan.to_dict()==before
    p.play_timer.stop()


def test_v40_display_mesh_reuses_body_but_not_changed_shape_or_deflection(editor,monkeypatch):
    import pa2.rendering.vtk_scene as module
    from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
    scene=editor.result.assembly_scene;scene._display_mesh_cache.clear();scene._display_mesh_cache_bytes=0
    calls=[];original=module.tessellate_shape
    def mesh(*a):calls.append(1);return original(*a)
    monkeypatch.setattr(module,'tessellate_shape',mesh)
    a=module._display_mesh(scene,'base',.2);b=module._display_mesh(scene,'base',.2)
    assert len(calls)==1 and a[0] is b[0]
    module._display_mesh(scene,'base',.1);assert len(calls)==2
    shape=scene.shapes['base'];scene.shapes['base']=BRepPrimAPI_MakeBox(2,3,4).Shape()
    changed=module._display_mesh(scene,'base',.2)
    assert len(calls)==3 and tuple(changed[0].max(axis=0))==(2,3,4)
    assert shape.IsNull() is False
    monkeypatch.setattr(module,'DISPLAY_MESH_CACHE_BYTES',1)
    scene._display_mesh_cache.clear();scene._display_mesh_cache_bytes=0
    module._display_mesh(scene,'base',.2);assert not scene._display_mesh_cache


def test_v40_regrouped_cached_mesh_matches_fresh_mesh_and_releases_thumbnail(editor):
    from pa2.domain.models import AssemblyGroup,Bounds,PartType
    p=editor;s=p.vtk_scene;scene=p.result.assembly_scene;groups=p.result.snapshot.groups
    merged=AssemblyGroup('merged','묶음',['bolt','cover'],PartType.UNKNOWN,
        Bounds.union(g.bounds for g in groups[1:]),2,None,True)
    s.load(scene,[groups[0],merged]);s.set_view('상면');cached=s.rgb_array()
    scene._display_mesh_cache.clear();scene._display_mesh_cache_bytes=0
    s.load(scene,[groups[0],merged]);s.set_view('상면');fresh=s.rgb_array()
    assert np.array_equal(cached,fresh)
    s.load(scene,groups);assert set(s.actors)=={g.id for g in groups}
    s.thumbnail('cover');s.clear()
    assert not s.actors and s._thumbnail_renderer.GetViewProps().GetNumberOfItems()==0


def test_v40_completed_tasks_and_closed_settings_are_released(monkeypatch,tmp_path):
    from pa2.ui.main_window import MainWindow
    from pa2.ui.settings_dialog import SettingsDialog
    monkeypatch.setenv('QT_QPA_PLATFORM','offscreen');monkeypatch.setenv('PA2_DISABLE_BACKGROUND_LEARNING','1')
    monkeypatch.setenv('PA2_DATA_ROOT',str(tmp_path/'data'))
    app=QApplication.instance() or QApplication([]);window=MainWindow(ROOT);results=[]
    try:
        for _ in range(50):
            window._task(lambda progress:42,results.append)
            deadline=time.monotonic()+5
            while window.thread and time.monotonic()<deadline:app.processEvents();time.sleep(.002)
            app.sendPostedEvents(None,QEvent.DeferredDelete);app.processEvents()
            assert window.thread is None and not window.findChildren(QThread)
        assert results==[42]*50
        monkeypatch.setattr(window,'_failed',lambda *_:None)
        for error in (RuntimeError('test failure'),InterruptedError('test cancellation')):
            def fail(progress):raise error
            window._task(fail,results.append);deadline=time.monotonic()+5
            while window.thread and time.monotonic()<deadline:app.processEvents();time.sleep(.002)
            app.sendPostedEvents(None,QEvent.DeferredDelete);app.processEvents()
            assert window.thread is None and not window.findChildren(QThread)
            assert window._task_callback is None and results==[42]*50
        for _ in range(5):
            def reject():
                for dialog in window.findChildren(SettingsDialog):
                    if dialog.isVisible():dialog.reject()
            QTimer.singleShot(0,reject);window._settings()
            app.sendPostedEvents(None,QEvent.DeferredDelete);app.processEvents();gc.collect()
            assert not window.findChildren(SettingsDialog)
    finally:window.close();window.deleteLater();app.sendPostedEvents(None,QEvent.DeferredDelete)
