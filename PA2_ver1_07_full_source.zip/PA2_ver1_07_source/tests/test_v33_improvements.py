import copy
import json
import math
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace
import pytest
from PySide6.QtCore import Qt,QEvent,QItemSelectionModel
from PySide6.QtWidgets import QApplication,QMessageBox
from test_mentor_visuals import editor
from test_v19_workflow import imported
from pa2.domain.models import Plan,PlanStep,PlanningStatus,GeometryStatus


def make_plan(t):
    groups=t.result.snapshot.groups;base=t.raw[0].id
    return Plan('v33-plan',t.project.id,1,base,[g.id for g in groups],
        [PlanStep(g.id,i,(0,0,1),(0,0,-1),10) for i,g in enumerate((g for g in groups if g.id!=base),1)],
        PlanningStatus.REVIEW_REQUIRED,input_snapshot_id=t.result.snapshot.id)


def test_configuration_lock_revert_without_regeneration_and_old_confirmation(imported):
    from pa2.application.plan_service import PlanService
    from pa2.application.plan_configuration import compatible
    from pa2.application.manual_grouping import ManualGroupingService
    t=imported;service=PlanService(t.db);plan=make_plan(t)
    service.save_preset(t.project.id,t.result.snapshot.id,plan.base_group_id,[])
    cid=service.confirm(plan);before=service.load_confirmation(cid).to_dict()
    assert compatible(t.db,plan)
    service.save_preset(t.project.id,t.result.snapshot.id,plan.base_group_id,[t.auto.id])
    assert not compatible(t.db,plan)
    with pytest.raises(ValueError,match='구성'):service.save_draft(plan)
    with pytest.raises(ValueError,match='구성'):service.confirm(plan)
    service.save_preset(t.project.id,t.result.snapshot.id,plan.base_group_id,[])
    assert compatible(t.db,plan)
    grouping=ManualGroupingService(t.db)
    grouping.change(t.result,[t.auto.id,t.raw[1].id],name='합침',base_id=plan.base_group_id)
    newer=t.imports.reopen(t.project.id);assert not compatible(t.db,plan)
    with pytest.raises(ValueError):service.save_draft(plan)
    manual=next(g for g in newer.snapshot.groups if g.id.startswith('manual-'))
    grouping.change(newer,[manual.id],ungroup=True,base_id=plan.base_group_id)
    restored=t.imports.reopen(t.project.id)
    assert compatible(t.db,plan)
    newcid=service.confirm(plan)
    assert service.load_confirmation(newcid).input_snapshot_id==restored.snapshot.id
    assert service.load_confirmation(cid).to_dict()==before


def test_base_group_inherits_and_restores_base_and_exceptions(imported):
    from pa2.application.manual_grouping import ManualGroupingService
    from pa2.application.plan_service import PlanService
    t=imported;s=ManualGroupingService(t.db);base=t.raw[0].id;other=t.auto.id
    s.change(t.result,[base,other],name='고정 조립체',base_id=base,exception_ids=[other])
    new=t.imports.reopen(t.project.id);m=next(g for g in new.snapshot.groups if g.id.startswith('manual-'))
    preset=PlanService(t.db).load_preset(t.project.id,new.snapshot.id)
    assert preset['base_group_id']==m.id and not preset['exception_ids']
    s.change(new,[m.id],ungroup=True,base_id=m.id)
    restored=t.imports.reopen(t.project.id);preset=PlanService(t.db).load_preset(t.project.id,restored.snapshot.id)
    assert preset['base_group_id']==base and preset['exception_ids']==[other]
    assert {g.id for g in restored.snapshot.groups}=={g.id for g in t.result.snapshot.groups}


def test_delta_save_keeps_step_ids_and_noop_revision(imported):
    from pa2.application.plan_service import PlanService
    from pa2.storage.database import PlanStepRecord
    t=imported;s=PlanService(t.db);plan=make_plan(t);s.save_draft(plan)
    with t.db.session() as session:before={r.group_id:r.id for r in session.query(PlanStepRecord)}
    revision=plan.revision;s.save_draft(plan);assert plan.revision==revision
    plan.steps[0].caution_text='주의';s.save_draft(plan)
    with t.db.session() as session:after={r.group_id:r.id for r in session.query(PlanStepRecord)}
    assert before==after and plan.revision>revision
    assert s.load_current_draft(t.project.id).steps[0].caution_text=='주의'


def capture(p):
    p.camera.setCurrentIndex(p.camera.findData('CUSTOM_NEW'))
    camera=p.vtk_scene.renderer.GetActiveCamera()
    camera.SetPosition(90,-100,80);camera.SetFocalPoint(4,6,9);camera.SetViewUp(.2,.7,1)
    camera.SetParallelProjection(True);camera.SetParallelScale(17);camera.SetWindowCenter(.1,-.15)
    p._capture_custom_camera();return camera


def test_full_camera_framing_replays_exactly(editor):
    p=editor;cam=capture(p);expected=(cam.GetPosition(),cam.GetFocalPoint(),cam.GetParallelScale(),cam.GetWindowCenter())
    assert p._apply_step();key=p.plan.steps[0].camera_mode
    p.vtk_scene.apply(__import__('pa2.rendering.scene',fromlist=['scene_at']).scene_at(p.plan,p._timeline().duration,p.settings,p._timeline()))
    # Final stage may use its own view; inspect the captured first stage explicitly.
    from pa2.rendering.scene import scene_at
    timeline=p._timeline();p.vtk_scene.apply(scene_at(p.plan,timeline.segments[0].highlight_end,p.settings,timeline))
    cam=p.vtk_scene.renderer.GetActiveCamera()
    assert cam.GetPosition()==pytest.approx(expected[0]) and cam.GetFocalPoint()==pytest.approx(expected[1])
    assert cam.GetParallelScale()==17 and cam.GetWindowCenter()==pytest.approx(expected[3]) and cam.GetParallelProjection()
    assert p.plan.custom_cameras[key]['position']==list(expected[0])


def test_base_only_camera_global_apply_update_undo_and_numbered_library(editor,monkeypatch):
    p=editor;before=copy.deepcopy(p.plan.to_dict());p.base_card.click()
    assert p._base_editing and p.camera.isEnabled() and not p.direction.isEnabled() and not p.process.isEnabled()
    assert not p.has_pending_fields() and p.plan.to_dict()==before
    capture(p);monkeypatch.setattr(QMessageBox,'question',lambda *a,**k:QMessageBox.Yes)
    assert p._apply_step();key=p.plan.base_camera_mode
    assert key and p.plan.custom_cameras[key]['name']=='기준시점'
    assert all(s.camera_mode==key for s in p.plan.steps)
    timeline=p._timeline();assert timeline.start_camera==timeline.step_cameras[0]
    p.order.setCurrentRow(0,QItemSelectionModel.ClearAndSelect);capture(p);assert p._apply_step()
    assert p.plan.base_camera_mode==key and len(p.plan.custom_cameras)==2
    assert any(v['name'].startswith('사용자 지정') for v in p.plan.custom_cameras.values())
    p._history(False);assert all(s.camera_mode==key for s in p.plan.steps)
    p._history(False);assert not p.plan.base_camera_mode


def test_base_bulk_cancel_does_not_change_plan(editor,monkeypatch):
    p=editor;before=copy.deepcopy(p.plan.to_dict());p.base_card.click();capture(p)
    monkeypatch.setattr(QMessageBox,'question',lambda *a,**k:QMessageBox.No)
    assert not p._apply_step() and p.plan.to_dict()==before


def test_nonaxis_vector_and_exact_distance_survive_camera_and_guide_only(editor):
    p=editor;step=p.plan.steps[0];v=(.6,0,.8)
    step.removal_direction=v;step.assembly_direction=tuple(-x for x in v);step.travel_mm=12.3456789
    p.set_plan(p.plan,'test');p.thumbnail_timer.stop()
    assert '기존 경로' in p.direction.currentText()
    p.caution.setPlainText('정확한 방향 유지');assert p._apply_step()
    assert p.plan.steps[0].removal_direction==v and p.plan.steps[0].travel_mm==12.3456789


def test_stale_ui_blocks_apply_play_seek_history_and_keeps_grouping(editor):
    p=editor;before=copy.deepcopy(p.plan.to_dict());p.set_configuration_state(True)
    assert not p.order.isEnabled() and not p.apply_button.isEnabled() and not p.play.isEnabled()
    assert p.manual_generate.isEnabled() and p.parts.isEnabled()
    p._apply_step();p._toggle_play();p._seek(5000);p._history(False)
    assert p.plan.to_dict()==before and not p.play_timer.isActive()
    p.set_configuration_state(False);assert p.order.isEnabled()


def test_guide_focus_pauses_without_resuming_or_changing_target(editor):
    p=editor;target=p.order.currentItem().data(Qt.UserRole)
    p._toggle_play();assert p.play_timer.isActive()
    p.eventFilter(p.caution,QEvent(QEvent.FocusIn))
    assert not p.play_timer.isActive() and p.order.currentItem().data(Qt.UserRole)==target
    p.eventFilter(p.caution,QEvent(QEvent.FocusOut));assert not p.play_timer.isActive()


def test_selection_one_sync_and_3d_scroll_without_camera_change(editor,monkeypatch):
    p=editor;calls=[];monkeypatch.setattr(p.parts,'scrollToItem',lambda item:calls.append(item.data(Qt.UserRole)))
    cam=p.vtk_scene.renderer.GetActiveCamera();position=cam.GetPosition();before=p.selection_sync_count
    p._picked('cover');assert p.selection_sync_count==before+1
    assert calls==['cover'] and cam.GetPosition()==position
    assert p._selected()=={'cover'} and p.order.selectedItems()[0].data(Qt.UserRole)=='cover'
    p._picked('base',True);assert p._selected()=={'base','cover'} and p.base_card.isChecked()


def test_card_reorder_reuses_items(editor):
    p=editor;items={p.order.item(i).data(Qt.UserRole):p.order.item(i) for i in range(p.order.count())}
    p.order.setCurrentRow(0,QItemSelectionModel.ClearAndSelect);p.order.move_selection(1)
    assert [s.group_id for s in p.plan.steps]==['cover','bolt']
    assert all(p.order.item(i) is items[p.order.item(i).data(Qt.UserRole)] for i in range(p.order.count()))


def test_recent_generation_popup_disambiguates_counters(editor):
    p=editor;record=SimpleNamespace(metrics_json={'elapsed_sec':2.3,'tested_candidates':12,'native_path_calls':4,'unresolved_general_steps':1},
        generation_mode='auto',plan_snapshot_json={'steps':[{},{}]})
    p.set_recent_generation(record);assert p.generation_button.text()=='생성 기록'
    p.generation_button.click();assert p.generation_dialog.isVisible()
    text=p.generation_dialog.details.toPlainText()
    assert all(v in text for v in ('2.3초','2단계','12개','4회'))
    p.generation_dialog.reject();assert not p.generation_dialog.isVisible()


def test_presentation_inheritance_does_not_overwrite_new_geometry(editor):
    from pa2.application.plan_configuration import inherit_presentation
    p=editor;capture(p);p._apply_step();old=p.plan
    old.steps[0].caution_text='이어받기';new=copy.deepcopy(old);new.steps.reverse()
    new.steps[1].removal_direction=(1,0,0);new.steps[1].assembly_direction=(-1,0,0);new.steps[1].travel_mm=99
    new.steps[1].caution_text='';new.steps[1].camera_mode='AUTO'
    inherit_presentation(old,new)
    assert new.steps[1].caution_text=='이어받기' and new.steps[1].camera_mode==old.steps[0].camera_mode
    assert new.steps[1].removal_direction==(1,0,0) and new.steps[1].travel_mm==99


def test_trackball_unclamped_full_turn_keeps_pivot_distance():
    import vtk
    from pa2.rendering.orbit import TrackballCamera
    camera=vtk.vtkCamera();camera.SetPosition(0,-10,0);camera.SetViewUp(0,0,1)
    orbit=TrackballCamera(camera);orbit.rotate(0,300,600);orbit.step()
    assert camera.GetViewUp()[2]<-.999 and camera.GetPosition()[1]>9.99
    assert camera.GetDistance()==pytest.approx(10) and camera.GetFocalPoint()==(0,0,0)
    orbit.rotate(0,300,600);orbit.step();assert camera.GetPosition()==pytest.approx((0,-10,0))


def test_model_feature_cache_is_bounded_copy_safe_and_exact(editor):
    from pa2.learning.features import FeatureBuilder
    groups=editor.result.snapshot.groups;b=FeatureBuilder(groups,[],groups[0].id,'TEST');remaining={g.id for g in groups}
    a=b.rows(remaining);expected=copy.deepcopy(a);a['cover']['volume']=999
    assert b.rows(remaining)==expected and b.cache_hits==1


def test_project_vehicle_product_search_filters(tmp_path,monkeypatch):
    monkeypatch.setenv('QT_QPA_PLATFORM','offscreen')
    from pa2.cli import _runtime
    from pa2.ui.main_window import ProjectPage
    app=QApplication.instance() or QApplication([]);_,db,s,_=_runtime(tmp_path/'data')
    s.create('alpha','A','P1');s.create('beta','A','P2');s.create('gamma','B','P3')
    page=ProjectPage(s);assert page.project_list.count()==3
    page.filter_vehicle.setCurrentIndex(page.filter_vehicle.findData('A'));assert page.project_list.count()==2
    assert {page.filter_product.itemText(i) for i in range(page.filter_product.count())}=={'전체','P1','P2'}
    page.filter_product.setCurrentIndex(page.filter_product.findData('P2'));assert page.project_list.count()==1
    page.filter_vehicle.setCurrentIndex(page.filter_vehicle.findData('B'));assert page.filter_product.currentText()=='전체'
    page.filter_search.setText('gam');assert page.project_list.count()==1
    page.filter_search.setText('alpha');assert page.project_list.count()==0
    page.close();db.engine.dispose()


def test_nut_seating_plane_priority_without_boolean_or_distance(monkeypatch):
    from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox,BRepPrimAPI_MakeCylinder
    from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut
    from OCP.gp import gp_Pnt,gp_Ax2,gp_Dir
    from pa2.planning.manual import fastener_hints
    from pa2.planning.fastener_direction import assigned_direction
    from pa2.domain.models import AssemblyGroup,Bounds,PartType,ContactEdge
    axis=gp_Ax2(gp_Pnt(0,0,10),gp_Dir(0,0,1))
    nut=BRepAlgoAPI_Cut(BRepPrimAPI_MakeCylinder(axis,3,2).Shape(),BRepPrimAPI_MakeCylinder(axis,1,2).Shape()).Shape()
    plate=BRepPrimAPI_MakeBox(gp_Pnt(-5,-5,0),10,10,10).Shape()
    n=AssemblyGroup('nut','nut',['n'],PartType.NUT,Bounds(-3,-3,10,3,3,12),1,(0,0,11),True)
    p=AssemblyGroup('plate','plate',['p'],PartType.PLATE,Bounds(-5,-5,0,5,5,10),1,(0,0,50),True)
    import pa2.cad.direction_policy as policy
    monkeypatch.setattr(policy,'BRepAlgoAPI_Common',lambda *a,**k:pytest.fail('Seating hint called Boolean'))
    hints=fastener_hints([n,p],{'n':nut,'p':plate},.001,contacts=[ContactEdge('nut','plate',0)],gap=.05)
    assert hints['nut'].get('seating_direction')==pytest.approx((0,0,1))
    direction,method,_=assigned_direction(n,p,hints['nut'])
    assert direction==pytest.approx((0,0,1)) and method=='nut_away_from_seating_face'
    assert assigned_direction(n,p,{'axis':(0,0,1)})[0]==(0,0,-1)
    # A valid connected bolt head still has priority.
    bolt=replace(p,id='bolt',part_type=PartType.BOLT)
    assert assigned_direction(n,p,hints['nut'],[(bolt,{'axis':(0,0,1),'head_center':(0,0,20)})])[1]=='nut_away_from_bolt_head'
    # A plate bounding box alone cannot turn its empty hole into a seating face.
    hole=BRepPrimAPI_MakeCylinder(gp_Ax2(gp_Pnt(0,0,-1),gp_Dir(0,0,1)),4,12).Shape()
    hollow=BRepAlgoAPI_Cut(plate,hole).Shape()
    empty=fastener_hints([n,p],{'n':nut,'p':hollow},.001,contacts=[ContactEdge('nut','plate',0)],gap=.05)
    assert 'seating_direction' not in empty['nut']
    # Contact on both nut ends is ambiguous and must retain the fallback policy.
    top=replace(p,id='top',body_ids=['t'],bounds=Bounds(-5,-5,12,5,5,14))
    ambiguous=fastener_hints([n,p,top],{'n':nut,'p':plate,'t':BRepPrimAPI_MakeBox(gp_Pnt(-5,-5,12),10,10,2).Shape()},
        .001,contacts=[ContactEdge('nut','plate',0),ContactEdge('nut','top',0)],gap=.05)
    assert ambiguous['nut']['seating_ambiguous'] and 'seating_direction' not in ambiguous['nut']
    import OCP.BRepClass
    def failed_face(*args):raise RuntimeError('Malformed optional seating face')
    monkeypatch.setattr(OCP.BRepClass,'BRepClass_FaceClassifier',failed_face)
    fallback=fastener_hints([n,p],{'n':nut,'p':plate},.001,contacts=[ContactEdge('nut','plate',0)],gap=.05)
    assert fallback['nut']['axis'] and fallback['nut']['seating_ambiguous']
    assert assigned_direction(n,p,fallback['nut'])[1]=='axis_away_from_target'


def test_video_template_aligned_and_table_lines_exist(editor):
    import numpy as np
    from pa2.video.renderer import VideoRenderer
    from pa2.rendering.scene import scene_at
    root=Path(__file__).resolve().parents[1];template=json.loads((root/'assets/video_template_v1.json').read_text(encoding='utf-8'))
    regions=template['regions'];assert regions['header'][0]==regions['scene'][0]==regions['process'][0]
    assert regions['header'][2]==regions['scene'][2]==regions['process'][2]
    renderer=VideoRenderer(editor.settings,root/'assets/video_template_v1.json')
    state=scene_at(editor.plan,0,editor.settings,editor._timeline());state.caution_text=''
    image=renderer._compose(np.full((40,40,3),255,dtype=np.uint8),state,'차종','품종','assembly.step',1920,1080)
    x,y,w,h=regions['caution'];left=int(x*1920)+80;right=int((x+w)*1920)-5
    pixels=np.asarray(image);a=pixels[int(y*1080)+2:int((y+h)*1080)-2,left:right]
    assert ((a[:,:,0]==184)&(a[:,:,1]==192)&(a[:,:,2]==216)).sum()>1000


def test_unchanged_apply_previews_without_dirtying_or_saving(editor):
    p=editor;before=copy.deepcopy(p.plan.to_dict());saves=[];p.save_requested.connect(lambda *_:saves.append(1))
    p.apply_button.click();p._stop_preview()
    assert p.plan.to_dict()==before and not saves


def test_invalid_full_framing_never_inserts_partial_camera(editor):
    from pa2.domain.presentation import add_custom_camera
    plan=editor.plan;before=copy.deepcopy(plan.to_dict())
    with pytest.raises(ValueError):add_custom_camera(plan,(0,0,-1),(0,1,0),framing={'position':[1,2,3]})
    assert plan.to_dict()==before
