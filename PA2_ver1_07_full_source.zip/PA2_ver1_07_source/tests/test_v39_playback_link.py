import copy
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication
from test_mentor_visuals import editor
from test_v37_card_seek_popup import click_card


def selected(p):return {i.data(Qt.UserRole) for i in p.order.selectedItems()}


def test_v39_paused_cards_seek_both_directions_without_writes(editor):
    p=editor;p.show();QApplication.processEvents();before=copy.deepcopy(p.plan.to_dict());saves=[];p.save_requested.connect(lambda *_:saves.append(1))
    for row in (1,0,1):
        click_card(p,row);assert p.play_time==p._timeline().segments[row].camera_end
        assert selected(p)=={p.plan.steps[row].group_id} and not p.play_timer.isActive()
        assert p.scrubber.value()==round(p.play_time/p._timeline().duration*10000)
    assert not saves and p.plan.to_dict()==before


def test_v39_slider_and_playback_follow_card_and_fields_without_stopping_timer(editor):
    p=editor;before=copy.deepcopy(p.plan.to_dict());timeline=p._timeline()
    segment=timeline.segments[1];position=round((segment.highlight_end+segment.move_end)/2/timeline.duration*10000)
    p.scrubber.setValue(position)
    assert selected(p)=={p.plan.steps[1].group_id} and p.parts.selectedItems()[0].data(Qt.UserRole)==p.plan.steps[1].group_id
    assert p.order.active_step_id==p.plan.steps[1].group_id and p.distance.value()==p.plan.steps[1].travel_mm
    p.last_button.click();assert selected(p)=={p.plan.steps[-1].group_id} and p.scrubber.value()==10000
    p.first_button.click();assert p.base_card.isChecked() and not selected(p)
    p.play.click();assert p.play_timer.isActive()
    p.play_time=timeline.segments[0].move_end+.001;p._play_tick()
    assert p.play_timer.isActive() and selected(p)=={p.plan.steps[1].group_id}
    p.scrubber.setValue(1000)
    assert not p.play_timer.isActive() and p.base_card.isChecked() and p.plan.to_dict()==before


def test_v39_following_same_stage_does_not_discard_pending_guide_text(editor):
    p=editor;p.scrubber.setValue(4000)
    target=p.order.currentItem().data(Qt.UserRole);p.caution.setPlainText('입력 중')
    p._sync_playback();p._sync_playback()
    assert p.order.currentItem().data(Qt.UserRole)==target and p.caution.toPlainText()=='입력 중'
