import copy
from types import SimpleNamespace
import pytest
from PySide6.QtCore import Qt,QPoint,QPointF
from PySide6.QtGui import QWheelEvent
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication,QScrollArea,QWidget,QVBoxLayout,QLabel,QMessageBox
from test_mentor_visuals import editor
from pa2.ui.input_widgets import ScrollSafeComboBox,ScrollSafeSpinBox,ScrollSafeDoubleSpinBox
from pa2.rendering.scene import camera_for_step,_roll_camera


def wheel(widget,delta=-120):
    center=widget.rect().center()
    event=QWheelEvent(QPointF(center),QPointF(widget.mapToGlobal(center)),QPoint(),QPoint(0,delta),
        Qt.NoButton,Qt.NoModifier,Qt.NoScrollPhase,False)
    QApplication.sendEvent(widget,event);QApplication.processEvents()


@pytest.mark.parametrize('kind',[ScrollSafeComboBox,ScrollSafeSpinBox,ScrollSafeDoubleSpinBox])
def test_focused_field_wheel_scrolls_parent_without_value_changes(kind,monkeypatch):
    monkeypatch.setenv('QT_QPA_PLATFORM','offscreen');app=QApplication.instance() or QApplication([])
    scroll=QScrollArea();scroll.resize(360,220);scroll.setWidgetResizable(True)
    panel=QWidget();layout=QVBoxLayout(panel);widget=kind()
    if isinstance(widget,ScrollSafeComboBox):widget.addItems(['A','B','C']);widget.setCurrentIndex(1)
    else:widget.setRange(0,100);widget.setValue(50)
    layout.addWidget(widget)
    for i in range(30):layout.addWidget(QLabel('scroll content '+str(i)))
    scroll.setWidget(panel);scroll.show();widget.setFocus();app.processEvents()
    value=lambda:widget.currentIndex() if isinstance(widget,ScrollSafeComboBox) else widget.value()
    before=value();assert scroll.verticalScrollBar().maximum()>0
    wheel(widget);assert value()==before and scroll.verticalScrollBar().value()>0
    # Explicit keyboard editing remains possible, even after wheel suppression.
    QTest.keyClick(widget,Qt.Key_Down if isinstance(widget,ScrollSafeComboBox) else Qt.Key_Up)
    assert value()!=before
    scroll.close()


def test_editor_and_settings_use_safe_fields(editor,tmp_path):
    from pa2.settings.config import SettingsStore
    from pa2.ui.settings_dialog import SettingsDialog
    p=editor
    assert all(isinstance(w,ScrollSafeComboBox) for w in (p.base,p.direction,p.camera,p.speed))
    assert isinstance(p.distance,ScrollSafeDoubleSpinBox)
    settings=SettingsDialog(SettingsStore(tmp_path/'settings.json'),p.settings)
    assert isinstance(settings.widgets['video_encoder'],ScrollSafeComboBox)
    assert isinstance(settings.widgets['generation_timeout_sec'],ScrollSafeSpinBox)
    assert isinstance(settings.widgets['assembly_move_sec'],ScrollSafeDoubleSpinBox)
    settings.close()


def test_open_combo_popup_retains_its_own_list_scrolling(monkeypatch):
    monkeypatch.setenv('QT_QPA_PLATFORM','offscreen');app=QApplication.instance() or QApplication([])
    combo=ScrollSafeComboBox();combo.addItems([str(i) for i in range(100)]);combo.setMaxVisibleItems(4)
    combo.show();combo.showPopup();app.processEvents();view=combo.view()
    assert view.isVisible() and view.verticalScrollBar().maximum()>0
    before=combo.currentIndex();wheel(view.viewport())
    assert view.verticalScrollBar().value()>0 and combo.currentIndex()==before
    combo.hidePopup();combo.close()


@pytest.mark.parametrize('captured',[False,True])
def test_base_roll_bakes_into_global_camera_without_geometry_changes(editor,monkeypatch,captured):
    p=editor;before=copy.deepcopy(p.plan.to_dict());p.base_card.click()
    assert p._base_editing and p.camera_roll_left.isEnabled() and p.camera_roll_right.isEnabled()
    if captured:
        p.camera.setCurrentIndex(p.camera.findData('CUSTOM_NEW'));cam=p.vtk_scene.renderer.GetActiveCamera()
        cam.SetPosition(65,-80,75);cam.SetFocalPoint(7,8,3);cam.SetViewUp(.2,.4,1)
        cam.SetParallelProjection(True);cam.SetParallelScale(21);p.camera_capture_button.click()
        pending=copy.deepcopy(p._pending_custom_camera)
        from pa2.rendering.scene import CameraPose
        initial=CameraPose(tuple(pending['direction']),'CUSTOM_NEW',tuple(pending['up']))
    else:
        p.camera.setCurrentIndex(p.camera.findData('TOP'))
        initial=camera_for_step(SimpleNamespace(camera_mode='TOP',camera_roll_deg=0,assembly_direction=(0,0,-1)),camera_rolls=p.plan.camera_rolls)
    p.camera_roll_right.click();assert p._camera_roll_deg==90 and p.has_pending_fields()
    monkeypatch.setattr(QMessageBox,'question',lambda *a,**k:QMessageBox.No)
    assert not p._apply_step() and p.plan.to_dict()==before
    monkeypatch.setattr(QMessageBox,'question',lambda *a,**k:QMessageBox.Yes)
    assert p._apply_step();key=p.plan.base_camera_mode
    expected=_roll_camera(initial,90)
    stored=p.plan.custom_cameras[key] if captured else dict(view_direction=p._timeline().start_camera.view_direction,view_up=p._timeline().start_camera.view_up)
    assert stored['view_direction']==pytest.approx(expected.view_direction)
    assert stored['view_up']==pytest.approx(expected.view_up)
    assert all(s.camera_mode==key and s.camera_roll_deg==(0 if captured else 90) for s in p.plan.steps)
    assert p._camera_roll_deg==0 and p.camera_roll_label.text()=='0°' and not p.has_pending_fields()
    if captured:
        for field,value in pending['framing'].items():assert stored[field]==value
    for old,new in zip(before['steps'],p.plan.to_dict()['steps']):
        assert all(old[field]==new[field] for field in ('group_id','removal_direction','assembly_direction','travel_mm'))
    p._seek(0);cam=p.vtk_scene.renderer.GetActiveCamera()
    assert cam.GetViewUp()==pytest.approx(expected.view_up)
    p._history(False);assert p.plan.to_dict()==before


def test_base_roll_disabled_for_stale_configuration(editor):
    p=editor;p.base_card.click();p.set_configuration_state(True)
    assert not p.camera_roll_left.isEnabled() and not p.camera_roll_right.isEnabled()
    before=p._camera_roll_deg;p._rotate_camera(90);assert p._camera_roll_deg==before
