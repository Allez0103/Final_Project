import os,shutil,subprocess
from dataclasses import replace
from pathlib import Path
import pytest


def test_v41_render_title_strips_only_assembly_extension_and_keeps_project_dots(tmp_path,monkeypatch):
    from types import SimpleNamespace
    from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
    from pa2.domain.models import AssemblyGroup,Bounds,PartType,Plan,PlanningStatus
    from pa2.cad.importer import CadScene
    from pa2.settings.config import AppSettings
    from pa2.video.renderer import VideoRenderer
    group=AssemblyGroup('base','기준',['body'],PartType.BODY,Bounds(0,0,0,1,1,1),1,(.5,.5,.5),True)
    scene=CadScene(Path('source.step'),'hash','source.step','mm',[SimpleNamespace(bounds=group.bounds)],{'body':BRepPrimAPI_MakeBox(1,1,1).Shape()})
    plan=Plan('p','project',1,'base',['base'],[],PlanningStatus.COMPLETE)
    settings=replace(AppSettings(),video_width=320,video_height=180,video_encoder='libx264',highlight_sec=.1,final_hold_sec=.1)
    renderer=VideoRenderer(settings,Path(__file__).resolve().parents[1]/'assets/video_template_v1.json')
    seen=[];original=renderer._compose
    def compose(scene,state,vehicle,product,title,*size):
        seen.append(title);return original(scene,state,vehicle,product,title,*size)
    monkeypatch.setattr(renderer,'_compose',compose)
    for i,(filename,expected) in enumerate([(r'C:\parts\완제품.v2.STP','완제품.v2'),('assembly.step','assembly'),('','프로젝트.v1')]):
        seen.clear()
        renderer.render(plan,scene,[group],tmp_path/f'{i}.mp4',vehicle_name='차종',product_name='품종',project_name='프로젝트.v1',assembly_filename=filename)
        assert seen and set(seen)=={expected}


def test_v41_project_names_duplicate_history_restore_cleanup_and_legacy(tmp_path,monkeypatch):
    import imageio_ffmpeg
    from pa2.cli import _runtime
    from pa2.application.plan_service import PlanService
    from pa2.application.video_library import VideoLibrary,video_stem
    from pa2.domain.models import Plan,PlanStep,PlanningStatus
    from pa2.settings.config import AppSettings
    from pa2.video.renderer import VideoResult
    from pa2.storage.assets import sha256_file
    from pa2.storage.database import VideoRecord
    layout,db,projects,_=_runtime(tmp_path/'data');project=projects.create('HVJB 조립 시험','차종','품종')
    other=projects.create('다른 프로젝트','차종','품종');plans=PlanService(db)
    def confirm(p):return plans.confirm(Plan('plan-'+p.id,p.id,1,'base',['base','part'],[PlanStep('part',1,(0,0,1),(0,0,-1),10)],PlanningStatus.REVIEW_REQUIRED))
    cid=confirm(project);foreign=confirm(other);library=VideoLibrary(db,layout)
    fixture=tmp_path/'fixture.mp4'
    subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-v','error','-f','lavfi','-i','color=c=blue:s=64x64:r=10','-t','0.2','-c:v','libx264','-pix_fmt','yuv420p',str(fixture)],check=True,capture_output=True)
    first=library.new_path(project.id,project.name);assert first.name=='HVJB 조립 시험.mp4'
    first.parent.mkdir(parents=True);shutil.copy2(fixture,first)
    result=lambda path:VideoResult(path,sha256_file(path),.2,2,'libx264')
    library.register(project.id,cid,result(first),AppSettings(),'test')
    second=library.new_path(project.id,project.name);assert second.name=='HVJB 조립 시험 (2).mp4'
    shutil.copy2(fixture,second);library.register(project.id,cid,result(second),AppSettings(),'test')
    os.utime(first,(100,100));os.utime(second,(200,200))
    exported=first.parent/'내보낸 복사본.mp4';shutil.copy2(fixture,exported)
    legacy=first.parent/f'{cid}-00000001.mp4';shutil.copy2(fixture,legacy);os.utime(legacy,(50,50))
    assert VideoLibrary(db,layout).latest(project.id,cid)==second
    assert library.latest(project.id,foreign) is None
    projects.update(project.id,'변경된 프로젝트명')
    assert library.latest(project.id,cid)==second and library.new_path(project.id,'변경된 프로젝트명').name=='변경된 프로젝트명.mp4'
    cleanup=library.keep_latest(project.id)
    assert cleanup['kept']==str(second) and set(cleanup['deleted'])=={first.name,legacy.name}
    assert second.exists() and exported.exists()
    with db.session() as session:assert session.query(VideoRecord).count()==1
    with pytest.raises(ValueError):library.register(project.id,foreign,result(second),AppSettings(),'test')
    assert video_stem('A/B:C?')=='A_B_C_' and video_stem('CON')=='_CON' and video_stem(' .. ')=='PA2'
    assert library.new_path(project.id,'../escape').parent==second.parent


def test_v41_export_dialog_defaults_to_project_name(monkeypatch,tmp_path):
    from PySide6.QtWidgets import QApplication,QFileDialog
    from pa2.ui.video_page import VideoPage
    monkeypatch.setenv('QT_QPA_PLATFORM','offscreen');app=QApplication.instance() or QApplication([])
    page=VideoPage();page.project_name='조립 프로젝트';page.video_path=tmp_path/'old-id.mp4';seen=[]
    monkeypatch.setattr(QFileDialog,'getSaveFileName',lambda *args:(seen.append(args[2]) or ('','')))
    page._export();assert seen==['조립 프로젝트.mp4']
    page.project_name='';page._export();assert seen[-1]=='old-id.mp4'
    page.close();page.deleteLater();app.processEvents()


def test_v41_publish_never_replaces_a_file_created_while_rendering(tmp_path):
    from pa2.video.renderer import _publish
    temporary=tmp_path/'temp.mp4';destination=tmp_path/'project.mp4'
    temporary.write_bytes(b'new');destination.write_bytes(b'old')
    with pytest.raises(FileExistsError):_publish(temporary,destination)
    assert destination.read_bytes()==b'old' and temporary.read_bytes()==b'new'
