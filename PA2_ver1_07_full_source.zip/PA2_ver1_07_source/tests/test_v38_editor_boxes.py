import copy
import pytest
from PySide6.QtCore import QPoint
from PySide6.QtWidgets import QApplication
from test_mentor_visuals import editor


def inside(child,parent):
    return parent.rect().contains(child.mapTo(parent,QPoint())) and parent.rect().contains(child.mapTo(parent,child.rect().bottomRight()))


@pytest.mark.parametrize('size',[(1280,820),(1540,1010),(1760,1100)])
def test_v38_titles_and_playback_stay_inside_white_cards_and_controls_are_centered(editor,size):
    p=editor;p.resize(*size);p.show();QApplication.processEvents()
    assert p.sequence_card.objectName()==p.viewer_card.objectName()==p.playback_card.objectName()=='whiteCard'
    assert p.viewer_card is not p.playback_card and not p.viewer_card.geometry().intersects(p.playback_card.geometry())
    assert p.sequence_heading.text()=='조립 순서' and p.sequence_heading.property('cardTitle')
    assert inside(p.sequence_heading,p.sequence_card) and inside(p.order,p.sequence_card)
    assert p.sequence_card.layout().contentsMargins().top()==12
    assert inside(p.viewer_surface,p.viewer_card)
    for widget in (p.playback_bar,p.scrubber):assert inside(widget,p.playback_card)
    assert not p.playback_bar.geometry().intersects(p.scrubber.geometry())
    group=p.playback_controls;assert abs(group.geometry().center().x()-p.playback_bar.rect().center().x())<=1
    assert p.scrubber.width()==p.viewer_surface.width()


def test_v38_reparented_playback_buttons_speed_and_slider_keep_working(editor):
    p=editor;p.show();QApplication.processEvents();before=copy.deepcopy(p.plan.to_dict())
    p.first_button.click();assert p.play_time==0
    p.speed.setCurrentText('4');p.play.click();assert p.play_timer.isActive()
    p._play_tick();assert p.play_time>0
    p.play.click();assert not p.play_timer.isActive()
    p.next_button.click();assert p.play_time>=p._timeline().base_end
    p.last_button.click();assert p.play_time==p._timeline().duration
    p.first_button.click();p.previous_button.click();assert p.play_time==0
    p.scrubber.setValue(5000);p.scrubber.sliderMoved.emit(5000)
    assert p.play_time==p._timeline().duration*.5 and p.plan.to_dict()==before


def test_v38_last_button_reaches_exact_end_for_fractional_durations(editor):
    from dataclasses import replace
    p=editor;p.settings=replace(p.settings,highlight_sec=.2,assembly_move_sec=.4,final_hold_sec=.2,camera_180_sec=.3)
    p._changed();p.last_button.click()
    assert p.play_time==p._timeline().duration
    p.play.click();assert p.play_timer.isActive() and p.play_time==0
    p.play.click()
