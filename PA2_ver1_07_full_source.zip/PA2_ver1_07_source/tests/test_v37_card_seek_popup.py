import copy
from types import SimpleNamespace
from PySide6.QtCore import Qt,QPointF
from PySide6.QtGui import QMouseEvent
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication
from test_mentor_visuals import editor
from pa2.domain.models import GeometryStatus


def click_card(p,row,modifiers=Qt.NoModifier):
    item=p.order.item(row);p.order.scrollToItem(item);QApplication.processEvents()
    QTest.mouseClick(p.order.viewport(),Qt.LeftButton,modifiers,p.order.visualItemRect(item).center())


def test_v37_playing_card_click_jumps_to_target_camera_and_pauses_without_saving(editor):
    p=editor;p.show();QApplication.processEvents();p.plan.steps[0].camera_mode='FRONT';p.plan.steps[1].camera_mode='TOP'
    p._changed();before=copy.deepcopy(p.plan.to_dict());saves=[];p.save_requested.connect(lambda *_:saves.append(1))
    p._toggle_play();assert p.play_timer.isActive();click_card(p,1)
    target=p._timeline().segments[1]
    assert p.play_time==target.camera_end and not p.play_timer.isActive() and not p.preview_timer.isActive()
    assert p.order.active_step_id==p.plan.steps[1].group_id
    assert p.vtk_scene.renderer.GetActiveCamera().GetDirectionOfProjection()==p._timeline().step_cameras[1].view_direction
    assert p.plan.to_dict()==before and not saves
    p._toggle_play();click_card(p,1)
    assert not p.play_timer.isActive() and p.play_time==target.camera_end  # already-selected card


def test_v37_stopped_card_selection_now_follows_playback(editor):
    p=editor;p.show();QApplication.processEvents()
    click_card(p,1)
    assert p.play_time==p._timeline().segments[1].camera_end and p._timeline_focus and not p.play_timer.isActive()
    p._seek(0);click_card(p,0)
    assert p.play_time==p._timeline().segments[0].camera_end and not p.play_timer.isActive()


def test_v37_record_popup_never_resizes_editor_and_is_reused(editor):
    p=editor;p.show();QApplication.processEvents()
    record=SimpleNamespace(metrics_json={'elapsed_sec':3.2,'tested_candidates':10,'native_path_calls':2},
        generation_mode='auto',plan_snapshot_json={'steps':[{},{}]})
    p.set_recent_generation(record)
    geometry=lambda:(p.size(),p.parts.geometry(),p.order.geometry(),p.properties_tabs.geometry(),p.vtk_widget.geometry())
    before=geometry();p.generation_button.click();QApplication.processEvents();dialog=p.generation_dialog
    assert dialog.isVisible() and not dialog.isModal() and geometry()==before
    assert p.generation_button.text()=='생성 기록' and not p.status.isVisible()
    assert all(s in dialog.details.toPlainText() for s in ('3.2초','10개','2회','2단계'))
    dialog.reject();QApplication.processEvents();assert geometry()==before
    p.generation_button.click();assert p.generation_dialog is dialog and geometry()==before
    dialog.reject()


def test_v37_issue_badge_shows_only_real_unresolved_or_action_errors(editor):
    p=editor;assert p.issue_button.isHidden()
    p.plan.steps[0].geometry_status=GeometryStatus.DRAFT_UNRESOLVED;p._changed()
    assert not p.issue_button.isHidden() and p.issue_button.text()=='확인 필요 1개'
    p.issue_button.click();assert '경로 확인 필요' in p.generation_dialog.details.toPlainText()
    p.plan.steps[0].geometry_status=GeometryStatus.USER_CONFIRMED_UNCHECKED;p._changed()
    assert p.issue_button.isHidden()
    p.status.set_issue('앵글을 먼저 캡처하세요.');assert not p.issue_button.isHidden()
    assert '앵글을 먼저 캡처' in p.generation_dialog.details.toPlainText()
    p.status.setText('저장 완료');assert p.issue_button.isHidden();p.generation_dialog.reject()


def test_v37_ctrl_multi_selection_pauses_without_seeking(editor):
    p=editor;p.show();QApplication.processEvents();p._toggle_play();before=p.play_time
    click_card(p,1,Qt.ControlModifier)
    assert not p.play_timer.isActive() and p.play_time==before and len(p._selected())==2
