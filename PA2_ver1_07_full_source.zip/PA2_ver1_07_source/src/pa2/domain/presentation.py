"""Small presentation-only values; never used for CAD decisions or ML features."""
import copy
import uuid
import math
from .models import normalize


def camera_vectors(direction, up):
    direction = normalize(direction)
    up = normalize(up)
    dot = sum(a*b for a,b in zip(direction,up))
    up = normalize(tuple(u-dot*d for u,d in zip(up,direction)))
    return direction, up


def validate_custom_cameras(plan):
    if type(plan.next_custom_camera_index) is not int or plan.next_custom_camera_index < 1:
        raise ValueError('사용자 지정 카메라 번호가 잘못되었습니다.')
    if not isinstance(plan.custom_cameras, dict) or len(plan.custom_cameras)>1000:
        raise ValueError('사용자 지정 카메라 목록이 잘못되었습니다.')
    names=set()
    for key,value in plan.custom_cameras.items():
        if not isinstance(key,str) or not key.startswith('CUSTOM:') or str(uuid.UUID(key[7:]))!=key[7:]:
            raise ValueError('사용자 지정 카메라 ID가 잘못되었습니다.')
        name=value.get('name')
        if not isinstance(name,str) or not name.strip() or len(name)>100 or name in names:
            raise ValueError('사용자 지정 카메라 이름이 잘못되었습니다.')
        names.add(name)
        camera_vectors(value['view_direction'],value['view_up'])
        validate_framing(value)
    if plan.base_camera_mode and plan.base_camera_mode not in {'TOP','BOTTOM','FRONT','BACK','LEFT','RIGHT'} and plan.base_camera_mode not in plan.custom_cameras:
        raise ValueError('기준시점이 없습니다.')
    for step in plan.steps:
        if step.camera_mode.startswith('CUSTOM:') and step.camera_mode not in plan.custom_cameras:
            raise ValueError('단계에서 사용하는 사용자 지정 카메라가 없습니다.')
    if not isinstance(plan.display_names,dict) or any(not isinstance(k,str) or not isinstance(n,str) or not n.strip() or len(n)>200
            or any(ord(c)<32 for c in n) for k,n in plan.display_names.items()):
        raise ValueError('부품 표시명이 잘못되었습니다.')


def validate_framing(value):
    fields=('position','focal_point','parallel_scale','view_angle','parallel_projection','window_center')
    if not any(k in value for k in fields):return
    if not all(k in value for k in fields):raise ValueError('카메라 구도 정보가 불완전합니다.')
    for key,length in (('position',3),('focal_point',3),('window_center',2)):
        v=value[key]
        if not isinstance(v,(list,tuple)) or len(v)!=length or not all(isinstance(x,(int,float)) and math.isfinite(x) for x in v):
            raise ValueError('카메라 위치가 유효하지 않습니다.')
    if math.dist(value['position'],value['focal_point'])<=1e-9:raise ValueError('카메라와 주시점은 달라야 합니다.')
    if not math.isfinite(value['parallel_scale']) or value['parallel_scale']<=0:raise ValueError('확대값이 유효하지 않습니다.')
    if not math.isfinite(value['view_angle']) or not 0<value['view_angle']<180:raise ValueError('화각이 유효하지 않습니다.')
    if type(value['parallel_projection']) is not bool:raise ValueError('투영 방식이 유효하지 않습니다.')
    direction,_=camera_vectors(value['view_direction'],value['view_up'])
    actual=normalize(tuple(b-a for a,b in zip(value['position'],value['focal_point'])))
    if sum(a*b for a,b in zip(direction,actual))<1-1e-7:raise ValueError('카메라 위치와 방향이 다릅니다.')


def add_custom_camera(plan, direction, up, *, framing=None):
    direction,up=camera_vectors(direction,up)
    key='CUSTOM:'+str(uuid.uuid4())
    used={v['name'] for v in plan.custom_cameras.values()}
    while f'사용자 지정{plan.next_custom_camera_index}' in used:plan.next_custom_camera_index+=1
    value={'name':f'사용자 지정{plan.next_custom_camera_index}',
           'view_direction':list(direction),'view_up':list(up)}
    if framing:
        value.update(copy.deepcopy(framing));validate_framing(value)
    plan.custom_cameras=copy.deepcopy(plan.custom_cameras)
    plan.custom_cameras[key]=value
    plan.next_custom_camera_index+=1
    return key


def prune_custom_cameras(plan):
    used={s.camera_mode for s in plan.steps}
    if plan.base_camera_mode:used.add(plan.base_camera_mode)
    plan.custom_cameras={k:v for k,v in plan.custom_cameras.items() if k in used}


def set_base_camera(plan, direction, up, *, framing=None):
    old=plan.base_camera_mode
    counter=plan.next_custom_camera_index
    key=add_custom_camera(plan,direction,up,framing=framing)
    plan.next_custom_camera_index=counter
    # A single named reference is updated; ordinary numbered presets stay independent.
    if old and old in plan.custom_cameras:
        plan.custom_cameras[old]=plan.custom_cameras.pop(key);key=old
    plan.custom_cameras[key]['name']='기준시점'
    plan.base_camera_mode=key
    for step in plan.steps:step.camera_mode=key;step.camera_roll_deg=0
    prune_custom_cameras(plan)
    return key


def set_base_camera_mode(plan,mode,roll_delta=0):
    """Use a selected mode directly; do not turn AUTO into a fixed custom pose."""
    standard={'AUTO','TOP','BOTTOM','FRONT','BACK','LEFT','RIGHT'}
    if mode not in standard and mode not in plan.custom_cameras:raise ValueError('카메라 시점이 없습니다.')
    if type(roll_delta) is not int or roll_delta not in (0,90,180,270):raise ValueError('화면 회전값이 잘못되었습니다.')
    plan.base_camera_mode='' if mode=='AUTO' else mode
    if mode.startswith('CUSTOM:'):
        plan.custom_cameras=copy.deepcopy(plan.custom_cameras)
        value=plan.custom_cameras[mode];direction,up=camera_vectors(value['view_direction'],value['view_up'])
        right=(direction[1]*up[2]-direction[2]*up[1],direction[2]*up[0]-direction[0]*up[2],direction[0]*up[1]-direction[1]*up[0])
        angle=math.radians(roll_delta)
        value['view_up']=list(normalize(tuple(math.cos(angle)*u-math.sin(angle)*r for u,r in zip(up,right))))
        for step in plan.steps:step.camera_mode=mode;step.camera_roll_deg=0
    elif mode=='AUTO':
        plan.camera_rolls={k:(v+roll_delta)%360 for k,v in plan.camera_rolls.items()}
        for key in standard-{'AUTO'}:plan.camera_rolls.setdefault(key,roll_delta)
        for step in plan.steps:step.camera_mode='AUTO';step.camera_roll_deg=(step.camera_roll_deg+roll_delta)%360
    else:
        roll=(plan.camera_rolls.get(mode,0)+roll_delta)%360
        plan.camera_rolls=dict(plan.camera_rolls,**{mode:roll})
        for step in plan.steps:step.camera_mode=mode;step.camera_roll_deg=roll
    prune_custom_cameras(plan)
