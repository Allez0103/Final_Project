"""Opt-in native GUI regression on newly created disposable STEP/projects only."""
import copy
import json
import os
import time
from dataclasses import replace
from pathlib import Path


def verify(window,output_dir):
    checks=[]
    def require(condition,message='V32 native verification failed'):
        if not condition:raise AssertionError(message)
        checks.append(message)
    from PySide6.QtCore import Qt,QTimer,QItemSelectionModel,QPoint,QRectF
    from PySide6.QtGui import QImage,QPainter
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QApplication,QLineEdit
    from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox,BRepPrimAPI_MakeCylinder
    from OCP.gp import gp_Pnt
    from OCP.STEPControl import STEPControl_Writer,STEPControl_AsIs
    from OCP.IFSelect import IFSelect_RetDone
    from pa2.cad.shapes import compound
    from pa2.domain.models import PartType
    from pa2.rendering.scene import build_timeline,camera_pose_angle,scene_at
    from pa2.ui.settings_dialog import SettingsDialog
    root=Path(os.environ['PA2_DATA_ROOT']).resolve()
    output_dir=Path(output_dir).resolve()
    if not root.is_relative_to(output_dir):raise ValueError('V32 smoke requires a disposable data root below its output directory.')
    started=time.monotonic();errors=[]
    window._failed=lambda message:errors.append(message)
    settings=replace(window.settings,video_width=640,video_height=360,video_fps=15,
        highlight_sec=.05,assembly_move_sec=.12,final_hold_sec=.1,camera_180_sec=.5,video_encoder='libx264',swap_mouse_buttons=False)
    window.settings=settings;window.model_page.apply_settings(settings)
    inputs=root/'synthetic-inputs';inputs.mkdir(parents=True,exist_ok=True)
    # gp_Ax2 is used by the cylinder overload; keep the model simple and analytic.
    from OCP.gp import gp_Ax2,gp_Dir
    shapes=[BRepPrimAPI_MakeBox(20,20,5).Shape(),
            BRepPrimAPI_MakeBox(gp_Pnt(0,0,5),20,20,2).Shape(),
            BRepPrimAPI_MakeCylinder(gp_Ax2(gp_Pnt(9,9,0),gp_Dir(0,0,1)),1,10).Shape()]
    def write(shape,path):
        writer=STEPControl_Writer();writer.Transfer(shape,STEPControl_AsIs)
        status=writer.Write(str(path))
        require(status==IFSelect_RetDone and path.is_file(),'Synthetic STEP written')
    assembly=inputs/'V32_ASSEMBLY.step';write(compound(shapes),assembly)
    parts=[]
    for name,shape in zip(('MBD-V32.STP','COV-V32.STP','BLT-V32.STP'),shapes):
        path=inputs/name;write(shape,path);parts.append(path)
    project=window.projects.create('V32 isolated workflow','TEST','TEST')
    window.current_project=project
    imported=window.imports.prepare(project.id,assembly,parts,settings)
    window._analyzed(imported)
    p=window.model_page;QApplication.processEvents()
    require(len(imported.snapshot.groups)==3 and p.plan is None)
    cover=next(g for g in imported.snapshot.groups if g.part_type==PartType.COVER)
    identity=(cover.id,cover.display_name,list(cover.body_ids),cover.part_type)
    item=next(p.parts.item(i) for i in range(p.parts.count()) if p.parts.item(i).data(Qt.UserRole)==cover.id)
    p.parts.scrollToItem(item);QApplication.processEvents()
    QTest.mouseClick(p.parts.viewport(),Qt.RightButton,Qt.NoModifier,p.parts.visualItemRect(item).center())
    QApplication.processEvents();line=next(e for e in p.parts.findChildren(QLineEdit) if e.isVisible())
    line.setText('사용자 커버');QTest.keyClick(line,Qt.Key_Return);QApplication.processEvents()
    require(cover.label=='사용자 커버' and identity==(cover.id,cover.display_name,list(cover.body_ids),cover.part_type))
    require(not p.plan)
    def wait_task():
        limit=time.monotonic()+120
        while (window.thread and window.thread.isRunning()) or not p.isEnabled():
            QTest.qWait(20)
            if time.monotonic()>limit:raise TimeoutError('V32 workflow task timeout')
        QApplication.processEvents()
        if errors:raise RuntimeError(str(errors))
    window._generate(p.base.currentData());wait_task()
    require(window.current_plan and len(window.current_plan.steps)==2)
    automatic=window.plans.generation(window.current_plan.id)
    auto_metrics=copy.deepcopy(automatic.metrics_json)
    original_geometry=[(s.group_id,s.removal_direction,s.assembly_direction) for s in p.plan.steps]
    require(any(s.material_text=='사용자 커버' for s in p.plan.steps if s.group_id==cover.id))
    window._generate_manual({'base':p.base.currentData(),'display_order':[g.id for g in imported.snapshot.groups]});wait_task()
    manual=window.plans.generation(window.current_plan.id)
    require(manual.metrics_json['native_path_calls']==0 and len(window.current_plan.steps)==2)
    row=next(i for i,s in enumerate(p.plan.steps) if s.group_id==cover.id)
    def choose(row):
        p.order.clearSelection();p.order.setCurrentRow(row,QItemSelectionModel.ClearAndSelect)
        p.order.scrollToItem(p.order.item(row));QApplication.processEvents()
    choose(row)
    p.camera.setCurrentIndex(p.camera.findData('CUSTOM_NEW'))
    camera=p.vtk_scene.renderer.GetActiveCamera()
    camera.SetPosition(60,-90,70);camera.SetFocalPoint(10,10,2.5);camera.SetViewUp(.3,.1,1)
    direction=tuple(camera.GetDirectionOfProjection());up=tuple(camera.GetViewUp())
    QTest.mouseClick(p.camera_capture_button,Qt.LeftButton)
    require(p._pending_custom_camera)
    QTest.mouseClick(p.apply_button,Qt.LeftButton)
    key=p.plan.steps[row].camera_mode
    require(key in p.plan.custom_cameras and p._step_preview and not p.has_pending_fields())
    p._stop_preview();other=1-row;choose(other)
    p.camera.setCurrentIndex(p.camera.findData(key));QTest.mouseClick(p.apply_button,Qt.LeftButton);p._stop_preview()
    require(all(s.camera_mode==key for s in p.plan.steps))
    p.camera.setCurrentIndex(p.camera.findData('CUSTOM_NEW'))
    camera.SetPosition(-80,40,100);camera.SetFocalPoint(10,10,2.5);camera.SetViewUp(0,1,0)
    QTest.mouseClick(p.camera_capture_button,Qt.LeftButton);QTest.mouseClick(p.apply_button,Qt.LeftButton);p._stop_preview()
    key2=p.plan.steps[other].camera_mode;require(key2!=key and len(p.plan.custom_cameras)==2)
    p.camera.setCurrentText('TOP');QTest.mouseClick(p.apply_button,Qt.LeftButton);p._stop_preview()
    require(key2 not in p.plan.custom_cameras)
    p._history(False);require(key2 in p.plan.custom_cameras)
    p._history(True);require(key2 not in p.plan.custom_cameras)
    p._history(False);require(key2 in p.plan.custom_cameras)
    # Real modal settings dialog, save its toggle, verify live application and disk.
    def set_toggle():
        dialog=next(w for w in QApplication.topLevelWidgets() if isinstance(w,SettingsDialog) and w.isVisible())
        dialog.widgets['swap_mouse_buttons'].click();dialog._save()
    QTimer.singleShot(100,set_toggle);window._settings()
    require(window.settings.swap_mouse_buttons and p.vtk_scene.swap_mouse_buttons)
    require(window.settings_store.load().swap_mouse_buttons)
    # Test both drag buttons through the real QVTK widget, not just a mapping helper.
    def drag(button):
        before=tuple(camera.GetPosition())
        point=p.vtk_widget.rect().center()
        QTest.mousePress(p.vtk_widget,button,Qt.NoModifier,point)
        QTest.mouseMove(p.vtk_widget,point+QPoint(45,20),30)
        QTest.mouseRelease(p.vtk_widget,button,Qt.NoModifier,point+QPoint(45,20))
        QApplication.processEvents()
        return before,tuple(camera.GetPosition())
    choose(row);focal=tuple(camera.GetFocalPoint());before,after=drag(Qt.RightButton)
    require(before!=after and tuple(camera.GetFocalPoint())==focal)
    direction_before=tuple(camera.GetDirectionOfProjection());focal=tuple(camera.GetFocalPoint())
    before,after=drag(Qt.LeftButton)
    require(before!=after and tuple(camera.GetFocalPoint())!=focal)
    require(sum(abs(a-b) for a,b in zip(direction_before,camera.GetDirectionOfProjection()))<1e-8)
    selected_plan=copy.deepcopy(p.plan.to_dict())
    loaded=window.plans.load_current_draft(project.id)
    require(loaded.custom_cameras==p.plan.custom_cameras)
    require(loaded.display_names[cover.id]=='사용자 커버')
    reopened=window.imports.reopen(project.id)
    require(next(g for g in reopened.snapshot.groups if g.id==cover.id).label=='사용자 커버')
    def snapshot(name):
        QApplication.processEvents();pixels=p.vtk_scene.rgb_array()
        require(float(pixels.reshape(-1,3).std(axis=0).max())>5)
        pixmap=window.grab();painter=QPainter(pixmap)
        image=QImage(pixels.data,pixels.shape[1],pixels.shape[0],pixels.shape[1]*3,QImage.Format_RGB888).copy()
        origin=p.vtk_widget.mapTo(window,QPoint(0,0))
        painter.drawImage(QRectF(origin.x(),origin.y(),p.vtk_widget.width(),p.vtk_widget.height()),image)
        painter.end();pixmap.save(str(output_dir/name))
    p.properties_tabs.setCurrentIndex(0);window.tabs.setCurrentWidget(p);snapshot('v32-motion.png')
    p.properties_tabs.setCurrentIndex(1);snapshot('v32-guide.png')
    p._stop_preview();window._confirm(p.plan)
    require(window.confirmation_id and window.video_page.generate.isEnabled())
    confirmed=window.plans.load_confirmation(window.confirmation_id)
    timeline=build_timeline(confirmed,window.settings,imported.assembly_scene.bounds)
    require(timeline.first_view_landscape_roll_deg==0)
    if confirmed.steps[0].camera_mode==key:
        require(sum(abs(a-b) for a,b in zip(timeline.start_camera.view_direction,direction))<1e-8)
    window._render();wait_task()
    require(window.video_path and window.video_path.is_file())
    window.video_page.player.stop()
    import imageio_ffmpeg
    frames=imageio_ffmpeg.read_frames(str(window.video_path));metadata=next(frames)
    frame_count=sum(1 for _ in frames)
    require(frame_count==max(1,round(timeline.duration*window.settings.video_fps)))
    result=dict(ok=True,project_id=project.id,groups=3,rename_before_generation=True,
        original_group_identity_unchanged=True,automatic_steps=len(automatic.plan_snapshot_json['steps']),
        automatic_metrics=auto_metrics,manual_steps=2,manual_native_paths=manual.metrics_json['native_path_calls'],
        property_tabs=['동작설정','작업 안내'],single_apply_preview_button=True,
        custom_camera_count=len(confirmed.custom_cameras),custom_capture_reuse_gc_undo_redo=True,
        custom_angles_survive_reopen=True,toggle_saved_live_native_drag_test=True,
        separate_confirmation=True,video_path=str(window.video_path),video_frames=frame_count,
        video_size=metadata['size'],video_fps=metadata['fps'],verified_check_count=len(checks),seconds=time.monotonic()-started)
    (output_dir/'v32-workflow.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return result
