"""Opt-in native card-seek and detached generation-popup regression."""
import copy,json,time
from pathlib import Path


def verify(window,output_dir):
    from .ui_verify_v34 import verify as prior_verify
    previous=prior_verify(window,output_dir)
    from PySide6.QtCore import Qt,QPoint,QRectF
    from PySide6.QtGui import QImage,QPainter
    from PySide6.QtWidgets import QApplication
    from PySide6.QtTest import QTest
    from .domain.models import GeometryStatus
    p=window.model_page;checks=[];started=time.monotonic();output_dir=Path(output_dir)
    def require(value,message):
        if not value:raise AssertionError(message)
        checks.append(message)
    def close(a,b):return len(a)==len(b) and max(abs(x-y) for x,y in zip(a,b))<1e-7
    window.tabs.setCurrentWidget(p)
    p.plan.steps[0].camera_mode='FRONT';p.plan.steps[0].camera_roll_deg=0
    p.plan.steps[1].camera_mode=p.plan.base_camera_mode;p.plan.steps[1].camera_roll_deg=90
    p.set_plan(p.plan,'카드 이동 검증');p.thumbnail_timer.stop()
    before=copy.deepcopy(p.plan.to_dict());saves=[];p.save_requested.connect(lambda *_:saves.append(1))
    p._toggle_play();require(p.play_timer.isActive(),'Assembly playback starts before card click')
    target=p.order.item(1);p.order.scrollToItem(target);QApplication.processEvents()
    QTest.mouseClick(p.order.viewport(),Qt.LeftButton,pos=p.order.visualItemRect(target).center());QApplication.processEvents()
    timeline=p._timeline();expected=timeline.step_cameras[1];cam=p.vtk_scene.renderer.GetActiveCamera()
    require(not p.play_timer.isActive() and not p.preview_timer.isActive(),'Native card click pauses both playback timers')
    require(abs(p.play_time-timeline.segments[1].camera_end)<1e-9,'Card click seeks exact target camera end')
    require(p.order.active_step_id==p.plan.steps[1].group_id,'Clicked stage becomes active')
    require(close(cam.GetDirectionOfProjection(),expected.view_direction) and close(cam.GetViewUp(),expected.view_up),'Captured camera direction and screen roll restored')
    require(close(cam.GetPosition(),expected.position) and close(cam.GetFocalPoint(),expected.focal_point),'Captured position and focal point restored')
    require(abs(cam.GetParallelScale()-expected.parallel_scale)<1e-7 and cam.GetParallelProjection()==expected.parallel_projection,'Captured zoom and projection restored')
    require(p.plan.to_dict()==before and not saves,'Playback navigation never writes plan values')
    p._toggle_play();QTest.mouseClick(p.order.viewport(),Qt.LeftButton,pos=p.order.visualItemRect(target).center())
    require(not p.play_timer.isActive(),'Already selected card also seeks and pauses')
    geometry=lambda:(p.size(),p.vtk_widget.geometry(),p.parts.geometry(),p.order.geometry(),p.properties_tabs.geometry())
    p.state_label.setText('편집본 저장됨 · 순서 확정 필요');original=geometry()
    p.generation_button.click();QTest.qWait(50);dialog=p.generation_dialog
    require(dialog.isVisible() and not dialog.isModal(),'Generation record opens as nonmodal popup')
    require(geometry()==original,'Opening record popup preserves all editor panel geometry')
    require('생성 시간:' in dialog.details.toPlainText() and '신규 경로 검사 수:' in dialog.details.toPlainText(),'Popup separates generation time and native check count')
    require(not p.status.isVisible() and p.generation_button.text()=='생성 기록','Verbose inline records and duplicate notices hidden')
    dialog.reject();QTest.qWait(30);require(geometry()==original,'Closing record popup preserves all editor panel geometry')
    status=p.plan.steps[0].geometry_status;p.plan.steps[0].geometry_status=GeometryStatus.DRAFT_UNRESOLVED;p._changed()
    require(p.issue_button.isVisible() and p.issue_button.text()=='확인 필요 1개','Only unresolved item displays compact warning badge')
    p.issue_button.click();require(p.generation_dialog is dialog and '경로 확인 필요' in dialog.details.toPlainText(),'Issue button reuses record popup and shows details')
    dialog.grab().save(str(output_dir/'record-popup.png'));dialog.reject()
    p.plan.steps[0].geometry_status=status;p._changed()
    require(not p.issue_button.isVisible(),'Resolved issue badge disappears')
    p._stop_preview();p.play_timer.stop();pixels=p.vtk_scene.rgb_array();pixmap=window.grab();painter=QPainter(pixmap)
    image=QImage(pixels.data,pixels.shape[1],pixels.shape[0],pixels.shape[1]*3,QImage.Format_RGB888).copy()
    origin=p.vtk_widget.mapTo(window,QPoint(0,0));painter.drawImage(QRectF(origin.x(),origin.y(),p.vtk_widget.width(),p.vtk_widget.height()),image)
    painter.end();pixmap.save(str(output_dir/'editor-compact-footer.png'))
    result=dict(ok=True,previous_checks=sum(previous[k] for k in ('previous_v32_checks','previous_v33_checks','verified_check_count')),
        checks=checks,verified_check_count=len(checks),seconds=time.monotonic()-started)
    (output_dir/'v37-workflow.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return result
