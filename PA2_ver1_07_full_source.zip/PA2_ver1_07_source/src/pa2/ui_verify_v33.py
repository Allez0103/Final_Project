"""Isolated native end-to-end checks for configuration, cameras and video."""
import copy,json,os,time
from pathlib import Path


def verify(window,output_dir):
    from .ui_verify_v32 import verify as previous_verify
    previous=previous_verify(window,output_dir)
    from PySide6.QtCore import Qt,QTimer,QItemSelectionModel,QPoint,QRectF
    from PySide6.QtGui import QImage,QPainter
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QApplication,QMessageBox
    from pa2.domain.models import PartType
    from pa2.application.plan_configuration import compatible
    p=window.model_page;checks=[];errors=[];started=time.monotonic()
    def require(value,message):
        if not value:raise AssertionError(message)
        checks.append(message)
    root=Path(os.environ['PA2_DATA_ROOT']).resolve();output_dir=Path(output_dir).resolve()
    if not root.is_relative_to(output_dir):raise ValueError('Disposable test root required')
    window._failed=lambda message:errors.append(message)
    def wait_task():
        limit=time.monotonic()+180
        while (window.thread and window.thread.isRunning()) or not p.isEnabled():
            QTest.qWait(20)
            if time.monotonic()>limit:raise TimeoutError('V33 task timeout')
        QApplication.processEvents()
        if errors:raise RuntimeError(str(errors))
    def select(gid):
        window.tabs.setCurrentWidget(p);p._stop_preview();p.play_timer.stop()
        if gid==p.plan.base_group_id:p.base_card.click()
        else:
            row=next(i for i in range(p.order.count()) if p.order.item(i).data(Qt.UserRole)==gid)
            p.order.setCurrentRow(row,QItemSelectionModel.ClearAndSelect);p.order.scrollToItem(p.order.item(row));QApplication.processEvents()
    def snapshot(name):
        QApplication.processEvents();pixels=p.vtk_scene.rgb_array();pixmap=window.grab();painter=QPainter(pixmap)
        image=QImage(pixels.data,pixels.shape[1],pixels.shape[0],pixels.shape[1]*3,QImage.Format_RGB888).copy()
        origin=p.vtk_widget.mapTo(window,QPoint(0,0))
        painter.drawImage(QRectF(origin.x(),origin.y(),p.vtk_widget.width(),p.vtk_widget.height()),image)
        painter.end();pixmap.save(str(output_dir/name))
    project=window.current_project;groups=window.import_result.snapshot.groups
    base=p.plan.base_group_id;cover=next(g.id for g in groups if g.part_type==PartType.COVER)
    old_plan_id=p.plan.id;old_cid=window.confirmation_id
    old_confirmation=window.plans.load_confirmation(old_cid).to_dict()
    select(cover);require(p.plan.id==old_plan_id,'Existing V32 plan remains editable')
    p._picked(base,True);require(p._selected()=={base,cover} and p.base_card.isChecked(),'Parts/card/base selection shared')
    p._picked(cover);require(p._selected()=={cover},'Plain 3D selection clears other choices')
    p.set_exceptions([cover]);window._save_preset()
    require(p.configuration_stale and not window.video_page.generate.isEnabled(),'Exception change locks old confirmed sequence')
    window._change_grouping({'ids':[base,cover],'name':'고정 조립체','ungroup':False});wait_task()
    manual=next(g.id for g in window.import_result.snapshot.groups if g.id.startswith('manual-'))
    require(p.base.currentData()==manual and not p.exception_ids,'Base grouping inherits base and clears exceptions')
    require(p.plan.id==old_plan_id and p.configuration_stale and not p.order.isEnabled(),'Old reference plan survives grouping and is locked')
    require(p.manual_generate.isEnabled() and p.parts.isEnabled(),'Configuration controls remain usable while stale')
    require(not p._apply_step(),'Stale reference cannot apply fields')
    window._change_grouping({'ids':[manual],'ungroup':True});wait_task()
    require(p.base.currentData()==base and p.exception_ids==[cover],'Ungroup restores original base and exceptions')
    p.set_exceptions([]);window._save_preset()
    require(not p.configuration_stale and p.plan.id==old_plan_id,'Exact configuration revert reuses old sequence without regeneration')
    require(compatible(window.database,p.plan),'Semantic configuration comparison survives snapshot changes')
    require(window.plans.load_confirmation(old_cid).to_dict()==old_confirmation,'Previous confirmation remains immutable')
    select(base);require(p.camera.isEnabled() and not p.process.isEnabled() and not p.distance.isEnabled(),'Base exposes camera-only properties')
    require(not p.has_pending_fields(),'Selecting base alone never changes camera settings')
    p.camera.setCurrentIndex(p.camera.findData('CUSTOM_NEW'))
    cam=p.vtk_scene.renderer.GetActiveCamera();cam.SetPosition(65,-80,75);cam.SetFocalPoint(7,8,3)
    cam.SetViewUp(.2,.4,1);cam.SetParallelProjection(True);cam.SetParallelScale(21);cam.SetWindowCenter(.08,-.06)
    expected=(tuple(cam.GetPosition()),tuple(cam.GetFocalPoint()))
    p.camera_capture_button.click();require(p._pending_custom_camera is not None,'Base camera capture staged')
    def approve():
        box=next((w for w in QApplication.topLevelWidgets() if isinstance(w,QMessageBox) and w.isVisible()),None)
        if box:box.button(QMessageBox.Yes).click()
    QTimer.singleShot(100,approve);p.apply_button.click();QApplication.processEvents()
    base_camera=p.plan.base_camera_mode
    require(base_camera and p.plan.custom_cameras[base_camera]['name']=='기준시점','Named base camera stored')
    require(all(s.camera_mode==base_camera for s in p.plan.steps),'Base camera bulk-applies to every step')
    require(tuple(cam.GetPosition())==expected[0] and tuple(cam.GetFocalPoint())==expected[1],'Captured position and focal point replay exactly')
    require(cam.GetParallelProjection() and abs(cam.GetParallelScale()-21)<1e-8,'Zoom and projection preserved in playback')
    p._history(False);require(not p.plan.base_camera_mode,'Base camera bulk operation is undoable')
    p._history(True);require(p.plan.base_camera_mode==base_camera,'Base camera bulk operation is redoable')
    select(cover);p.properties_tabs.setCurrentIndex(1);p.caution.setPlainText('체결 위치 확인')
    p.apply_button.click();p._stop_preview()
    saved_distance=next(s.travel_mm for s in p.plan.steps if s.group_id==cover)
    p._toggle_play();require(p.play_timer.isActive(),'Assembly playback starts')
    p.caution.setFocus();QTest.mouseClick(p.caution.viewport(),Qt.LeftButton);QApplication.processEvents()
    require(not p.play_timer.isActive(),'Guide input pauses playback without changing edit target')
    window._generate_manual({'base':base,'display_order':[g.id for g in window.import_result.snapshot.groups]});wait_task()
    require(p.plan.id!=old_plan_id and len(p.plan.steps)==2,'Regeneration creates a new complete manual draft')
    step=next(s for s in p.plan.steps if s.group_id==cover)
    require(step.caution_text=='체결 위치 확인' and step.camera_mode==base_camera,'Same-ID guide and camera survive regeneration')
    require(p.plan.base_camera_mode==base_camera,'Base view survives regeneration with unchanged base')
    require('수동생성' in p.generation_button.toolTip(),'Recent generation restores saved mode and counters')
    p.generation_button.click();require(p.generation_dialog.isVisible(),'Recent generation popup opens')
    p.generation_dialog.reject();require(not p.generation_dialog.isVisible(),'Recent generation popup closes')
    select(cover);p.properties_tabs.setCurrentIndex(0);snapshot('v33-camera.png')
    window._confirm(p.plan)
    require(window.confirmation_id!=old_cid and window.video_page.generate.isEnabled(),'New draft requires and accepts explicit reconfirmation')
    window._render();wait_task();require(window.video_path and window.video_path.is_file(),'Updated template video exported from frozen confirmation')
    import imageio_ffmpeg
    from PIL import Image
    import numpy as np
    frames=imageio_ffmpeg.read_frames(str(window.video_path));metadata=next(frames);count=0
    for raw in frames:
        if count==0:Image.fromarray(np.frombuffer(raw,np.uint8).reshape(metadata['size'][1],metadata['size'][0],3)).save(output_dir/'v33-video-first.png')
        count+=1
    require(count>0,'Entire MP4 decoded')
    cid=window.confirmation_id;confirmed=window.plans.load_confirmation(cid).to_dict()
    window._reopen(next(q for q in window.projects.list() if q.id==project.id));wait_task()
    require(window.confirmation_id==cid and window.plans.load_confirmation(cid).to_dict()==confirmed,'Saved project reopens with immutable full camera confirmation')
    require(p.plan.base_camera_mode==base_camera and not p.configuration_stale,'Base view and configuration status persist across reopen')
    require('수동생성' in p.generation_button.toolTip(),'Recent generation restored on project reopen')
    window.projects.create('필터용 프로젝트','OTHER','OTHER_PRODUCT');window.project_page.refresh()
    page=window.project_page;page.filter_vehicle.setCurrentIndex(page.filter_vehicle.findData('TEST'))
    require(page.project_list.count()==1,'Vehicle filter narrows existing projects')
    page.filter_vehicle.setCurrentIndex(page.filter_vehicle.findData('OTHER'))
    require(page.filter_product.currentText()=='전체' and page.filter_product.findData('OTHER_PRODUCT')>=0,'Vehicle changes reset product filter and refresh choices')
    page.filter_search.setText('없는 이름');require(page.project_list.count()==0,'Project name search composes with filters')
    result=dict(ok=True,previous_v32_checks=previous['verified_check_count'],checks=checks,
        verified_check_count=len(checks),video_frames=count,video_size=metadata['size'],video_path=str(window.video_path),
        project_id=project.id,seconds=time.monotonic()-started)
    (output_dir/'v33-workflow.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return result
