"""Opt-in scoped layout/playback checks; no import/planning/video pipeline run."""
import copy,json
from pathlib import Path


def verify(window,output_dir):
    from types import SimpleNamespace
    from dataclasses import replace
    from PySide6.QtCore import QPoint,QRectF
    from PySide6.QtGui import QImage,QPainter
    from PySide6.QtWidgets import QApplication
    from PySide6.QtTest import QTest
    from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
    from OCP.gp import gp_Pnt
    from .cad.importer import CadScene
    from .domain.models import AssemblyGroup,Bounds,PartType,Plan,PlanStep,PlanningStatus
    checks=[];p=window.model_page;output_dir=Path(output_dir)
    def require(value,message):
        if not value:raise AssertionError(message)
        checks.append(message)
    def inside(child,parent):
        return parent.rect().contains(child.mapTo(parent,QPoint())) and parent.rect().contains(child.mapTo(parent,child.rect().bottomRight()))
    specs=[('base',Bounds(0,0,0,20,20,4)),('cover',Bounds(0,0,4,20,20,6)),('bracket',Bounds(2,2,6,8,8,10))]
    groups=[AssemblyGroup(g,g,[g],PartType.BODY if g=='base' else PartType.COVER,b,1,b.center,True) for g,b in specs]
    shapes={g.id:BRepPrimAPI_MakeBox(gp_Pnt(g.bounds.xmin,g.bounds.ymin,g.bounds.zmin),*g.bounds.size).Shape() for g in groups}
    scene=CadScene(Path('synthetic'),'layout','source','mm',[SimpleNamespace(bounds=g.bounds) for g in groups],shapes)
    result=SimpleNamespace(snapshot=SimpleNamespace(groups=groups,contacts=[]),assembly_scene=scene,cache_hits=0,cache_misses=0)
    settings=replace(window.settings,highlight_sec=.2,assembly_move_sec=.4,final_hold_sec=.2,camera_180_sec=.3)
    p.set_result(result,settings)
    plan=Plan('layout','layout-project',1,'base',[g.id for g in groups],
        [PlanStep(gid,i,(0,0,1),(0,0,-1),12,camera_mode='TOP') for i,gid in enumerate(('cover','bracket'),1)],PlanningStatus.COMPLETE)
    p.set_plan(plan,'배치 확인');p.thumbnail_timer.stop();window.tabs.setCurrentWidget(p)
    for size in ((1280,820),(1540,1010)):
        window.resize(*size);QTest.qWait(30)
        require(inside(p.sequence_heading,p.sequence_card),'Sequence title enclosed by white card '+str(size))
        require(p.sequence_heading.property('cardTitle')==p.parts_heading.property('cardTitle')==p.properties_heading.property('cardTitle'),'All panel titles share style '+str(size))
        require(inside(p.viewer_surface,p.viewer_card) and all(inside(w,p.playback_card) for w in (p.playback_bar,p.scrubber)),'Viewer and playback enclosed by separate cards '+str(size))
        require(not p.viewer_card.geometry().intersects(p.playback_card.geometry()) and not p.playback_bar.geometry().intersects(p.scrubber.geometry()),'Viewer/playback/slider never overlap '+str(size))
        require(abs(p.playback_controls.geometry().center().x()-p.playback_bar.rect().center().x())<=1,'Transport group horizontally centered '+str(size))
    before=copy.deepcopy(p.plan.to_dict());saves=[];p.save_requested.connect(lambda *_:saves.append(1))
    p.first_button.click();p.speed.setCurrentText('4');p.play.click();p._play_tick()
    require(p.play_timer.isActive() and p.play_time>0,'Centered play button and 4x speed work')
    p.play.click();require(not p.play_timer.isActive(),'Centered pause button works')
    p.next_button.click();require(p.play_time>=p._timeline().base_end,'Next-step button works')
    p.last_button.click();require(p.play_time==p._timeline().duration,'Last-step button works')
    p.first_button.click();p.previous_button.click();require(p.play_time==0,'First/previous buttons work')
    p.scrubber.setValue(5000);p.scrubber.sliderMoved.emit(5000)
    require(abs(p.play_time-p._timeline().duration*.5)<1e-9,'Embedded slider seeks correctly')
    require(p.plan.to_dict()==before and not saves,'Playback controls never modify or save plan data')
    pixels=p.vtk_scene.rgb_array();require(float(pixels.reshape(-1,3).std(axis=0).max())>5,'Native 3D viewport renders geometry')
    pixmap=window.grab();painter=QPainter(pixmap)
    image=QImage(pixels.data,pixels.shape[1],pixels.shape[0],pixels.shape[1]*3,QImage.Format_RGB888).copy()
    origin=p.vtk_widget.mapTo(window,QPoint(0,0));painter.drawImage(QRectF(origin.x(),origin.y(),p.vtk_widget.width(),p.vtk_widget.height()),image)
    painter.end();pixmap.save(str(output_dir/'layout-preview.png'))
    report=dict(ok=True,scope='Changed editor layout and playback controls only',checks=checks,verified_check_count=len(checks))
    (output_dir/'layout-workflow.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report
