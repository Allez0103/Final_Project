"""Opt-in project-name video storage, export, reopen and cleanup workflow."""
import hashlib,json,shutil,time
from dataclasses import replace
from pathlib import Path


def verify(window,output_dir):
    from PySide6.QtWidgets import QApplication,QFileDialog
    from PySide6.QtCore import QEvent
    from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
    from OCP.gp import gp_Pnt
    from OCP.STEPControl import STEPControl_Writer,STEPControl_AsIs
    from .cad.shapes import compound
    from .video.renderer import VideoRenderer
    from .application.video_library import VideoLibrary
    from .storage.database import VideoRecord
    import imageio_ffmpeg
    out=Path(output_dir);checks=[];captured=[]
    def require(value,message):
        if not value:raise AssertionError(message)
        checks.append(message)
    def flush():
        QApplication.processEvents();QApplication.sendPostedEvents(None,QEvent.DeferredDelete);QApplication.processEvents()
    def wait():
        deadline=time.monotonic()+60
        while window.thread and time.monotonic()<deadline:flush();time.sleep(.005)
        require(window.thread is None,'Background task finished');flush()
    source=out/'완제품.v2.STP';writer=STEPControl_Writer()
    writer.Transfer(compound([BRepPrimAPI_MakeBox(gp_Pnt(x,0,0),10,10,10).Shape() for x in (0,20,40)]),STEPControl_AsIs)
    writer.Write(str(source));source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
    project=window.projects.create('영상 파일명 검증','검증 차종','검증 품종')
    window.settings=replace(window.settings,video_width=320,video_height=180,video_fps=10,
        video_encoder='libx264',highlight_sec=.1,assembly_move_sec=.1,final_hold_sec=.1,camera_180_sec=.2)
    window._analyze(project,source,[]);wait()
    require(window.import_result is not None,'Synthetic project analyzed')
    p=window.model_page
    window._generate_manual({'base':p.base.currentData(),'display_order':[g.id for g in window.import_result.snapshot.groups]});wait()
    require(window.current_plan is not None and len(window.current_plan.steps)==2,'Manual sequence available')
    window._confirm(p.plan);cid=window.confirmation_id
    require(bool(cid),'Sequence confirmation saved')
    original=VideoRenderer._compose
    def compose(self,scene,state,vehicle,product,title,*size):
        captured.append(title);return original(self,scene,state,vehicle,product,title,*size)
    VideoRenderer._compose=compose
    try:
        window._render();wait();first=Path(window.video_path)
        require(first.name=='영상 파일명 검증.mp4' and first.is_file(),'First output uses project name')
        first_hash=hashlib.sha256(first.read_bytes()).hexdigest()
        window._render();wait();second=Path(window.video_path)
        require(second.name=='영상 파일명 검증 (2).mp4' and second.is_file(),'Duplicate output gets a numeric suffix')
        require(hashlib.sha256(first.read_bytes()).hexdigest()==first_hash,'Second render preserves first file')
    finally:VideoRenderer._compose=original
    require(captured and set(captured)=={'완제품.v2'},'All rendered title frames omit STEP extension and keep internal dot')
    stream=imageio_ffmpeg.read_frames(str(second));info=next(stream);frames=sum(1 for _ in stream)
    require(info['size']==(320,180) and frames>0,'Named output completely decodes')
    seen=[];dialog=QFileDialog.getSaveFileName
    QFileDialog.getSaveFileName=lambda *args:(seen.append(args[2]) or ('',''))
    try:window.video_page._export()
    finally:QFileDialog.getSaveFileName=dialog
    require(seen==['영상 파일명 검증.mp4'],'Export dialog defaults to project name')
    exported=out/'별도 내보내기.mp4'
    VideoRenderer(window.settings,window.app_root/'assets/video_template_v1.json').export(second,exported)
    library=VideoLibrary(window.database,window.layout)
    require(library.latest(project.id,cid)==second,'Latest project-named video associated with correct confirmation')
    window._reopen(next(x for x in window.projects.list() if x.id==project.id));wait()
    require(window.video_path==second and window.video_page.project_name==project.name,'Project reopen restores named video and export name')
    window._keep_latest_video();wait()
    require(not first.exists() and second.exists() and exported.exists(),'Cleanup removes older owned video and preserves newest/export')
    with window.database.session() as session:count=session.query(VideoRecord).filter_by(confirmation_id=cid).count()
    require(count==1,'Cleanup retains one corresponding video record')
    require(window.confirmation_id==cid and hashlib.sha256(source.read_bytes()).hexdigest()==source_hash,'Confirmation and source STEP unchanged')
    report=dict(ok=True,verified_check_count=len(checks),checks=checks,first=first.name,latest=str(second),
        export_default=seen[0],title=captured[0],decoded_frames=frames)
    (out/'video-names-workflow.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report
