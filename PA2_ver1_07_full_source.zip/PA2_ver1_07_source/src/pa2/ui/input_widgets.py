"""Form fields keep their values while the surrounding panel scrolls.

Deliver the closed field's wheel event to the enclosing scroll area. Simply
ignoring it can leave some focused fields swallowing the panel's scroll.
A combo popup uses its own item view and still scrolls normally.
Mouse clicks, typing, arrow buttons and keyboard navigation remain available.
"""
from PySide6.QtCore import QPointF
from PySide6.QtGui import QWheelEvent
from PySide6.QtWidgets import QComboBox,QSpinBox,QDoubleSpinBox,QAbstractScrollArea,QApplication


def _scroll_panel(widget,event):
    parent=widget.parentWidget()
    while parent is not None:
        if isinstance(parent,QAbstractScrollArea):
            viewport=parent.viewport()
            forwarded=QWheelEvent(QPointF(viewport.mapFromGlobal(event.globalPosition().toPoint())),
                event.globalPosition(),event.pixelDelta(),event.angleDelta(),event.buttons(),event.modifiers(),
                event.phase(),event.inverted(),event.source(),event.pointingDevice())
            QApplication.sendEvent(viewport,forwarded)
            event.accept()  # Do not deliver the same native scroll twice.
            return
        parent=parent.parentWidget()
    event.ignore()


class ScrollSafeComboBox(QComboBox):
    def wheelEvent(self,event):_scroll_panel(self,event)


class ScrollSafeSpinBox(QSpinBox):
    def wheelEvent(self,event):_scroll_panel(self,event)


class ScrollSafeDoubleSpinBox(QDoubleSpinBox):
    def wheelEvent(self,event):_scroll_panel(self,event)
