"""Toggle a sole selected part on a plain click, preserving Qt multi-selection."""
from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QApplication, QListWidget, QStyledItemDelegate, QAbstractItemView


class PartNameDelegate(QStyledItemDelegate):
    def setEditorData(self,editor,index):
        editor.setText(index.data(Qt.UserRole+1) or index.data(Qt.DisplayRole))
        editor.selectAll()

    def setModelData(self,editor,model,index):
        self.parent().rename_requested.emit(index.data(Qt.UserRole),editor.text())


class PartListWidget(QListWidget):
    rename_requested = Signal(str,str)
    def __init__(self, parent=None):
        super().__init__(parent)
        self._toggle_press = None
        self.setItemDelegate(PartNameDelegate(self))
        self.setEditTriggers(QAbstractItemView.NoEditTriggers)

    def mousePressEvent(self, event):
        self._toggle_press = None
        item = self.itemAt(event.position().toPoint())
        if event.button()==Qt.RightButton:
            if item is not None:self.editItem(item)
            event.accept();return
        if (event.button() == Qt.LeftButton and not event.modifiers()
                and item is not None and self.selectedItems() == [item]):
            self._toggle_press = (item, event.position().toPoint())
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        pending = self._toggle_press
        self._toggle_press = None
        super().mouseReleaseEvent(event)
        if pending and event.button() == Qt.LeftButton and not event.modifiers():
            item, origin = pending
            point = event.position().toPoint()
            if (self.itemAt(point) is item and self.selectedItems() == [item]
                    and (point-origin).manhattanLength() < QApplication.startDragDistance()):
                self.clearSelection()
