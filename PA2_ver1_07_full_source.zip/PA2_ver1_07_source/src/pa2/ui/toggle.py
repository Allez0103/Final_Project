"""Keyboard-accessible binary switch retaining QCheckBox semantics."""
from PySide6.QtCore import Qt, QSize, QRectF
from PySide6.QtGui import QPainter, QColor
from PySide6.QtWidgets import QCheckBox
from .theme import PRIMARY


class ToggleSwitch(QCheckBox):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setFixedSize(48,28)
        self.setCursor(Qt.PointingHandCursor)

    def sizeHint(self):return QSize(48,28)

    def hitButton(self,point):return self.rect().contains(point)

    def paintEvent(self,event):
        painter=QPainter(self);painter.setRenderHint(QPainter.Antialiasing)
        painter.setOpacity(1 if self.isEnabled() else .4)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor(PRIMARY if self.isChecked() else '#9AA5B1'))
        painter.drawRoundedRect(QRectF(2,3,44,22),11,11)
        painter.setBrush(QColor('white'));painter.drawEllipse(QRectF(27 if self.isChecked() else 5,6,16,16))
        if self.hasFocus():
            painter.setBrush(Qt.NoBrush);painter.setPen(QColor(PRIMARY))
            painter.drawRoundedRect(QRectF(0,1,47,26),12,12)
