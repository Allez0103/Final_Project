"""Generation details live outside the editor's layout."""
from PySide6.QtCore import Signal
from PySide6.QtWidgets import QLabel,QDialog,QVBoxLayout,QPlainTextEdit,QDialogButtonBox


class DetailMessage(QLabel):
    changed=Signal(str,bool)
    def setText(self,text):
        super().setText(text);self.changed.emit(text,False)
    def set_issue(self,text):
        super().setText(text);self.changed.emit(text,True)


class GenerationRecordDialog(QDialog):
    def __init__(self,parent):
        super().__init__(parent);self.setWindowTitle('생성 기록');self.resize(640,450);self.setModal(False)
        layout=QVBoxLayout(self);self.details=QPlainTextEdit();self.details.setReadOnly(True)
        self.details.setAccessibleName('최근 생성 기록과 확인 항목');layout.addWidget(self.details)
        buttons=QDialogButtonBox(QDialogButtonBox.Close);buttons.rejected.connect(self.reject);layout.addWidget(buttons)

    def update_record(self,summary,issues,notice,diagnostics=''):
        body=summary
        if issues:body+='\n\n확인 필요\n'+'\n'.join(issues)
        if notice:body+='\n\n최근 안내\n'+notice
        if issues and diagnostics:body+='\n\n상세 판정 기록\n'+diagnostics
        if body!=self.details.toPlainText():
            bar=self.details.verticalScrollBar();position=bar.value()
            self.details.setPlainText(body);bar.setValue(position)
