"""Cheap semantic configuration checks; never call CAD or modify old confirmations."""
import copy
import hashlib
import json
from sqlalchemy import select
from pa2.storage.database import (Project, ImportSnapshotRecord, AssemblyGroupRecord,
    GroupMember, PlanningPresetRecord, GenerationRecord)


def signature(database, snapshot_id, base, exceptions):
    with database.session() as session:
        snapshot=session.get(ImportSnapshotRecord,snapshot_id)
        if snapshot is None:return ''
        rows=list(session.scalars(select(AssemblyGroupRecord).where(AssemblyGroupRecord.snapshot_id==snapshot_id)))
        members=list(session.scalars(select(GroupMember).where(GroupMember.group_id.like(snapshot_id+':%'))))
        groups={r.id:[r.id.split(':',1)[1],r.part_type,[]] for r in rows}
        for m in members:
            if m.group_id in groups:groups[m.group_id][2].append(m.body_id.split(':',1)[1])
        raw=dict(asset=snapshot.assembly_asset_hash,base=base,exceptions=sorted(set(exceptions)),
                 groups=sorted((g,t,sorted(bs)) for g,t,bs in groups.values()))
    return hashlib.sha256(json.dumps(raw,sort_keys=True).encode()).hexdigest()


def current_configuration(database, project_id):
    with database.session() as session:
        p=session.get(Project,project_id)
        preset=session.get(PlanningPresetRecord,project_id)
        if not p:return None
        return (p.current_snapshot_id,preset.base_group_id if preset else None,
                list(preset.exception_ids_json) if preset else [])


def expected_signature(database,plan):
    if plan.configuration_signature:return plan.configuration_signature
    with database.session() as session:
        g=session.query(GenerationRecord).filter_by(plan_id=plan.id).first()
        exceptions=(g.metrics_json or {}).get('collision_exception_ids',[]) if g else [
            s.group_id for s in plan.steps if s.geometry_status.value=='USER_COLLISION_EXCEPTION']
    return signature(database,plan.input_snapshot_id,plan.base_group_id,exceptions)


def compatible(database,plan):
    current=current_configuration(database,plan.project_id)
    if not current:return False
    sid,base,exceptions=current
    # Old projects without presets still use the plan's stored base.
    return bool(sid and expected_signature(database,plan)==signature(database,sid,base or plan.base_group_id,exceptions))


def inherit_presentation(previous,plan):
    """Transfer same-ID presentation only, never order, direction or distance."""
    if not previous:return plan
    old={s.group_id:s for s in previous.steps}
    for step in plan.steps:
        prior=old.get(step.group_id)
        if prior:
            for key in ('camera_mode','camera_roll_deg','process_text','material_text','caution_text','material_auto','process_auto'):
                setattr(step,key,copy.deepcopy(getattr(prior,key)))
    plan.custom_cameras=copy.deepcopy(previous.custom_cameras)
    plan.camera_rolls=copy.deepcopy(previous.camera_rolls)
    plan.next_custom_camera_index=previous.next_custom_camera_index
    if previous.base_group_id==plan.base_group_id:plan.base_camera_mode=previous.base_camera_mode
    from pa2.domain.presentation import prune_custom_cameras
    prune_custom_cameras(plan)
    return plan
