"""Manage only completed, project-owned videos; never exported copies."""
import re
import subprocess
import uuid
from pathlib import Path

import imageio_ffmpeg
from sqlalchemy import select
from pa2.storage.database import ConfirmationRecord, Project, VideoRecord


NAME=re.compile(r'^([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})(?:-[0-9a-f]{8})?\.mp4$',re.I)


def video_stem(project_name):
    """A Windows-safe display name; project IDs never become visible filenames."""
    name=re.sub(r'[<>:"/\\|?*\x00-\x1f]','_',str(project_name)).strip().rstrip(' .')[:100].rstrip(' .')
    if not name:name='PA2'
    if re.fullmatch(r'CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9]',name.split('.')[0],re.I):name='_'+name
    return name


def complete_video(path):
    """Decode a tail frame: incomplete/unfinalized containers are not latest."""
    try:
        result=subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-hide_banner','-loglevel','error',
            '-sseof','-1','-i',str(path),'-map','0:v:0','-frames:v','1','-progress','pipe:1','-f','null','-'],
            capture_output=True,text=True,timeout=15,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        frames=[int(line.split('=',1)[1]) for line in result.stdout.splitlines() if line.startswith('frame=')]
        return result.returncode==0 and bool(frames and frames[-1]>0)
    except (OSError,subprocess.TimeoutExpired):return False


class VideoLibrary:
    def __init__(self,database,layout):self.database,self.layout=database,layout

    def _directory(self,project_id):
        if not re.fullmatch(r'[A-Za-z0-9_-]+',project_id):raise ValueError('잘못된 프로젝트 ID입니다.')
        root=self.layout.projects.resolve()
        requested=root/project_id/'videos'
        directory=requested.resolve()
        if directory!=requested or not directory.is_relative_to(root) or directory.parent.parent!=root:
            raise ValueError('프로젝트 영상 경로가 관리 영역 밖입니다.')
        return directory

    def new_path(self,project_id,project_name):
        directory=self._directory(project_id);stem=video_stem(project_name)
        path=directory/(stem+'.mp4');index=2
        while path.exists() or path.is_symlink():
            path=directory/f'{stem} ({index}).mp4';index+=1
        return path

    def register(self,project_id,confirmation_id,result,settings,template_version):
        directory=self._directory(project_id);path=Path(result.path)
        if path.is_symlink() or path.resolve().parent!=directory or not path.is_file():
            raise ValueError('프로젝트 관리 영상만 등록할 수 있습니다.')
        relative=path.resolve().relative_to(self.layout.root.resolve()).as_posix()
        with self.database.session() as session:
            confirmation=session.get(ConfirmationRecord,confirmation_id)
            if confirmation is None or confirmation.project_id!=project_id:raise ValueError('확정본과 프로젝트가 다릅니다.')
            existing=session.scalar(select(VideoRecord).where(VideoRecord.relative_path==relative))
            if existing:
                if existing.confirmation_id!=confirmation_id:raise ValueError('다른 확정본에 등록된 영상입니다.')
                return
            session.add(VideoRecord(id=str(uuid.uuid4()),confirmation_id=confirmation_id,template_version=template_version,
                relative_path=relative,width=settings.video_width,height=settings.video_height,fps=settings.video_fps,
                duration_sec=result.duration_sec,checksum=result.checksum))

    def _owned(self,project_id,confirmation_id=None):
        directory=self._directory(project_id)
        with self.database.session() as session:
            if session.get(Project,project_id) is None:raise KeyError('프로젝트가 없습니다.')
            confirmations=set(session.scalars(select(ConfirmationRecord.id).where(ConfirmationRecord.project_id==project_id)))
            if confirmation_id is not None:confirmations &= {confirmation_id}
            registered=set(session.scalars(select(VideoRecord.relative_path).where(VideoRecord.confirmation_id.in_(confirmations))))
        rows=[]
        for path in directory.glob('*.mp4'):
            match=NAME.fullmatch(path.name)
            if path.is_symlink() or path.resolve().parent!=directory or not path.is_file():continue
            relative=path.relative_to(self.layout.root.resolve()).as_posix()
            legacy=match and match.group(1) in confirmations
            if not legacy and relative not in registered:continue
            stat=path.stat()
            rows.append((path,stat.st_mtime_ns,stat.st_size))
        return sorted(rows,key=lambda row:(row[1],row[0].name),reverse=True)

    def latest(self,project_id,confirmation_id):
        # Restoring a project must not launch an FFmpeg subprocess on the UI
        # thread. New entries are registered only after a successful render;
        # the media player reports playback errors for externally damaged files.
        return next((path for path,_,size in self._owned(project_id,confirmation_id) if size>0),None)

    def completed(self,project_id):
        return [row for row in self._owned(project_id) if complete_video(row[0])]

    def keep_latest(self,project_id):
        rows=self.completed(project_id)
        if not rows:return {'kept':None,'deleted':[],'freed_bytes':0,'errors':[]}
        kept,kept_time,kept_size=rows[0]
        # Recheck the retained file immediately before any destructive operation.
        stat=kept.stat()
        if (stat.st_mtime_ns,stat.st_size)!=(kept_time,kept_size) or not complete_video(kept):
            raise ValueError('최신 영상이 변경됐습니다. 삭제하지 않았습니다.')
        deleted=[];errors=[];freed=0
        with self.database.session() as session:
            for path,mtime,size in rows[1:]:
                try:
                    stat=path.stat()
                    if path.is_symlink() or path.resolve().parent!=kept.parent or (stat.st_mtime_ns,stat.st_size)!=(mtime,size):
                        errors.append({'name':path.name,'error':'파일 변경 감지'});continue
                    path.unlink()
                    relative=path.relative_to(self.layout.root.resolve()).as_posix()
                    session.query(VideoRecord).filter(VideoRecord.relative_path==relative).delete(synchronize_session=False)
                    deleted.append(path.name);freed+=size
                except OSError as exc:errors.append({'name':path.name,'error':str(exc)})
        return {'kept':str(kept),'deleted':deleted,'freed_bytes':freed,'errors':errors}
