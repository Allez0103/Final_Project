"""Project-local labels; imported classifier names/identities are never rewritten."""
import copy
from pa2.storage.database import Project, ProjectAppearanceRecord


class AppearanceService:
    def __init__(self,database):self.database=database

    def load(self,project_id):
        with self.database.session() as session:
            row=session.get(ProjectAppearanceRecord,project_id)
            return copy.deepcopy(row.payload_json) if row else {}

    def apply_names(self,project_id,groups):
        names=self.load(project_id).get('display_names',{})
        for group in groups:group.user_display_name=names.get(group.id,'')
        return names

    def rename(self,project_id,group_id,name):
        name=name.strip()
        if not name or len(name)>200 or any(ord(c)<32 for c in name):
            raise ValueError('부품 이름은 줄바꿈 없이 1~200자로 입력하세요.')
        with self.database.session() as session:
            project=session.get(Project,project_id)
            if project is None:raise KeyError('프로젝트를 찾을 수 없습니다.')
            from pa2.storage.database import AssemblyGroupRecord
            if not project.current_snapshot_id or session.get(AssemblyGroupRecord,project.current_snapshot_id+':'+group_id) is None:
                raise ValueError('현재 모델에 없는 부품입니다.')
            row=session.get(ProjectAppearanceRecord,project_id)
            if row is None:
                row=ProjectAppearanceRecord(project_id=project_id,payload_json={});session.add(row)
            payload=copy.deepcopy(row.payload_json or {})
            payload['display_names']=dict(payload.get('display_names',{}),**{group_id:name})
            row.payload_json=payload
        return name
