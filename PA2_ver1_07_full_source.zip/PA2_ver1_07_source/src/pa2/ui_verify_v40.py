"""Opt-in runtime checks: bounded resources, linked playback and actual MP4s."""
import copy,gc,json,time,weakref
from pathlib import Path


def verify(window,output_dir):
    from .ui_verify_v39 import verify as prior_verify
    previous=prior_verify(window,output_dir)
    import numpy as np
    import imageio_ffmpeg
    from dataclasses import replace
    from PySide6.QtCore import QEvent,QThread,QTimer
    from PySide6.QtWidgets import QApplication
    from .ui.settings_dialog import SettingsDialog
    from .video.renderer import VideoRenderer
    from .runtime import resource_root
    from .rendering.scene import scene_at
    p=window.model_page;p.play_timer.stop();out=Path(output_dir);root=resource_root();checks=[]
    def require(value,message):
        if not value:raise AssertionError(message)
        checks.append(message)
    def flush():
        QApplication.processEvents();QApplication.sendPostedEvents(None,QEvent.DeferredDelete);QApplication.processEvents()
    def task(function):
        results=[];window._task(function,results.append);deadline=time.monotonic()+90
        while window.thread and time.monotonic()<deadline:flush();time.sleep(.005)
        flush();require(window.thread is None and len(results)==1,'Worker result delivered and thread released')
        require(not window.findChildren(QThread),'No completed QThread remains')
        return results[0]
    for _ in range(5):task(lambda progress:42)
    for _ in range(5):
        def reject():
            for dialog in window.findChildren(SettingsDialog):
                if dialog.isVisible():dialog.reject()
        QTimer.singleShot(0,reject);window._settings();flush();gc.collect()
        require(not window.findChildren(SettingsDialog),'Closed settings dialog released')
    before=copy.deepcopy(p.plan.to_dict());scene=p.result.assembly_scene;groups=p.result.snapshot.groups
    require(scene._display_mesh_cache_bytes<=64*1024**2,'Display cache bounded to 64 MiB')
    renderer=VideoRenderer(p.settings,root/'assets/video_template_v1.json',root/'assets/thn_logo.png')
    frame=scene_at(p.plan,0,p.settings,p._timeline());frame.material_text='브래킷';frame.caution_text='체결 위치 확인'
    from .rendering.vtk_scene import VtkScene
    preview=VtkScene(offscreen=True)
    try:
        preview.load(scene,groups);preview.apply(frame,1382,864)
        template=renderer._compose(preview.rgb_array(),frame,'검증 차종','조립품','완제품.step',1920,1080)
    finally:preview.render_window.Finalize()
    template.save(out/'video-template-preview.png');pixels=np.asarray(template)
    for name in ('header','process'):
        x,y,w,h=renderer.template['regions'][name]
        panel=pixels[int(y*1080)+8:int((y+h)*1080)-8,int(x*1920)+20:int((x+w)*1920)-20]
        require(float((panel==[38,51,197]).all(2).mean())>.85,name+' solid primary background')
        require(int((panel==255).all(2).sum())>100,name+' white text')
    require(renderer._font(28).getname()[0]=='Noto Sans KR','Bundled Noto Sans KR loads without OS font dependency')
    require(bytes(renderer._font(40,True).getmask('제목'))!=bytes(renderer._font(40).getmask('제목')),'Header bold weight differs from body weight')
    refs=[]
    for _ in range(8):
        r=VideoRenderer(p.settings,root/'assets/video_template_v1.json')
        r._compose(np.zeros((2,2,3),np.uint8),frame,'차종','품종','완제품.step',1920,1080)
        refs.append(weakref.ref(r));del r;gc.collect()
    require(all(r() is None for r in refs),'Font cache retains no renderers after eight compositions')
    renders=[]
    settings=replace(p.settings,video_encoder='libx264',highlight_sec=.12,assembly_move_sec=.2,final_hold_sec=.12)
    for name,plan in [('original',copy.deepcopy(p.plan)),('reordered',copy.deepcopy(p.plan))]:
        if name=='reordered':
            plan.steps.reverse()
            for index,step in enumerate(plan.steps,1):step.step_index=index
        r=VideoRenderer(settings,root/'assets/video_template_v1.json',root/'assets/thn_logo.png')
        result=task(lambda progress:r.render(plan,scene,groups,out/(name+'.mp4'),vehicle_name='검증 차종',product_name='조립품',project_name=name))
        require(not r._overlays,'Render completion clears full-size panel cache')
        stream=imageio_ffmpeg.read_frames(str(result.path));info=next(stream);decoded=sum(1 for _ in stream)
        require(info['size']==(1920,1080) and decoded==result.frame_count,'1080p MP4 completely decodes: '+name)
        require([s.group_id for s in plan.steps]==([s.group_id for s in p.plan.steps] if name=='original' else [s.group_id for s in reversed(p.plan.steps)]),'Requested order preserved in '+name)
        renders.append(dict(name=name,path=str(result.path),frames=decoded,duration=result.duration_sec,encoder=result.encoder))
    require(p.plan.to_dict()==before,'Verification never modifies the user plan')
    window.video_page.rendered(out/'reordered.mp4');deadline=time.monotonic()+10
    while window.video_page.player.duration()==0 and time.monotonic()<deadline:flush();time.sleep(.01)
    require(window.video_page.player.duration()>0,'Generated MP4 loads in native video player')
    window.video_page.player.play();deadline=time.monotonic()+5
    while window.video_page.decoded_preview_frames==0 and time.monotonic()<deadline:flush();time.sleep(.01)
    window.video_page.player.pause()
    require(window.video_page.decoded_preview_frames>0,'Native video player displays decoded frames')
    report=dict(ok=True,previous_checks=previous['previous_checks']+previous['verified_check_count'],
        verified_check_count=len(checks),checks=checks,renders=renders)
    (out/'optimization-template-workflow.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report
