"""Opt-in native verification of wheel-safe forms and base-camera roll."""
import copy,json,time
from pathlib import Path


def verify(window,output_dir):
    from .ui_verify_v33 import verify as previous_verify
    previous=previous_verify(window,output_dir)
    return verify_current(window,output_dir,previous)


def verify_current(window,output_dir,previous):
    from PySide6.QtCore import Qt,QPoint,QPointF,QTimer
    from PySide6.QtGui import QWheelEvent
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QApplication,QScrollArea,QMessageBox
    from pa2.ui.settings_dialog import SettingsDialog
    from pa2.rendering.scene import camera_for_step,_roll_camera
    from types import SimpleNamespace
    p=window.model_page;checks=[];errors=[];started=time.monotonic();output_dir=Path(output_dir)
    def require(value,message):
        if not value:raise AssertionError(message)
        checks.append(message)
    def wait_task():
        until=time.monotonic()+180
        while (window.thread and window.thread.isRunning()) or not p.isEnabled():
            QTest.qWait(20)
            if time.monotonic()>until:raise TimeoutError('V34 task timeout')
        QApplication.processEvents()
        if errors:raise RuntimeError(str(errors))
    def wheel(widget,delta,*,direct=False):
        if direct:
            event=QWheelEvent(QPointF(widget.rect().center()),QPointF(widget.mapToGlobal(widget.rect().center())),
                QPoint(),QPoint(0,delta),Qt.NoButton,Qt.NoModifier,Qt.NoScrollPhase,False)
            QApplication.sendEvent(widget,event);QTest.qWait(50);return
        top=widget.window();local=top.mapFromGlobal(widget.mapToGlobal(widget.rect().center()))
        QTest.wheelEvent(top.windowHandle(),QPointF(local),QPoint(0,delta));QTest.qWait(50)
    def close(a,b):return len(a)==len(b) and max(abs(x-y) for x,y in zip(a,b))<1e-7
    window._failed=lambda message:errors.append(message)
    dialog=SettingsDialog(window.settings_store,window.settings,window);dialog.resize(620,500);dialog.setModal(True)
    dialog.show();dialog.activateWindow();dialog.raise_();QTest.qWaitForWindowActive(dialog);QTest.qWait(100)
    try:
        scroll=dialog.findChild(QScrollArea);combo=dialog.widgets['video_encoder']
        scroll.ensureWidgetVisible(combo);combo.setFocus();QTest.qWait(30)
        before=combo.currentText();position=scroll.verticalScrollBar().value();wheel(combo,-120)
        require(combo.currentText()==before,'Native wheel preserves focused settings combo value')
        require(scroll.verticalScrollBar().value()>position,'Native wheel over combo scrolls settings panel')
        target=dialog.widgets['generation_timeout_sec'];scroll.ensureWidgetVisible(target);target.setFocus();QTest.qWait(30)
        before=target.value();position=scroll.verticalScrollBar().value();wheel(target.lineEdit(),-120)
        require(target.value()==before,'Native wheel over spin-box text preserves timeout')
        require(scroll.verticalScrollBar().value()>position,'Native wheel over spin-box text scrolls settings panel')
        # Popup-list scrolling and explicit edits have separate offscreen tests.
        # Windows synthetic open events also fail for the stock Qt combo; do
        # not claim a native mouse-open check from those simulated events.
    finally:dialog.reject()
    window.raise_();window.activateWindow();QTest.qWaitForWindowActive(window)
    window.tabs.setCurrentWidget(p);p.properties_tabs.setCurrentIndex(0)
    if not p._base_editing:p.base_card.click()
    scroll=p.properties_tabs.widget(0);scroll.verticalScrollBar().setValue(scroll.verticalScrollBar().maximum());QTest.qWait(50)
    # QTest's OS-level hit test misses this main-window child on this Windows
    # desktop (widgetAt=None, childAt=correct). Deliver the Qt wheel event to
    # the actual native form widget explicitly, without changing its handler.
    before=p.camera.currentData();position=scroll.verticalScrollBar().value();wheel(p.camera,120,direct=True)
    require(p.camera.currentData()==before,'Qt wheel preserves base-camera choice')
    point=p.camera.mapToGlobal(p.camera.rect().center());hit=QApplication.widgetAt(point)
    (output_dir/'wheel-properties-probe.json').write_text(json.dumps(dict(before=position,after=scroll.verticalScrollBar().value(),
        maximum=scroll.verticalScrollBar().maximum(),camera_visible=p.camera.isVisible(),camera_enabled=p.camera.isEnabled(),
        camera_global=(point.x(),point.y()),hit_type=type(hit).__name__,hit_name=hit.objectName() if hit else None,
        main_active=window.isActiveWindow(),modal=type(QApplication.activeModalWidget()).__name__,
        screens=[s.geometry().getRect() for s in QApplication.screens()],main_geometry=window.geometry().getRect(),
        camera_geometry=p.camera.geometry().getRect(),scroll_geometry=scroll.geometry().getRect(),
        main_child=type(window.childAt(window.mapFromGlobal(point))).__name__),indent=2),encoding='utf-8')
    require(position>0 and scroll.verticalScrollBar().value()<position,'Qt wheel scrolls motion properties over camera field')
    require(p.camera_roll_left.isEnabled() and p.camera_roll_right.isEnabled(),'Base screen-rotation buttons enabled')
    old=copy.deepcopy(p.plan.to_dict());mode=p.camera.currentData()
    pose=camera_for_step(SimpleNamespace(camera_mode=mode,camera_roll_deg=0,assembly_direction=(0,0,-1)),
        custom_cameras=p.plan.custom_cameras,camera_rolls=p.plan.camera_rolls)
    expected=_roll_camera(pose,90);p.camera_roll_right.click()
    require(p._camera_roll_deg==90 and p.has_pending_fields(),'Base 90-degree rotation is staged for explicit apply')
    def approve():
        box=next((w for w in QApplication.topLevelWidgets() if isinstance(w,QMessageBox) and w.isVisible()),None)
        if box:box.button(QMessageBox.Yes).click()
    QTimer.singleShot(100,approve);p.apply_button.click();QApplication.processEvents()
    key=p.plan.base_camera_mode;stored=p.plan.custom_cameras[key]
    require(close(stored['view_up'],expected.view_up),'Rotated base orientation saved in named reference')
    require(all(s.camera_mode==key and s.camera_roll_deg==0 for s in p.plan.steps),'Rotated base view applies coherently to every step')
    if expected.position is not None:
        require(close(stored['position'],expected.position) and close(stored['focal_point'],expected.focal_point),'Base rotation preserves captured position and focal point')
    fields=('group_id','removal_direction','assembly_direction','travel_mm')
    require(all(all(a[k]==b[k] for k in fields) for a,b in zip(old['steps'],p.plan.to_dict()['steps'])),'Base rotation preserves assembly motion and order')
    require(close(p.vtk_scene.renderer.GetActiveCamera().GetViewUp(),expected.view_up),'Base preview renders rotated screen orientation')
    require(p._camera_roll_deg==0 and not p.has_pending_fields(),'Applied base roll leaves no phantom pending edit')
    warnings=[];warning=QMessageBox.warning
    def record_warning(parent,title,text,*args,**kwargs):warnings.append(title+': '+text);return QMessageBox.Ok
    QMessageBox.warning=record_warning
    try:
        old_cid=window.confirmation_id;window._confirm(p.plan)
        require(not warnings and window.confirmation_id!=old_cid,'Rotated base plan confirms without warnings: '+str(warnings))
        window._render();wait_task()
        require(not warnings,'Rotated base video renders without warnings: '+str(warnings))
    finally:QMessageBox.warning=warning
    require(window.video_path is not None and window.video_path.is_file(),'Rotated base-camera video generated from reconfirmed plan')
    import imageio_ffmpeg
    import numpy as np
    from PIL import Image
    frames=imageio_ffmpeg.read_frames(str(window.video_path));metadata=next(frames);count=0
    for raw in frames:
        if count==0:Image.fromarray(np.frombuffer(raw,np.uint8).reshape(metadata['size'][1],metadata['size'][0],3)).save(output_dir/'v34-video-first.png')
        count+=1
    require(count>0,'Rotated-base MP4 decoded through the last frame')
    project_id=p.plan.project_id;window._reopen(next(x for x in window.projects.list() if x.id==project_id));wait_task()
    require(close(p.plan.custom_cameras[p.plan.base_camera_mode]['view_up'],expected.view_up),'Rotated base view persists after project reopen')
    result=dict(ok=True,previous_v32_checks=previous['previous_v32_checks'],previous_v33_checks=previous['verified_check_count'],
        checks=checks,verified_check_count=len(checks),video_frames=count,video_size=metadata['size'],
        video_path=str(window.video_path),native_popup_mouse_open_verified=False,
        property_wheel_delivery='QApplication.sendEvent(QWheelEvent)',settings_wheel_delivery='QTest.wheelEvent(QWindow)',
        seconds=time.monotonic()-started)
    (output_dir/'v34-workflow.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return result
