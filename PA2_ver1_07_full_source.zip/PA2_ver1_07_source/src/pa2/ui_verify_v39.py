"""Scoped bidirectional playback selection and separated viewer/player check."""
import copy,json
from pathlib import Path


def verify(window,output_dir):
    from .ui_verify_v38 import verify as prior_verify
    previous=prior_verify(window,output_dir)
    from PySide6.QtCore import Qt,QPoint,QRectF
    from PySide6.QtGui import QImage,QPainter
    from PySide6.QtWidgets import QApplication
    from PySide6.QtTest import QTest
    p=window.model_page;checks=[];output_dir=Path(output_dir)
    def require(value,message):
        if not value:raise AssertionError(message)
        checks.append(message)
    def click(row):
        item=p.order.item(row);p.order.scrollToItem(item);QApplication.processEvents()
        QTest.mouseClick(p.order.viewport(),Qt.LeftButton,pos=p.order.visualItemRect(item).center());QApplication.processEvents()
    def selected():return {item.data(Qt.UserRole) for item in p.order.selectedItems()}
    p.plan.steps[0].camera_mode='FRONT';p.plan.steps[1].camera_mode='TOP';p.plan.steps[1].camera_roll_deg=90
    p.set_plan(p.plan,'연동 확인');p.thumbnail_timer.stop();before=copy.deepcopy(p.plan.to_dict());saves=[]
    p.save_requested.connect(lambda *_:saves.append(1));timeline=p._timeline()
    for row in (1,0,1):
        click(row)
        require(not p.play_timer.isActive() and abs(p.play_time-timeline.segments[row].camera_end)<1e-9,'Paused card seeks exact stored step '+str(row))
        require(p.scrubber.value()==round(p.play_time/timeline.duration*10000),'Card updates slider '+str(row))
    expected=timeline.step_cameras[1];cam=p.vtk_scene.renderer.GetActiveCamera()
    require(max(abs(a-b) for a,b in zip(cam.GetViewUp(),expected.view_up))<1e-7,'Paused card applies saved camera roll')
    segment=timeline.segments[0];position=round((segment.highlight_end+segment.move_end)/2/timeline.duration*10000)
    p.scrubber.setValue(position)
    require(selected()=={p.plan.steps[0].group_id} and p.order.active_step_id==p.plan.steps[0].group_id,'Slider updates selected and active card')
    require(p.parts.selectedItems()[0].data(Qt.UserRole)==p.plan.steps[0].group_id and p.distance.value()==p.plan.steps[0].travel_mm,'Slider updates part list and properties')
    p.last_button.click();require(selected()=={p.plan.steps[-1].group_id} and p.scrubber.value()==10000,'End position selects last card')
    p.play.click();require(p.play_timer.isActive() and p.base_card.isChecked() and not selected(),'Playback restart follows base stage')
    p.play_time=timeline.segments[0].move_end+.001;p._play_tick()
    require(p.play_timer.isActive() and selected()=={p.plan.steps[1].group_id},'Stage boundary follows card without stopping playback')
    p.scrubber.setValue(1000);require(not p.play_timer.isActive() and p.base_card.isChecked(),'Manual slider seek pauses and follows base')
    require(p.viewer_card is not p.playback_card and not p.viewer_card.geometry().intersects(p.playback_card.geometry()),'3D and playback have separate white cards')
    require(p.plan.to_dict()==before and not saves,'Bidirectional navigation never changes or saves plan')
    pixels=p.vtk_scene.rgb_array();pixmap=window.grab();painter=QPainter(pixmap)
    image=QImage(pixels.data,pixels.shape[1],pixels.shape[0],pixels.shape[1]*3,QImage.Format_RGB888).copy()
    origin=p.vtk_widget.mapTo(window,QPoint(0,0));painter.drawImage(QRectF(origin.x(),origin.y(),p.vtk_widget.width(),p.vtk_widget.height()),image)
    painter.end();pixmap.save(str(output_dir/'layout-preview.png'))
    report=dict(ok=True,previous_checks=previous['verified_check_count'],verified_check_count=len(checks),checks=checks)
    (output_dir/'playback-link-workflow.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report
